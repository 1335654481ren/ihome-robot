lt --port 8080 --subdomain mysubdomain
