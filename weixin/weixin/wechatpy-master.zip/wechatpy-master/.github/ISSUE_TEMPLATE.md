<!--
请在下方填入问题描述。
更精确的版本信息和重现步骤可以大大加快您问题的解决速度。
 -->

## 问题描述 (Description)

## 配置信息 (Environment/Version)

- OS
<!-- Mac / Windows / Linux / ? -->

- Python
<!-- 2.7 / 3.4 / 3.5 / 3.6 / ? -->

- wechatpy
<!-- 1.4.2 / 1.5.1 / ? -->

## 重现步骤 (Reproducing)

