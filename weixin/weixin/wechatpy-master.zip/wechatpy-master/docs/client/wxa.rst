小程序接口
================

.. module:: wechatpy.client.api

.. autoclass:: WeChatWxa
   :members:
   :inherited-members:
