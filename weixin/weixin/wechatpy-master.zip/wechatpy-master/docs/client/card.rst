卡券接口
==========

.. module:: wechatpy.client.api

.. autoclass:: WeChatCard
   :members:
   :inherited-members:
