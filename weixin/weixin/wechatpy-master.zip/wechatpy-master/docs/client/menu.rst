自定义菜单接口
====================

.. module:: wechatpy.client.api

.. autoclass:: WeChatMenu
   :members:
   :inherited-members:
