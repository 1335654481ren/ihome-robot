语义理解接口
=================

.. module:: wechatpy.client.api

.. autoclass:: WeChatSemantic
   :members:
   :inherited-members:
