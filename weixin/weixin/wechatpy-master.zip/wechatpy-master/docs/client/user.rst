用户接口
====================

.. module:: wechatpy.client.api

.. autoclass:: WeChatUser
   :members:
   :inherited-members:
