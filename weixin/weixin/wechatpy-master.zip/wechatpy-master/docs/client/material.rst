素材接口
=============

.. module:: wechatpy.client.api

.. autoclass:: WeChatMaterial
   :members:
   :inherited-members:
