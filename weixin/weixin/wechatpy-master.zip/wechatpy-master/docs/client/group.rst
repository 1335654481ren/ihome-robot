用户分组接口
=================

.. module:: wechatpy.client.api

.. autoclass:: WeChatGroup
   :members:
   :inherited-members:
