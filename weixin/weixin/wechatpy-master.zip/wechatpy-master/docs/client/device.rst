设备功能接口
===================

.. module:: wechatpy.client.api

.. autoclass:: WeChatDevice
   :members:
   :inherited-members:
