微信连 Wi-Fi 接口
========================

.. module:: wechatpy.client.api

.. autoclass:: WeChatWiFi
   :members:
   :inherited-members:
