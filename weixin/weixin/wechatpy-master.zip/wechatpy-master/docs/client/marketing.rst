营销接口
================

.. module:: wechatpy.client.api

.. autoclass:: WeChatMarketing
   :members:
   :inherited-members:
