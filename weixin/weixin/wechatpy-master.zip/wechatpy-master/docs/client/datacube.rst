数据分析接口
==================

.. module:: wechatpy.client.api

.. autoclass:: WeChatDataCube
   :members:
   :inherited-members:
