主动消息接口
===================

.. module:: wechatpy.client.api

.. autoclass:: WeChatMessage
   :members:
   :inherited-members:
