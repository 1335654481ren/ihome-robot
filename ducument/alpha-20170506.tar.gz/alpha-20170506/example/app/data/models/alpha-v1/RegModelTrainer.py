##
# Alpha Detection Plus Regression Trainer
##

import os
import sys
import time
import logging
import struct
import cv2
import copy
import numpy as np
import cPickle
from smp import *
import ObjDetectorCPP
from Model import CascadeBoostedDNN
from ClassifierTrainer import AlphaClassifierTrainer, log, SetLogFileName


def LoadSmpAndLabelFileList(smp_fn_list, label_fn_list):
    assert len(smp_fn_list) == len(label_fn_list)
    smp_l = []
    label_l = []
    for idx, smp_fn in enumerate(smp_fn_list):
        label_fn = label_fn_list[idx]
        ext_fname = os.path.splitext(smp_fn)[-1]
        if ext_fname == '.smp':
            smps, info = LoadSmpFile(smp_fn)
        elif ext_fname == '.npy':
            smps = np.load(smp_fn)
        else:
            raise ValueError('Unknown smp format {}'.format(smp_fn))
        labels = np.load(label_fn).astype('float32')
        print labels.shape, smps.shape
        assert len(labels) == len(smps)
        smp_l.append(smps)
        label_l.append(labels)
        log.info('{} samples are loaded from {}.'.format(len(smps), smp_fn))
        log.info('{} labels are loaded from {}.'.format(len(labels), label_fn))
    smp_arr = np.vstack(smp_l)
    label_arr = np.vstack(label_l)
    log.info('Totally {} samples are loaded; smp size {}, label dim {}.'.format(
        len(smp_arr), smp_arr.shape[1:], label_arr.shape[1:]))
    return smp_arr, label_arr


def PerturbSamples(raw_smp_arr, dst_w, dst_h, perturb_para):
    from util import GetPerturbedSamples
    if perturb_para is None:
        return raw_smp_arr
    smp_l = []
    for smp_i, smp in enumerate(raw_smp_arr):
        if smp_i % 100 == 0:
            print 'perturbing {}/{}  \r'.format(smp_i, len(raw_smp_arr)),
        for i in xrange(perturb_para['times']):
            nsmp, info = GetPerturbedSamples(
                smp, (dst_w, dst_h), perturb_para, verbose=False)
            if nsmp is not None:
                smp_l.append(nsmp.reshape(1, dst_h, dst_w))

    return np.vstack(smp_l)


##########################################################################

class AlphaRegModelTrainer(object):

    def __init__(self, cfg):
        self.cfg = cfg
        workplace = cfg['workplace']
        if not os.path.exists(workplace):
            os.makedirs(workplace)
        log_fn = os.path.join(workplace, cfg['log_fname'])
        SetLogFileName(log_fn)
        log.info(cfg)
        ObjDetectorCPP.init_cuda(self.cfg['boosting_cfg']['device'], 2)

    def AddDecisionTrees(self, cascade_py, WCs, opt_thres, conf_conv):
        ret = copy.deepcopy(cascade_py)

        # add decision trees
        lut_l = []
        for WC in WCs:
            dt = {'modes': WC['modes'],
                  'pixels': WC['pixels'],
                  'biases': WC['biases'],
                  }
            if WC['bdt_type'] == 'naive':
                dt['dt_type'] = 3
            elif WC['bdt_type'] == 'balanced':
                dt['dt_type'] = 2
            else:
                raise ValueError("unkonwn bdt type {}".format(WC['bdt_type']))

            ret.DTs.append(dt)
            lut = WC['lut']  # .reshape(-1, 1)
            lut_l.append(lut)

        # add boosted dnn
        layer_agg_lut = {'act_type': -1,
                         'luts': lut_l
                         }
        layers_fc = []
        bd = {'layer_agg_lut': layer_agg_lut,
              'layers_fc': layers_fc,
              }
        ret.boosted_DNNs.append(bd)

        # add check points
        indices = ret.check_points['indices']
        thresholds = ret.check_points['thresholds']
        indices = np.resize(indices, indices.size + 1)
        thresholds = np.resize(thresholds, thresholds.size + 1)
        indices[-1] = len(WCs) if indices.size == 1 else indices[-2] + len(WCs)
        thresholds[-1] = opt_thres

        ret.check_points['indices'] = indices
        ret.check_points['thresholds'] = thresholds

        # add confidence convertor
        ret.conf_convs += [conf_conv['scale'],
                           conf_conv['offset'], conf_conv['conf_ub']]

        return ret

    def Learn(self):
        cfg = self.cfg
        bcfg = cfg['boosting_cfg']
        workplace = cfg['workplace']
        # set thread number of c++ module
        if 'thread_num' in cfg:
            ObjDetectorCPP.SetThreadNum(cfg['thread_num'])

        # Step 1: initiate model
        # create an empty cascade with only reference window size, scale and
        # channel types specified
        cascade_py = CascadeBoostedDNN.empty_cascade(bcfg['ref_w'], bcfg['ref_h'],
                                                     bcfg['starting_scale'], bcfg['scale_num'], bcfg['chan_types'])

        #
        # Step 2: collect data for boosting decision trees
        #
        smp_fn_list = cfg['smp_fn_list']
        label_fn_list = cfg['label_fn_list']
        samples, labels = LoadSmpAndLabelFileList(smp_fn_list, label_fn_list)

        #
        # Step 3.2: boosting decision trees
        #
        boosting_cfg = dict(cfg['boosting_cfg'])
        boosting_cfg['max_bdt_num'] = cfg['max_bdt_num']
        assert boosting_cfg['loss_type'] == 'least_square'
        WCs = []
        # concatenate samples
        weights = 1.0 / \
            len(samples) * np.ones((len(samples), 1), dtype='float32')
        # get initial conf
        #labels /= 32
        init_outputs = np.zeros_like(labels)
        avg_label = labels.mean(axis=0)
        init_outputs[:] = avg_label
        cascade_py.init_reg_outputs = avg_label
        log.info('init_outputs {}'.format(init_outputs))
        log.info("Initializing classifier learner....")
        learner = AlphaClassifierTrainer(
            boosting_cfg, samples, labels, weights, init_outputs)
        WCs, opt_thres = learner.LearnBoostedBDT(0, WCs)

        dummy_conf_conv = {'scale': 0, 'offset': 0, 'conf_ub': 0}
        cascade_py = self.AddDecisionTrees(
            cascade_py, WCs, opt_thres=0, conf_conv=dummy_conf_conv)

        # save model file
        cascade_fn_tmpl = self.cfg['cascade_fn_tmpl']
        cascade_fn = os.path.join(workplace, cascade_fn_tmpl.format(0))
        open(cascade_fn, 'w').write(cascade_py.tostring())
        log.info('cascade is saved to {}'.format(cascade_fn))
