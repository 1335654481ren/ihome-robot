# AlphaDet Training Tools #
## detect.py ##
detect.py is an interactive script used to detect objects with trained alphadet model.
### Supported options: ###
```shell
usage: detect.py [-h] [-b] [--cal_stat] [-t N] [-s START END STEP]
                 [-o LEFT TOP RIGHT BOTTOM] [-p STRIDE] [--pad_border border]
                 [-c conf_thres] [-m OVERLAP] [--min_resp_num MIN_RESP_NUM]
                 [-r reg_model_fname]
                 model_fname image_fname

Detect images with a given model.

positional arguments:
  model_fname           model filename
  image_fname           image filename (wildcard * or ? supported) or image
                        list filename.

optional arguments:
  -h, --help            show this help message and exit
  -b, --batch_mode      batch mode for detecting many images (default: false)
  --cal_stat            whether calculate statistics (used with batch mode -b)
                        (default : false)
  -t N, --thread_num N  thread number in batch mode (default: 4)
  -s START END STEP, --scan_scale START END STEP
                        starting scale, ending scale and scale step in image
                        scanning (default: 1.0 0.01 0.8)
  -o LEFT TOP RIGHT BOTTOM, --obj_roi LEFT TOP RIGHT BOTTOM
                        object roi in smp window (default: 0.0 0.0 1.0 1.0)
  -p STRIDE, --scan_stride STRIDE
                        scanning stride in x and y axis (default: 2)
  --pad_border border   padding border (default: 0)
  -c conf_thres, --conf_thres conf_thres
                        confidence threshold (default: -10000)
  -m OVERLAP, --merge_overlap OVERLAP
                        overlap threshold for merging detection responses
                        (default: 0.3)
  --min_resp_num MIN_RESP_NUM
                        minimum response number of merged results (default: 1)
  -r reg_model_fname, --bbox_reg reg_model_fname
                        bounding box regression model 
```
#### Basic usage ####
Basically, you can simply supply the *model_fname* and *image_fname*. 
```shell
$ python tools/detect.py model_fname image_fname
```
*model_fname* is the path to your alphadet model. *image_fname* can be image filenames (wildcard * or ? supported) or a list file containing image paths. Supported image types include: *'.bmp', '.BMP', '.jpg', '.JPG', '.png','.PNG'*. 

Images with annotations can be supplied as a list file using the following format:
```
image_filename1 left top right bottom ignore left top right bottom ignore 
image_filename2 
image_filename3 left top right bottom ignore  
```
Every 5-tuple `(left,top,right,bottom,ignore)` indicates a object boundingbox, `ignore` indicates whether this box should be ignored during training and testing. *NOTE*: list file with annoations should use *'.gt'* or *'.anno'* as file extention.

#### Batch mode ####
If detections results need to be saved for further performance evaluation and analysis, you can turn on the batch mode by `-b` or `--batch_mode`.
```shell
$ python tools/detect.py model_fname image_fname -b > det_results.txt
```

#### Bounding box regression ####
Bounding box regression model can be used to refine the detection boxes from the alhpadet model. The regression model can be specified with the `-r' option.
```shell
$ python tools/detect.py model_fname image_fname -r reg_model_fname
```

#### Useful Options ####
-  --cal_stat            whether calculate statistics (used with batch mode -b)(default : false)
-  -t N, --thread_num N  thread number in batch mode (default: 4)
-  -s START END STEP, --scan_scale START END STEP specify the *starting scale, ending scale and scale step* in image scanning (default: 1.0 0.01 0.8)
-  -o LEFT TOP RIGHT BOTTOM, --obj_roi LEFT TOP RIGHT BOTTOM
                        object roi in smp window (default: 0.0 0.0 1.0 1.0)
-  -p/--scan_stride specify the scanning stride in x and y axis (default: 2).
-  --pad_border padding the image with a border before detection, so that objects near the border can be detected.
-  -c/--conf_thres conf_thres specify the confidence threshold (default: -10000), useful when inspecting lower level cascade model.  
-  -m/--merge_overlap specify the overlap threshold for merging detection responses.
-  --min_resp_num specify the minimum response number for a valid detection.

### Key Shortcuts ###
In non-batch-mode (without -b), you can interactively change visualization options using key shortcuts.
- q or Q or *ESC* : quit.
- = or *SPACE* : jump to next image.
- \- : jump to previous image.
- ] : jump 10 images forward
- [ : jump 10 images backward
- ' : jump 100 images forward
- ; : jump 100 images backward
- m : whether to display merged responses.
- r : whether to display raw responses.
- w : whether to display cropped detections.
- g : whether to show annotated boundingboxes.

## eval.py ##
eval.py is used to evaluate the performance of the detection results on a dataset with annoations.
### Supported Options ###
```shell
usage: eval.py [-h] [--scale_gt SCALE_GT] [--scale_det SCALE_DET]
               [--square_gt SQUARE_GT] [--with_cnn_results WITH_CNN_RESULTS]
               [--graph_type GRAPH_TYPE] [--ivu_thres IVU_THRES]
               anno_file det_file

positional arguments:
  anno_file             Annotation file.
  det_file              Detection results file.

optional arguments:
  -h, --help            show this help message and exit
  --scale_gt SCALE_GT   Groundtruth boundingbox scaling factor
  --scale_det SCALE_DET
                        Detection boundingbox scaling factor
  --square_gt SQUARE_GT
                        Whether to make groundtruth box square.
  --with_cnn_results WITH_CNN_RESULTS
                        CNN detection results in det_file.
  --graph_type GRAPH_TYPE
                        Type of the graph:pr/fppi/fp
  --ivu_thres IVU_THRES
                        Intersection v.s. union ratio
```

### Basic Usage ###
Evaluate `det_file` produced by `tools/detect.py` using annoations from groundtruth file `anno_file`:
```shell
$ python tools/eval.py anno_file det_file
```
this script will produce three files: 
- `det_file_gt_det.txt` containing the evaluation result of each detection/gt box, i.e., the tp/fp/fn boxes
- `det_file_tp.txt` ontaining the evaluation result of each detection box, i.e., the tp/fp boxes
- `det_file_pr.jpg`/`det_file_fppi.jpg`/`det_file_fp.jpg`: pr/fppi/fp curves.

### Useful Options ###
- `--scale_gt` and `--scale_det` can be used to scale the groundtruth/detection boxes. This is useful when we object size is smaller than smp size. 
- `--square_gt` Whether to make groundtruth box square. Useful when alphadet detection produces square results.
- `--graph_type` specify the evaluation curve type, can be one of pr/fppi/fp.
- `ivu_thres` Intersection v.s. union ratio used to determine whether a detection is a correct detection.
## tra_info.py ##
tra_info.py is used to inspect the status of the training log and the trained alphadet model. tra_info.py have two mode:
- Print the *pass rate* of the positive/negtive training samples.
```shell
$ python tools/tra_info.py --pass_rate /path/to/model.log
1.00000  0.99653  0.98893  0.97788  0.96387  0.95182  0.93864  0.92491  0.91136  0.90173  0.89187  0.88135  0.87079  0.86022  
9.5e-01  1.9e-01  7.6e-02  3.9e-02  2.4e-02  1.2e-02  6.2e-03  3.7e-03  2.0e-03  1.3e-03  9.1e-04  7.0e-04  4.9e-04  3.5e-04
```
This command will print two lines of numbers, the first line is the pass rate of positive samples of each level, the second line is the pass rate of negative samples of each level.
- Test the *pass rate* of a smp file using a alphadet model. 
```shell
$ python tools/tra_info.py --screen model_fname [sample_fname ...]
```
This command will print the pass rate of the specified alhpadet model on each smp file.
## model_conv.py ##
model_conv.py is used to convert a trained alphadet model to a fixed point model that can be used in the C++ prediction library. There are two steps: 1. convert the trained alphadet model to general format (pickle); 2. convert the general format model to fixed point one that can be used in lib. 
### Supported Options ###
```shell
usage: model_conv.py [-h] [-r SRC_REG_FNAME] [-i left top right bottom]
                     [--t2g] [-p int_prec dec_prec lut_base_prec]
                     [--max_prec_loss MAX_PREC_LOSS] [--ign_lut_prec_loss]
                     [--g2l] [-l LAYER_NUM]
                     src_fname dst_prefix

Convert a trained model to fixed point one

positional arguments:
  src_fname             source filename
  dst_prefix            destination model filename prefix

optional arguments:
  -h, --help            show this help message and exit
  -r SRC_REG_FNAME, --src_reg_fname SRC_REG_FNAME
                        source regression filename (only for separate
                        training)
  -i left top right bottom, --init_reg_outputs left top right bottom
                        override initial outputs for regression model
  --t2g                 convert separately trained models (det and reg) to
                        general format (default: false)
  -p int_prec dec_prec lut_base_prec, --prec_bits int_prec dec_prec lut_base_prec
                        precision bits for interger, decimal and lut base
                        (default: 8, 10 and 4)
  --max_prec_loss MAX_PREC_LOSS
                        maximum precision loss allowed in converting a
                        floating number to fixed point (default: 1E-6)
  --ign_lut_prec_loss   ignore precision loss in converting LUT (default:
                        false)
  --g2l                 convert general format to lib format (default: false)
  -l LAYER_NUM, --layer_num LAYER_NUM
                        the number of adopted layers (default: -1, i.e., all
                        available layers)

```
### Convert trained alphadet model to general format ###
```shell
$ python tools/model_conv.py --t2g /path/to/det_workspace/cascade_lv19.bin –r /path/to/reg_workplace/cascade_lv00.bin general_model
```
This command read detection model from `/path/to/det_workspace/cascade_lv19.bin` and bbox regression
 model from `/path/to/reg_workplace/cascade_lv00.bin` and save the combined model to `general_model` in general format.

### Convert general model to library format model with 20 detection layers ###
```shell
$ python tools/model_conv.py --g2l general_model.alpha+.pkl pred_lib_model -l 20
```
## model_analysis.py ##
