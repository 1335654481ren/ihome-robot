#!/usr/bin/env python
# encoding: utf-8

"""
@version: 1.0
@author: Haoyuan Gao
@contact: haoyuan.gao@hobot.cc
@file: DataTransform.py
@time: 16/8/3 下午12:05
"""

import logging
import os
import json
import numpy as np

# set log format
LFMT = '[%(asctime)s - %(name)s:%(lineno)d] %(levelname)s : %(message)s'
logging.basicConfig(format=LFMT)
logger = logging.getLogger("DataTransform")
logger.setLevel(logging.INFO)


#
# Convert Json Hierarchy Rect to the Required Ground Truth Format
#
def convertHierarchyJsonToRectList(
        json_fname,
        region_hierachy,
        min_area=0,
        min_dist_to_boundary=0):
    '''
    Use to convert Jie's Json to rect list
    :param json_fname:
    :param region_name:
    :param min_area:
    :param min_dist_to_boundary:
    :return: (image_key, rect_l) list
    '''

    # check hirachy info
    region_hierachy = region_hierachy.split(',')

    gt_l = []
    for line in open(json_fname):
        if len(line) < 2:
            continue
        j = json.loads(line.strip())
        if region_name not in j.keys():
            logger.debug("data do not contains {}".format(region_name))
            continue
        image_key = j['image_key']
        image_key = os.path.join(os.path.splitext(
            os.path.basename(json_fname))[0], image_key)
        img_w = j['width'] if isinstance(j['width'], int) else int(j['width'])
        img_h = j['height'] if isinstance(
            j['height'], int) else int(j['height'])
        rect_l = []

        testCmd = 'j'
        for line in region_hierachy:
            if eval(testCmd + '.has_key("{}")'.format(line)):
                testCmd = testCmd + '["{}"]'.format(line)
            else:
                logger.fatal("cannot get {} in json file".format(line))
                return []

        logger.info('use region: {}'.format(testCmd))

        for item in eval(testCmd):
            if item["struct_type"] != "rect":
                logger.debug(
                    'struct_type should be "rect", not {}'.format(
                        item['struct_type']))
                continue
            ign = item['ign'] if 'ign' in item else 0
            left, top, right, bottom = np.array(item['data'], dtype='float32')

            if (right - left) * (bottom - top) < min_area:
                # ignore due to too small size
                ign = 1

            dist_to_boundary = min(
                max(0, left),
                max(0, top),
                max(0, img_w - right),
                max(0, img_h - bottom))
            if dist_to_boundary < max(
                    right - left,
                    bottom - top) * min_dist_to_boundary:
                # ignore due to being to close to boundary
                ign = 1

            rect = (left, top, right, bottom, ign)

            rect_l.append(rect)

        gt_l.append((image_key, rect_l))

    return gt_l

#
# Convert Json Rect to the Required Ground Truth Format
#


def convertJsonToRectList(
        json_fname,
        region_name,
        attr_filter=None,
        attr_ignore=None,
        min_area=0,
        min_dist_to_boundary=0):
    '''
    Use to convert Jie's Json to rect list
    :param json_fname:
    :param region_name:
    :param attr_filter: filter part for
    :param min_area:
    :param min_dist_to_boundary:
    :return: (image_key, rect_l) list
    '''
    gt_l = []
    for line in open(json_fname):
        if len(line) < 2:
            continue
        j = json.loads(line.strip())
        if region_name not in j.keys():
            logger.debug("data do not contains {}".format(region_name))
            continue
        image_key = j['image_key']
        image_key = os.path.join(
            os.path.splitext(os.path.basename(json_fname))[0], image_key)
        img_w = j['width'] if isinstance(j['width'], int) else int(j['width'])
        img_h = j['height'] if isinstance(
            j['height'], int) else int(j['height'])
        rect_l = []
        for item in j[region_name]:
            if item["struct_type"] != "rect":
                logger.debug(
                    'struct_type should be "rect", not {}'.format(
                        item['struct_type']))
                continue

            ign = 0
            if ('ignore' in item['attrs']) and (item['attrs']['ignore'] == 'yes'):
                ign = 1

            # check attribute
            if attr_filter is not None:
                if item['attrs']['type'] != attr_filter:
                    if attr_ignore is not None and item['attrs']['type'] in attr_ignore:
                        ign = 1
                    else:
                        logger.debug(
                            'type not match {}'.format(item['attrs']['type']))
                        continue

            if attr_ignore is not None and item['attrs']['type'] in attr_ignore:
                ign = 1

            left, top, right, bottom = np.array(item['data'], dtype='float32')

            if (right - left) * (bottom - top) < min_area:
                # ignore due to too small size
                ign = 1

            dist_to_boundary = min(
                max(0, left),
                max(0, top),
                max(0, img_w - right),
                max(0, img_h - bottom))
            if dist_to_boundary < max(
                    right - left,
                    bottom - top) * min_dist_to_boundary:
                # ignore due to being to close to boundary
                ign = 1

            rect = (left, top, right, bottom, ign)

            rect_l.append(rect)

        gt_l.append((image_key, rect_l))

    return gt_l

#
# Convert Json FaceKpt72Gt to the Required Ground Truth Format
#


def convertJsonToFaceKpt72Gt(
        json_fname,
        min_area=0,
        min_dist_to_boundary=0,
        nose_center=False):
    gt_l = []
    for line in open(json_fname):
        if len(line) < 2:
            continue
        j = json.loads(line.strip())
        if 'face_keypoint_72' not in j:
            continue
        image_key = j['image_key']
        image_key = os.path.join(os.path.splitext(
            os.path.basename(json_fname))[0], image_key)
        img_w = j['width']
        img_h = j['height']
        rect_l = []
        for item in j['face_keypoint_72']:
            ign = item['ign'] if 'ign' in item else 0
            kpt72 = np.array(item['data'], dtype='float32')
            valid_indices = np.setdiff1d(
                np.arange(
                    len(kpt72)), np.where(
                    kpt72 < 0)[0])
            valid_kpt = kpt72[valid_indices]
            left, top = valid_kpt.min(axis=0)
            right, bottom = valid_kpt.max(axis=0)
            if nose_center:
                # with nose as center
                nose = kpt72[57]
                if nose.min() >= 0:
                    # update center as nose
                    cx, cy = nose
                    radius = 0.5 * max(bottom - top, right - left)
                    # update rect
                    left = cx - radius
                    right = cx + radius
                    top = cy - radius
                    bottom = cy + radius
                else:
                    # ignore due to invalid nose
                    ign = 1

            if (right - left) * (bottom - top) < min_area:
                # ignore due to too small size
                ign = 1

            dist_to_boundary = min(max(0, left), max(0, top),
                                   max(0, img_w - right), max(0, img_h - bottom))
            if dist_to_boundary < max(
                    right - left,
                    bottom - top) * min_dist_to_boundary:
                # ignore due to being to close to boundary
                ign = 1

            rect = (left, top, right, bottom, ign)

            rect_l.append(rect)

        gt_l.append((image_key, rect_l))

    return gt_l

#
# Convert Old Pickle Format to the Required Ground Truth Format
#


def convertOldPklToFaceKpt72Gt(
        pkl_fname,
        min_area=0,
        min_dist_to_boundary=0,
        nose_center=False):
    gt_l = []
    pkl = cPickle.load(open(pkl_fname))
    for image_key in sorted(pkl):
        img_w = pkl[image_key][0]['width']
        img_h = pkl[image_key][0]['height']
        rect_l = []
        for item in pkl[image_key][0]['objects']:
            ign = item['ign'] if 'ign' in item else 0
            kpt72 = item['kpt_72']
            valid_indices = np.setdiff1d(
                np.arange(
                    len(kpt72)), np.where(
                    kpt72 < 0)[0])
            valid_kpt = kpt72[valid_indices]
            left, top = valid_kpt.min(axis=0)
            right, bottom = valid_kpt.max(axis=0)
            if nose_center:
                # with nose as center
                nose = kpt72[57]
                if nose.min() >= 0:
                    # update center as nose
                    cx, cy = nose
                    radius = 0.5 * max(bottom - top, right - left)
                    # update rect
                    left = cx - radius
                    right = cx + radius
                    top = cy - radius
                    bottom = cy + radius
                else:
                    # ignore due to invalid nose
                    ign = 1

            if (right - left) * (bottom - top) < min_area:
                # ignore due to too small size
                ign = 1

            dist_to_boundary = min(max(0, left), max(0, top),
                                   max(0, img_w - right), max(0, img_h - bottom))
            if dist_to_boundary < max(
                    right - left,
                    bottom - top) * min_dist_to_boundary:
                # ignore due to being to close to boundary
                ign = 1

            rect = (left, top, right, bottom, ign)

            rect_l.append(rect)

        gt_l.append((image_key, rect_l))

    return gt_l

if __name__ == '__main__':
                # test for above function
    import sys
    func_name_l = []
    for func_name in dir():
        if func_name[:7] == 'convert':
            func_name_l.append(func_name)
    if len(sys.argv) < 3:
        print "Input the function you want to test"
        for func_name in func_name_l:
            print func_name
        print "Usage: python {} func_name json_anno_file".format(sys.argv[0])
    else:
        if sys.argv[1] == "convertHierarchyJsonToRectList":
            jsonFile = sys.argv[2]
            region_hierachy = ''
            convertHierarchyJsonToRectList(jsonFile, region_hierachy)
        elif sys.argv[1] == "convertJsonToRectList":
            jsonFile = sys.argv[2]
            region_name = 'hand'
            attr_filter = 'hand_open'
            attr_ignore = ['hand_close']
            gt_l = convertJsonToRectList(
                jsonFile,
                region_name,
                attr_filter=attr_filter,
                attr_ignore=attr_ignore)
            for line in gt_l:
                print line
        else:
            print "Not support"
