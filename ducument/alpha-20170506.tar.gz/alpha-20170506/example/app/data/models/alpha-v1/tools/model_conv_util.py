#
#   Utilities for Alpha Detection Model Conversion
#   Copyright (c) 2016 by Horizon Robotics Inc.
#   Author: Chang Huang (chang.huang@hobot.cc)
#

import os, sys
import numpy as np

def float2fp(x, int_prec, dec_prec, max_prec_loss = 1E-6):
  '''
  Convert a floating point array, a list or a matrix to fixed point one

  Inputs:
    x: an array, a list or a matrix with floatint point numbers.
    int_prec: the bit number used for the integer part of the fixed point number, including the sign bit.
    dec_prec: the bit number used for the decimal part of the fixed point number.
    max_prec_loss: maximum precision loss in converting a floating number to a fixed point one.

  Return:
    x_: a numpy array with fixed point numbers, i.e., integers
  '''
  x = np.array(x, dtype = 'float32')
  x_ = np.round(x * (1 << dec_prec)).astype('int32')
  if x_.max() > (1<<(int_prec+dec_prec-1))-1 or x_.min() < -(1<<(int_prec+dec_prec-1)):
    raise ValueError('x_ ({}~{})exceeds required integer + decimal precision range ({} bits)'.format(x_.min(), x_.max(), int_prec + dec_prec))

  prec_loss = np.abs(x_ * (1.0 / (1 << dec_prec)) - x).max()
  if max_prec_loss is not None and prec_loss > max_prec_loss:
    print 'loss of precision in conversion with dec_prec {} is {}\n\t{}\n\t{}'.format(dec_prec, prec_loss, x.flatten(), x_.flatten())
  return x_


def compress_fp(x, base_prec, ign_prec_loss = False):
  '''
  Further compress a fixed point array

  Inputs:
    x: a numpy array with fixed point numbers.
    base_prec: the bit number used for the base of these numbers.
    ign_prec_loss: whether ignore the loss in compressing.

  Return:
    x_: a numpy array as the base of x.
    exponent: an interger as the unified exponent of x.
  '''
  exponent = max(0, int(np.ceil(np.log2(max(x.max() + 1, -x.min()))) - (base_prec - 1)))
  x_ = x >> exponent
  if (x_ << exponent != x).max():
    info = 'with base_prec {}, x_ << {} != x, {}, {}'.format(base_prec, exponent, x_.flatten(), x.flatten())
    if ign_prec_loss:
      print info
    else:
      raise ValueError(info)
  return x_, exponent


def layer_floating_to_fixed_point(l, int_prec, dec_prec, lut_base_prec, max_prec_loss, ign_lut_prec_loss, is_reg_layer):
  '''
  Convernt a general format layer with floating-point parameters to a fixed point version

  Inputs:
    l: the general format layer whose parameters are floating point numbers.
    int_prec: the bit number used for the integer part of the fixed point number, including the sign bit.
    dec_prec: the bit number used for the decimal part of the fixed point number.
    lut_base_prec: the bit number used for the base of LUT elements.
    max_prec_loss: maximum precision loss in converting a floating number to a fixed point one.
    ign_lut_prec_loss: whether ignore the loss in compressing LUT elements with lut_base_prec.

  Return:
    a layer with all parameters fixed point.
  '''
  nl = {}
  nl['dt_num'] = l['dt_num']
  nl['dt_depth'] = l['dt_depth']
  nl['lut_dim'] = l['lut_dim']
  nl['pixels'] = l['pixels']
  nl['biases'] = l['biases']
  # convert LUTs
  nl['luts'] = []
  for lut in l['luts']:
    lut_fp = float2fp(lut, int_prec, dec_prec, max_prec_loss)
    lut_fp_base, lut_fp_exp = compress_fp(lut_fp, lut_base_prec, ign_lut_prec_loss)
    nl['luts'].append({'base' : lut_fp_base, 'exp' :lut_fp_exp})
  # convert cummulative parameters
  if not is_reg_layer:
    nl['pre_conf_bias'] = float2fp(l['pre_conf_bias'], int_prec, dec_prec, max_prec_loss)
    nl['pre_conf_ub'] = float2fp(l['pre_conf_ub'], int_prec, dec_prec, max_prec_loss)
    nl['threshold'] = float2fp(l['threshold'], int_prec, dec_prec, max_prec_loss)
  return nl
