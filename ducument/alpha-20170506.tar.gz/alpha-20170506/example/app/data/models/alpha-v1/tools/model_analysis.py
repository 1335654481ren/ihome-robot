import os, sys
import numpy as np

from Model import CascadeBoostedDNN

def calcConflictsOfPixels(model, dt_group_size):
  pixel_num = 0
  group_num = 0
  sum_cs = np.zeros((3,8), dtype = 'int')
  sum_csx = np.zeros((3,8,2), dtype = 'int')
  sum_x = np.zeros(64, dtype = 'int')
  sum_y = np.zeros(64, dtype = 'int')
  max_cs_l = []
  max_csx_l = []
  max_x_l = []
  max_y_l = []
  for si in xrange(0, len(model.DTs), dt_group_size):
    ei = min(len(model.DTs), si + dt_group_size)
    pixels = []
    for i in xrange(si, ei):
      pixels += model.DTs[i]['pixels']
    pixel_num += len(pixels)
    cs = np.zeros((3,8), dtype = 'int')
    csx = np.zeros((3,8,2), dtype = 'int')
    x = np.zeros(64, dtype = 'int')
    y = np.zeros(64, dtype = 'int')
    for p in pixels:
      cs[p['s'] - 1, p['c']] += 1
      csx[p['s'] - 1, p['c'], (p['x'] / 2) % 2] += 1
      x[p['x']] += 1
      y[p['y']] += 1
    sum_cs += cs
    sum_csx += csx
    sum_x += x
    sum_y += y
    max_cs_l.append(cs.max())
    max_csx_l.append(csx.max())
    max_x_l.append(x.max())
    max_y_l.append(y.max())
    group_num += 1
  print 'dt num {}, pixel num {}, dt group size {}, group_num {}'.format(len(model.DTs), pixel_num, dt_group_size, group_num)
  print 'conflicts in cs: max group cycle {}, total cycle {}'.format(np.max(max_cs_l), np.sum(max_cs_l))
  print 'conflicts in csx: max group cycle {}, total cycle {}'.format(np.max(max_csx_l), np.sum(max_csx_l))
  print 'conflicts in x: max group cycle {}, total cycle {}'.format(np.max(max_x_l), np.sum(max_x_l))
  print 'conflicts in y: max group cycle {}, total cycle {}'.format(np.max(max_y_l), np.sum(max_y_l))
  print 'sum_cs {}'.format(sum_cs)
  print 'sum_csx {}'.format(sum_csx)
  print 'sum_x {}'.format(sum_x)
  print 'sum_y {}'.format(sum_y)


def calcDtNum(generic_model_fn):
    import cPickle
    m = cPickle.load(open(generic_model_fn))
    cum_num = 0
    print 'det layers:'
    for idx, layer in enumerate(m['det_layers']):
        num = layer['dt_num']
        cum_num += num
        print '{:02d}:{:03d}:{:04d}\t'.format(idx, num, cum_num),
    print
    if 'reg_layer' in m:
        print 'reg layer: {:03d}'.format(m['reg_layer']['dt_num'])


def ParseArg(arg_list):
    import argparse
    parser = argparse.ArgumentParser(description='Model analysis.')
    parser.add_argument('model_fname', help='model filename')
    parser.add_argument('-c', '--conflict', type=int, default=0, metavar='dt_group_num', help='calculate conflicts of features in cs, x and y with dt_group_num (default: 0)')
    parser.add_argument('--dt-num', action='store_true', default=False, help='calculate dt numbers of each layer (default: false)')
    return parser.parse_args(arg_list)

if __name__ == '__main__':
    para = ParseArg(sys.argv[1:])
    if para.conflict > 0:
        model = CascadeBoostedDNN()
        model.fromstring(open(para.model_fname).read())
        calcConflictsOfPixels(model, para.conflict)
    if para.dt_num:
        calcDtNum(para.model_fname)



