import matplotlib
matplotlib.use('Agg')
import os, sys
import cv, cv2
import glob
import numpy as np
from time import time
sys.path.append('../')
sys.path.append('./')
import ObjDetectorCPP
from util import GetPerturbedSamples
import pylab
from smp import *
from scipy.io import savemat, loadmat
import argparse

THREAD_NUM = 2
ObjDetectorCPP.SetThreadNum(THREAD_NUM)

def parse_args():
  parser = argparse.ArgumentParser()
  parser.add_argument('anno_file', help='Annotation file.')
  parser.add_argument('det_file', help='Detection results file.')
  parser.add_argument('--scale_gt', help='Groundtruth boundingbox scaling factor', default=0, type=float)
  parser.add_argument('--scale_det', help='Detection boundingbox scaling factor', default=0, type=float)
  parser.add_argument('--square_gt', help='Whether to make groundtruth box square.', default=False, type=bool)
  parser.add_argument('--with_cnn_results', help='CNN detection results in det_file.', default=False, type=bool)
  parser.add_argument('--graph_type', help='Type of the graph:pr/fppi/fp', default='pr', type=str)
  parser.add_argument('--ivu_thres', help='Intersection v.s. union ratio', default='0.5', type=float)
  args = parser.parse_args()
  return args

def calfp(fp, rec):
  ap = 0
  for i in xrange(len(fp)-1):
    ap += (fp[i+1]-fp[i])*rec[i]
    if fp[i+1] > 100:
      break
  return ap/100

def calap(recall, prec):
  mrec = [0] + list(recall.flatten()) + [1]
  mpre = [0] + list(prec.flatten()) + [0]
  for i in range(len(mpre)-2, 0, -1):
    mpre[i] = max(mpre[i], mpre[i+1])
  ap = 0
  for i in xrange(len(mpre)-1):
    if mpre[i+1] > 0: #0.9:
      ap += (mrec[i+1] - mrec[i])*mpre[i+1]
  return ap, mrec[1:-1], mpre[1:-1]

def evaluation(det_boxes, gt_boxes, ivu_thres):
  num_gt = 0
  tp_all = []
  fp_all = []
  tp_boxes_all = []
  all_conf = []
  num_image = len(det_boxes)
  diff_x = []
  gt_detections = []
  for i, gt in enumerate(gt_boxes):
    num_gt += gt.shape[0] - gt[:,4].sum()
    num_gt_i = gt.shape[0]
    idx = np.argsort(-det_boxes[i][:,4])
    det_b = det_boxes[i][idx]
    num_obj = len(det_boxes[i])
    conf = det_boxes[i][idx,4].reshape(-1, 1)
    gt_detected = np.zeros((num_gt_i, 1))
    tp = np.zeros((num_obj, 1))
    fp = np.zeros((num_obj, 1))
    tp_boxes = np.zeros((num_obj, 1))
    for j in xrange(num_obj):
      b = det_b[j]
      kmax = -1
      ov_max = -1000000
      iv_max = -1000000
      for k in xrange(gt.shape[0]):
        if gt_detected[k] == 1:
          continue
        bbgt = gt[k]
        bi = [max(b[0], bbgt[0]), max(b[1], bbgt[1]), min(b[2], bbgt[2]), min(b[3], bbgt[3])]
        det_w = b[2] - b[0]
        det_h = b[3] - b[1]
        m = bbgt[2] - bbgt[0]
        n = bbgt[3] - bbgt[1]
        thr = min(ivu_thres, m*n/(m+10.0)/(n+10.0))
        iw = bi[2] - bi[0] + 1
        ih = bi[3] - bi[1] + 1
        if iw > 0 and ih > 0:
          ua = (b[2] - b[0] + 1) * (b[3] - b[1] + 1) + \
               (bbgt[2] - bbgt[0] + 1) * (bbgt[3] - bbgt[1] + 1) - \
               iw * ih
          ov = iw * ih / ua
          iv = iw * ih / (det_w * det_h)
          if bbgt[4] > 0:
            iv_max = max(iv, iv_max)
          if ov > ov_max and ov > thr:
            diff_x.append((bbgt[2] + bbgt[1] - b[2] - b[1])/2.0)
            ov_max = ov
            kmax = k
          if ov > thr:
            tp_boxes[j] = 1
      if kmax >= 0:
        if gt[kmax, 4] < 1:
          tp[j] = 1
        gt_detected[kmax] = 1
      elif iv_max < 0.5:
        fp[j] = 1;

    gt_detections.append(gt_detected)
    tp_all.append(tp)
    fp_all.append(fp)
    tp_boxes_all.append(zip(det_b, tp_boxes))
    all_conf.append(conf)
  diff_x = np.hstack(diff_x)
  #print diff_x.mean(), diff_x.std()
  tp = np.vstack(tp_all)
  fp = np.vstack(fp_all)
  num_pos = tp.sum()
  conf = np.vstack(all_conf)
  idx = np.argsort(-conf, axis=0)
  conf = conf[idx]
  tp = np.require(tp[idx], dtype=np.float)
  fp = fp[idx]
  tp = np.cumsum(tp)
  fp = np.cumsum(fp)
  recall = tp/(num_gt)
  prec = tp/(tp + fp + 1E-10)
  fppi = fp/float(num_image)
  ap, recall, prec = calap(recall, prec)

  return ap, recall, prec, list(fppi.flatten()), list(fp.flatten()), list(conf.flatten()), tp_boxes_all, gt_detections

def eval_detection(args):
  anno_l = open(args.anno_file, 'r').readlines()

  det_l = open(args.det_file, 'r').readlines()
  scale_gt = args.scale_gt
  scale_det = args.scale_det
  square_gt = args.square_gt
  ivu_thres = args.ivu_thres

  bias = 0
  gt_boxes = []
  for i, anno in enumerate(anno_l):
    box = np.array([float(s) for s in anno.strip().split()[1::]]).reshape(-1, 5)
    cx = (box[:,0] + box[:,2])/2.0
    cy = (box[:,1] + box[:,3])/2.0
    w = (box[:,2] - box[:,0])
    h = (box[:,3] - box[:,1])
    if square_gt:
      sz = np.maximum(w, h)
      if scale_gt <= 0:
        scale_gt = 0.5
      box[:,0] = cx - sz*scale_gt
      box[:,1] = cy - sz*scale_gt
      box[:,2] = cx + sz*scale_gt
      box[:,3] = cy + sz*scale_gt
    box[:,4] = np.array(box[:,4] > 0, dtype=np.float)
    gt_boxes.append(box)

  det_boxes = []
  files = []
  for det in det_l:
    files.append(det.strip().split()[0])
    if not args.with_cnn_results:
      box = np.array([float(s) for s in det.strip().split()[1::]]).reshape(-1, 5)
    else:
      raise Exception
      box = np.array([float(s) for s in det.strip().split()[1::]]).reshape(-1, 6+4)
      box[:,4] += box[:,5] * float(sys.argv[5])
      box[:, :4] = box[:, 6:]
    if scale_det > 0:
      cx = (box[:,0] + box[:,2])/2.0
      cy = (box[:,1] + box[:,3])/2.0
      w = (box[:,2] - box[:,0])
      h = (box[:,3] - box[:,1])
      box[:,0] = cx - w*1.*scale_det
      box[:,1] = cy - h*1.*scale_det
      box[:,2] = cx + w*1.*scale_det
      box[:,3] = cy + h*1.*scale_det
    det_boxes.append(box)

  ap, rec, pre, fppi, fp, conf, tp_boxes, gt_detections = evaluation(det_boxes, gt_boxes, ivu_thres)
  pr = args.graph_type
  if pr == 'pr':
    print ap, rec[-1]
    pylab.plot(rec, pre)
    pylab.xlabel('recall')
    pylab.ylabel('precision')
    pylab.xlim([0, 1])
    pylab.ylim([0, 1])
    pylab.xticks(np.arange(0.,1,0.05), fontsize = 8)
    pylab.yticks(np.arange(0.,1,0.05), fontsize = 8)
    pylab.title('ap = {}'.format(ap))
    pylab.grid()
  elif pr == 'fppi':
    pylab.semilogx(fppi, np.array(rec))
    pylab.xlabel('fppi')
    pylab.ylabel('miss rate')
    pylab.ylim([0, 1])
    pylab.xlim([0.001,1])
    pylab.xticks(np.power(10, np.arange(-3,0.1,0.1)), fontsize = 8)
    pylab.yticks(np.arange(0.,1.0,0.05), fontsize = 8)
    pylab.title('fppi vs miss_rate')
    pylab.grid()
  else:
    afp = calfp(fp, rec)
    print afp
    pylab.plot(fp, np.array(rec))
    pylab.xlabel('fp')
    pylab.ylabel('recall')
    pylab.ylim([0, 1])
    pylab.xlim([0, 200])
    pylab.xticks(np.arange(0, 200, 10), fontsize = 8)
    pylab.yticks(np.arange(0.,1.0,0.05), fontsize = 8)
    pylab.title('fp vs recall')
    pylab.grid()
  pylab.savefig(args.det_file + '_' + pr  + '.jpg')
  strs = []
  for i in xrange(len(rec)):
    strs.append(' '.join([str(rec[i]), str(pre[i]), str(fppi[i]), str(fp[i]), str(conf[i])]) + '\n')
  open(args.det_file + '.txt', 'w').writelines(strs)
  f = open(args.det_file + '_gt_det.txt', 'w')
  for i in xrange(len(gt_detections)):
      f.write('%s' % (files[i]))
      # 0: fp 1: tp 2: miss
      for j in xrange(gt_boxes[i].shape[0]):
          if not gt_detections[i][j]:
              f.write(' %.1f %.1f %.1f %.1f 0 2' %(gt_boxes[i][j, 0], gt_boxes[i][j, 1], gt_boxes[i][j, 2], gt_boxes[i][j, 3]))
      for b, tp in tp_boxes[i]:
          f.write(' %.1f %.1f %.1f %.1f %.1f %d' %(b[0], b[1], b[2], b[3], b[4], tp[0]))
      f.write('\n')
  f.close()
  strs = []
  for i, tps in enumerate(tp_boxes):
    ss = files[i]
    for b, tp in tps:
      ss += ' ' + ' '.join([str(x) for x in b]) + ' ' + str(tp[0])
    strs.append(ss + '\n')
  open(args.det_file + '_tp.txt', 'w').writelines(strs)

if __name__ == '__main__':
  args = parse_args()
  eval_detection(args)
