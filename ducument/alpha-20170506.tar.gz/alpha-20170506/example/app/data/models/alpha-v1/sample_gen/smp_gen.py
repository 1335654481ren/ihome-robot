#
#   Sample Generator for Alpha Detection
#   Author: Chang Huang (chang.huang@horizon-robotics.com)
#

import os
import sys
import cv2
import numpy as np
import cPickle

# convert rect to 4 key points
rect2kpt = lambda l, t, r, b: np.array([(l, t), (r, t), (r, b), (l, b)])

# get bounding box of key points
kpt2rect = lambda kpt: (
    np.min(kpt[:, 0]), np.min(kpt[:, 1]), np.max(kpt[:, 0]), np.max(kpt[:, 1]))

# generate a uniform random number given lower bound and upper bound
randRange = lambda lb, ub: np.random.rand() * (ub - lb) + lb

# get affine transformation matrix given scale, rotation and translation
getAffTransMat = lambda s, R, t: np.hstack([s * R, t.reshape(-1, 1)])

# get affine transformed coordinate
getAffTransCoord = lambda kpt, aff_mat: np.dot(np.hstack([kpt, 1]), aff_mat.T)

# get affine transformed coordinates
getAffTransCoords = lambda kpt, aff_mat: np.dot(
    np.hstack([kpt, np.ones((len(kpt), 1))]), aff_mat.T)

# get inverse affine transform matrix


def getInvAffTransMat(aff_mat):
    R = aff_mat[:, :2]
    t = aff_mat[:, 2:]
    inv_R = np.linalg.inv(R)
    return np.hstack([inv_R, - np.dot(inv_R, t)])

#
# perturb keep points by scaling, rotation and translation
#


def perturbKeyPoints(kpt, scale, rot_center, rot_angle, trans):
    #alpha = scale * np.cos(rot_angle * np.pi / 180)
    #beta = scale * np.sin(rot_angle * np.pi / 180)
    # rot_mat = np.array([(alpha, beta, (1 - alpha) * rot_center[0] - beta * rot_center[1]),
    #                    (-beta, alpha, beta * rot_center[0] + (1 - alpha) * rot_center[1])])
    rot_mat = cv2.getRotationMatrix2D(rot_center, rot_angle, scale)
    rot_mat[:, 2] += trans
    return getAffTransCoords(kpt, rot_mat)

#
# Get scale, otation matrix and translation
# from src to dst via weighted least square
# and treat horizontal loss and vertical loss differently
#


def getSimilarityTransformWeightedLeastSquareDiffXY(src_xy, dst_xy, wgt=None, xy_wgt=None):
    if xy_wgt is None:
        xy_wgt = (1, 1)
    if wgt is None:
        wgt = np.ones(len(src_xy), dtype=src_xy.dtype)
    wgt = wgt.reshape(-1, 1)
    wgt_sum = wgt.sum()
    mean_src = (src_xy * wgt).sum(axis=0) / wgt_sum
    mean_dst = (dst_xy * wgt).sum(axis=0) / wgt_sum
    cov = np.dot((xy_wgt * (src_xy - mean_src)).T,
                 (xy_wgt * (dst_xy - mean_dst)) * wgt) / wgt_sum
    src_var = (((xy_wgt * (src_xy - mean_src)) ** 2) * wgt).sum() / wgt_sum
    u, d, v = np.linalg.svd(cov)
    R = np.dot(v.T, u.T)
    s = d.sum() / src_var
    t = mean_dst - np.dot(mean_src, s * R.T)
    return s, R, t

#
# crop an image by similarity transform, given src and dst key points,
# optionally with their weights, de-moire min scale, and pyramid scale step
#


def cropImageBySimTransGivenKeyPoints(src_img, src_kpt,
                                      dst_img_size, dst_kpt,
                                      kpt_xy_wgt=None,
                                      kpt_wgt=None,
                                      demoire_min_scale=None,
                                      warp_flags=cv2.INTER_LINEAR,
                                      warp_border_mode=cv2.BORDER_REPLICATE,
                                      warp_border_val=0,
                                      pyramid_scale_step=None):
    s, R, t = getSimilarityTransformWeightedLeastSquareDiffXY(
        src_kpt, dst_kpt, kpt_wgt, kpt_xy_wgt)
    ori_tran_mat = getAffTransMat(s, R, t)
    if pyramid_scale_step != None:
        # simulate image pyramid effects
        while s < pyramid_scale_step:
            s /= pyramid_scale_step
            src_img = cv2.resize(src_img, dsize=None, fx=pyramid_scale_step,
                                 fy=pyramid_scale_step, interpolation=cv2.INTER_LINEAR)

    if demoire_min_scale and s <= demoire_min_scale:
        # pre-scale image with INTER_AREA method to avoid moire effect
        src_img = cv2.resize(src_img, dsize=None,
                             fx=s / demoire_min_scale, fy=s / demoire_min_scale, interpolation=cv2.INTER_AREA)
        s = demoire_min_scale

    # calc affine transform matrix
    tran_mat = getAffTransMat(s, R, t)
    dst_img = cv2.warpAffine(src_img, tran_mat, dst_img_size,
                             flags=warp_flags, borderMode=warp_border_mode, borderValue=warp_border_val)
    return dst_img, ori_tran_mat


#
# Generate Positive Samples Given Groundtruth, Configuration
#
def GenPosSamples(gt_l, cfg, src_prefix, dst_prefix, save_info, save_bbox, save_anno):
    # parse configuration
    smp_w = cfg['smp_w']
    smp_h = cfg['smp_h']
    gt_rect = np.array(cfg['smp_gt_rect']) * (smp_w, smp_h, smp_w, smp_h)
    xy_wgt = cfg['xy_wgt'] if 'xy_wgt' in cfg else None
    # as for perturbations
    # perturbation setting
    p = cfg['perturbation'] if 'perturbation' in cfg else None
    # perturbation times
    pt = p['times'] if p is not None and 'times' in p else 1
    ft = 2 if p is not None and 'flip' in p and p[
        'flip'] else 1    # flip times
    show_anno = show_step = cfg['show_step'] if 'show_step' in cfg else -1

    dst_fold = os.path.dirname(dst_prefix)
    if not os.path.exists(dst_fold):
        os.makedirs(dst_fold)

    smp_l = []    # sample list
    info_l = []   # infomation list regarding each sample
    bbox_l = []   # bounding box list regarding each sample
    anno_l = []   # annotation list

    # for each image
    for idx, gt in enumerate(gt_l):
        image_key, rects = gt
        #
        # Step 0: load src as grey image
        #
        print 'processing #{}/{}: {}. {} samples generated up to now\t\r'.format(
            idx, len(gt_l), image_key, len(smp_l)),
        if len(rects) > 0:
            src_img = cv2.imread(src_prefix + image_key, 0)
            if src_img is None:
                print 'Failed in loading ', src_prefix + image_key
                continue
        else:
            src_img = None

        # reset anno
        anno = []
        # for each rect
        for rect_ign in rects:
            #
            # Step 1: get src key points
            #
            rect = rect_ign[:4]
            ign = rect_ign[4]
            src_kpt = rect2kpt(*rect)
            # keep as it was in bg anno file
            anno.append(rect_ign)

            if ign > 0:
                # skip due to ignore
                continue

            for t in xrange(pt * ft):
                #
                # Step 2: get dst key points
                #
                if t % ft == 0:
                    l, t, r, b = gt_rect
                else:
                    # flip horizontally
                    r, t, l, b = gt_rect
                dst_kpt = rect2kpt(l, t, r, b)

                if p:
                    # perturb dst kpt
                    scale = randRange(*p['scale']) if 'scale' in p else 1
                    rot_angle = randRange(*p['angle']) if 'angle' in p else 0
                    tranX = randRange(*p['tranX']) if 'tranX' in p else 0
                    tranY = randRange(*p['tranY']) if 'tranY' in p else 0
                    rot_center = (smp_w * 0.5, smp_h * 0.5)
                    # re-generate dst key points
                    dst_kpt = perturbKeyPoints(
                        dst_kpt, scale, rot_center, rot_angle, (tranX, tranY))
                    demoire_min_scale = randRange(
                        *p['demoire_min_scale']) if 'demoire_min_scale' in p else None
                    pyramid_scale_step = randRange(
                        *p['pyramid_scale_step']) if 'pyramid_scale_step' in p else None
                else:
                    demoire_min_scale = pyramid_scale_step = None

                #
                # Step 3: crop image by similarity transform
                #
                smp, aff_mat = cropImageBySimTransGivenKeyPoints(src_img,
                                                                 src_kpt, (
                                                                     smp_w, smp_h), dst_kpt, xy_wgt,
                                                                 demoire_min_scale=demoire_min_scale,
                                                                 pyramid_scale_step=pyramid_scale_step)
                smp_l.append(smp.reshape(1, smp_h, smp_w))
                info_l.append((image_key, rects, aff_mat))

                #
                # Step 4: restore bounding box in the sample
                #
                true_dst_kpt = getAffTransCoords(src_kpt, aff_mat)
                bbox_l.append(kpt2rect(true_dst_kpt))

                #
                # Step 5 (optional): show the sample with gt rect
                #
                if show_step > 0 and len(smp_l) % show_step == 0:
                    smp_rst = cv2.cvtColor(smp, cv2.COLOR_GRAY2BGR)
                    for i in xrange(4):
                        cv2.line(smp_rst, tuple(np.round(true_dst_kpt[i]).astype('int')), tuple(
                            np.round(true_dst_kpt[(i + 1) % 4]).astype('int')), (0, 255, 0))
                    cv2.imshow('smp_img', smp_rst)
                    key = chr(cv2.waitKey(-1) % 256)
                    if key in ['q', 'Q']:
                        # stop showing samples
                        show_step = -1

        if show_anno > 0 and len(anno_l) % show_step == 0 and src_img is not None:
            anno_rst = cv2.cvtColor(src_img, cv2.COLOR_GRAY2BGR)
            for idx, rect in enumerate(anno):
                l, t, r, b, ign = rect[:5]
                cv2.rectangle(anno_rst, (int(l), int(t)), (int(r), int(
                    b)), (0, 255, 255) if ign > 0 else (0, 255, 0))
                if len(rect) > 5:
                    for ridx, ign_reason in enumerate(rect[5]):
                        cv2.putText(anno_rst, ign_reason, (int(l), int(t)-ridx*8),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.3, (0,0,255))

            cv2.imshow('anno_img', anno_rst)
            key = chr(cv2.waitKey(-1) % 256)
            if key in ['q', 'Q']:
                # stop showing samples
                show_anno = -1

        anno_line = os.path.relpath(src_prefix + image_key, dst_fold)
        for rect in anno:
            l, t, r, b, ign = rect[:5]
            anno_line += ' {:.1f} {:.1f} {:.1f} {:.1f} {:d}'.format(
                l, t, r, b, ign)
        anno_l.append(anno_line)

    smps = np.vstack(smp_l)
    fname = dst_prefix + '.smp.npy'
    np.save(fname, smps)
    print '{} saved!'.format(fname)

    avg_smp = smps.mean(axis=0).astype('uint8')
    cv2.imwrite(dst_prefix + '.{}.png'.format(len(smps)), avg_smp)

    if save_bbox:
        bboxes = np.vstack(bbox_l).astype('float32')
        fname = dst_prefix + '.bbox.npy'
        np.save(fname, bboxes)
        print '{} saved!'.format(fname)

    if save_info:
        fname = dst_prefix + '.info.pkl'
        cPickle.dump(info_l, open(fname, 'wb'), -1)
        print '{} saved!'.format(fname)

    if save_anno:
        fname = dst_prefix + '.anno'
        fid = open(fname, 'wt')
        for anno in anno_l:
            print>>fid, anno
        fid.close()
        print '{} saved!'.format(fname)
