import os, sys
import numpy as np
import glob
import cv2


def LoadImageFileNameList(img_fname):
  anno_list = None
  if '*' in img_fname or '?' in img_fname:
    #wildcard in the filename
    img_fname_list = glob.glob(img_fname)
  else:
    ext_name = os.path.splitext(img_fname)[-1]
    if ext_name in ['.lst', '.txt', '.list']:
      #image list file
      base_path = os.path.dirname(img_fname)
      img_fname_list = [os.path.join(base_path, line.strip().split()[0]) for line in open(img_fname)]
    elif ext_name in ['.gt', '.anno']:
      base_path = os.path.dirname(img_fname)
      img_fname_list = []
      anno_list = []
      for line in open(img_fname):
        items = line.strip().split()
        img_fname_list.append(os.path.join(base_path, items[0]))
        anno_list.append(np.array(items[1:], dtype = 'float32').reshape(-1, 5))
    elif ext_name in ['.bmp', '.BMP', '.jpg', '.JPG', '.png', '.PNG']:
      #image file
      img_fname_list = [img_fname]
    else:
      raise ValueError('Unknown type of img_fname {}'.format(img_fname))
  return img_fname_list, anno_list



def TileImagePatches(img_patch_arr, max_canvas_w = 1280, max_canvas_h = 720):
  num, h, w = img_patch_arr.shape[:3]
  max_rows = max_canvas_h / h
  max_cols = max_canvas_w / w
  num = min(num, max_rows * max_cols)
  cols = int(np.sqrt(num * max_canvas_w / max_canvas_h))
  rows = (num + cols - 1) / cols
  if len(img_patch_arr.shape) == 4:
    chan = img_patch_arr.shape[3]
    canvas = np.zeros((rows * h, cols * w, chan), dtype = 'uint8')
  else:
    canvas = np.zeros((rows * h, cols * w), dtype = 'uint8')

  for i in xrange(num):
    r = i / cols
    c = i % cols
    canvas[r*h:(r+1)*h, c*w:(c+1)*w] = img_patch_arr[i]
  return canvas


