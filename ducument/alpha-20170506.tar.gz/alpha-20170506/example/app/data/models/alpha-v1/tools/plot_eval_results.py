# -*- coding: utf-8 -*-
'''
Created on Sep 10, 2016

@author: liangzhujin
'''

import matplotlib
matplotlib.use('Agg')
import os
import sys
import numpy as np
sys.path.append('./')
sys.path.append('../')
import pylab
import argparse
from bisect import bisect_left
from eval import calap

colors_list = ['r', 'g', 'b', 'c', 'm', 'y', 'k']

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        'dst_prefix',
        help='prefix of destination result files')
    parser.add_argument(
        '-f', '--data_files', type=str, nargs='+',
        help='specified the all the data files')
    parser.add_argument(
        '-n', '--name_list', type=str, nargs='+',
        help='legend name for your data')
    parser.add_argument(
        '-p', '--recall_pts', type=float, nargs='+',
        help='legend name for your data')
    args = parser.parse_args()
    return args


def FindClosestNumIndex(num, nums_list):
    pos = bisect_left(nums_list, num)
    if pos == 0:
        return 0
    if pos == len(nums_list):
        return len(nums_list) - 1
    before = nums_list[pos - 1]
    after = nums_list[pos]
    if after - num < num - before: 
        return pos
    else:
        return pos - 1

def PlotData(data_list, dst_prefix, name=None, recall_pts=None):
    dst_dir = os.path.dirname(dst_prefix)
    if not os.path.exists(dst_dir):
        os.makedirs(dst_dir)
    font_size = 10
    pylab.subplots(1, 3, figsize=(30, 10))

    color_ind = -1
    name_ind = 0
    for data in data_list:
        color_ind = color_ind + 1
        if color_ind >= len(colors_list):
            color_ind = 0
        rec = data[:, 0]
        pre = data[:, 1]
        fppi = data[:, 2]
        fp = data[:, 3]

        label_name = str(name_ind)
        if name is not None:
            label_name = name[name_ind]
        
        recall_label = ''
        if recall_pts is not None:
            for vis_recall in recall_pts:
                pos = FindClosestNumIndex(vis_recall, rec)
                
                recall = 100 * (pre[pos] if 0.9 - rec[pos] < 0.01 else 0)
                if recall_label:
                    recall_label += '--{:.2f}'.format(recall)
                else:
                    recall_label = '{:.2f}'.format(recall)
                    
        ap = calap(rec, pre)
        recall_label += '--{:.2f}--{:.2f}--'.format(rec[-1] * 100, ap[0] * 100) + label_name
        
        # pr
        pylab.sca(pylab.subplot(1, 3, 1))
        pylab.plot(rec, pre, color=colors_list[color_ind], label=recall_label)
    
        # fppi
        pylab.sca(pylab.subplot(1, 3, 2))
        pylab.semilogx(fppi, np.array(rec), color=colors_list[color_ind], 
                       label=label_name)
    
        # fp vs recall
        pylab.sca(pylab.subplot(1, 3, 3))
        pylab.plot(fp, np.array(rec), color=colors_list[color_ind],
                   label=label_name)
        name_ind += 1
        
    pylab.sca(pylab.subplot(1, 3, 1))
    pylab.xlabel('recall')
    pylab.ylabel('precision')
    pylab.xlim([0, 1])
    pylab.ylim([0, 1])
    pylab.xticks(np.arange(0., 1, 0.05), fontsize=font_size)
    pylab.yticks(np.arange(0., 1, 0.05), fontsize=font_size)
    pylab.title('pr')
    pylab.legend(loc='lower left', prop={'size': 20})
#     pr_legend = pylab.legend(loc='lower left', prop={'size': 20})
#     pr_label_name_max_len = max([len(t.get_text()) for t in pr_legend.get_texts()])
#     for t in pr_legend.get_texts():
#         t.set_text((('%' + str(pr_label_name_max_len) + 's') % t.get_text()))
    pylab.grid()
    pylab.tight_layout()
    
    pylab.sca(pylab.subplot(1, 3, 2))
    pylab.xlabel('fppi')
    pylab.ylabel('recall')
    pylab.ylim([0, 1])
    pylab.xlim([0.001, 1])
    pylab.xticks(np.power(10, np.arange(-3, 0.1, 0.1)), fontsize=font_size)
    pylab.yticks(np.arange(0., 1.0, 0.05), fontsize=font_size)
    pylab.title('fppi vs recall')
    pylab.legend(loc='upper left', prop={'size': 20})
    pylab.grid()
    pylab.tight_layout()
    
    pylab.sca(pylab.subplot(1, 3, 3))
    pylab.xlabel('fp')
    pylab.ylabel('recall')
    pylab.ylim([0, 1])
    pylab.xlim([0, 200])
    pylab.xticks(np.arange(0, 200, 10), fontsize=font_size)
    pylab.yticks(np.arange(0., 1.0, 0.05), fontsize=font_size)
    pylab.legend(loc='upper left', prop={'size': 20})
    pylab.title('fp vs recall')    
    pylab.grid()
    pylab.tight_layout()
    
    pylab.savefig(dst_prefix + '.pdf')
    pylab.savefig(dst_prefix + '.png')
    
if __name__ == '__main__':
    args = parse_args()
    data = []
    for data_file in args.data_files:
        data.append(np.loadtxt(data_file))
    PlotData(data, args.dst_prefix, args.name_list, args.recall_pts)
