import os, sys
import cv2
import glob
import numpy as np
from time import time
sys.path.append('./')
sys.path.append('../')
import ObjDetectorCPP

def ParseArgDetection(arg_list):
  import argparse
  parser = argparse.ArgumentParser(description='Detect images with a given model.')
  parser.add_argument('model_fname', help='model filename')
  parser.add_argument('image_fname', help='image filename (wildcard * or ? supported) or image list filename.')
  parser.add_argument('-b', '--batch_mode', action='store_true', help='batch mode for detecting many images (default: false)')
  parser.add_argument('--cal_stat', action='store_true', help='whether calculate statistics (used with batch mode -b) (default : false)')
  parser.add_argument('-t', '--thread_num', type=int, default=4, metavar='N', help='thread number in batch mode (default: 4)')
  parser.add_argument('-s', '--scan_scale', type=float, nargs=3, metavar=('START', 'END', 'STEP'), default=(1.0, 0.01, 0.8), help='starting scale, ending scale and scale step in image scanning (default: 1.0 0.01 0.8)')
  parser.add_argument('-o', '--obj_roi', type=float, nargs=4, metavar=('LEFT', 'TOP', 'RIGHT', 'BOTTOM'), default=(0.0, 0.0, 1.0, 1.0), help='object roi in smp window (default: 0.0 0.0 1.0 1.0)')
  parser.add_argument('-p', '--scan_stride', type=int, metavar='STRIDE', default=2, help='scanning stride in x and y axis (default: 2)')
  parser.add_argument('--pad_border', type=int, metavar='border', default=0, help='padding border (default: 0)')
  parser.add_argument('-c', '--conf_thres', type=float, metavar='conf_thres', default=-10000, help='confidence threshold (default: -10000)')
  parser.add_argument('-m', '--merge_overlap', type=float, metavar='OVERLAP', default=0.3, help='overlap threshold for merging detection responses (default: 0.3)')
  parser.add_argument('--min_resp_num', type=float, default=1, help='minimum response number of merged results (default: 1)')
  parser.add_argument('-r', '--bbox_reg', type=str, metavar='reg_model_fname', default=None, help='bounding box regression model')
  return parser.parse_args(arg_list)


def AdjustROI(resps, roi):
  w = resps[:, 2] - resps[:, 0]
  h = resps[:, 3] - resps[:, 1]
  resps[:,0] += w * roi[0]
  resps[:,1] += h * roi[1]
  resps[:,2] -= w * (1.0 - roi[2])
  resps[:,3] -= h * (1.0 - roi[3])
  return resps

def CalcOverlapRatioWithGtRects(det_rect_arr, gt_rect_arr):
  assert det_rect_arr.shape[1] == 4 and gt_rect_arr.shape[1] == 4
  det_num = len(det_rect_arr)
  gt_num = len(gt_rect_arr)
  dd = np.repeat(det_rect_arr, gt_num, axis = 0)
  gg = np.tile(gt_rect_arr, (det_num, 1))
  ii_lt = np.maximum(dd[:,:2], gg[:,:2])
  ii_rb = np.minimum(dd[:,2:], gg[:,2:])
  ii_w = np.maximum(0, ii_rb[:,0] - ii_lt[:,0])
  ii_h = np.maximum(0, ii_rb[:,1] - ii_lt[:,1])
  ii_a = ii_w * ii_h
  dd_a = (dd[:,2] - dd[:,0]) * (dd[:,3] - dd[:,1])
  gg_a = (gg[:,2] - gg[:,0]) * (gg[:,3] - gg[:,1])
  ol = ii_a.astype('float32') / (gg_a + dd_a - ii_a)
  return ol.reshape(det_num, gt_num)

def MergeDetResp_(resp_arr, merge_overlap_thres):
  merged_resp_arr = np.empty((0, 5), dtype = 'float32')

  for resp in resp_arr:
    if len(merged_resp_arr) == 0:
      merge_target_idx = -1
    else:
      ol = CalcOverlapRatioWithGtRects(merged_resp_arr[:, :4], resp[:4].reshape(1, -1))
      if ol.max() >= merge_overlap_thres:
        merge_target_idx = ol.argmax()
      else:
        merge_target_idx = -1

    if merge_target_idx < 0:
      #add a new cluster
      merged_resp_arr = np.vstack([merged_resp_arr, resp])
    else:
      target = merged_resp_arr[merge_target_idx]
      target_rect = target[:4]
      target_num = target[4]
      wgt = float(target_num) / (target_num + resp[4])
      target_rect = target_rect * wgt + resp[:4] * (1 - wgt)
      merged_resp_arr[merge_target_idx][:4] = target_rect
      merged_resp_arr[merge_target_idx][4] += resp[4]
  return merged_resp_arr


def MergeDetResp(raw_resp_arr, merge_overlap_thres):
  resp_arr = np.hstack([raw_resp_arr, np.ones((raw_resp_arr.shape[0], 1), raw_resp_arr.dtype)])
  while True:
    new_resp_arr = MergeDetResp_(resp_arr, merge_overlap_thres)
    assert len(new_resp_arr) <= len(resp_arr)
    if len(new_resp_arr) == len(resp_arr):
      break
    resp_arr = new_resp_arr
  return resp_arr



def DetectImage(det_para):
  from misc import LoadImageFileNameList
  #load detection model
  model = ObjDetectorCPP.SCascadeBoostedDNN()
  if not model.FromString(open(det_para.model_fname).read()):
    raise IOError('Failed in loading model {}'.format(det_para.model_fname))

  #load bounding box regression model
  if det_para.bbox_reg is not None:
    reg_model = ObjDetectorCPP.SCascadeBoostedDNN()
    if not reg_model.FromString(open(det_para.bbox_reg).read()):
      raise IOError('Failed in loading regression model {}'.format(det_para.bbox_reg))
  else:
    reg_model = None

  img_fname_list, anno_list = LoadImageFileNameList(det_para.image_fname)
  base_path = os.path.dirname(det_para.image_fname)

  if len(img_fname_list) == 0:
    print 'image list is empty!'
    return

  if det_para.batch_mode:
    #batch mode for detecting images and print merged detection results
    ObjDetectorCPP.SetThreadNum(det_para.thread_num)
    batch_sz = 64
    if det_para.cal_stat:
      stat_pixel_num_l = []
      stat_wnd_num_l = []
      stat_dt_hist_x = None
      stat_dt_hist_y = None
    for si in xrange(0, len(img_fname_list), batch_sz):
      ei = min(len(img_fname_list), si + batch_sz)
      grey_img_l = []
      for idx in xrange(si, ei):
        img = cv2.imread(img_fname_list[idx])
        if img is None:
          raise ValueError("Failed in loading image {}".format(img_fname_list[idx]))
        grey_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        if det_para.pad_border > 0:
          border = det_para.pad_border
          grey_img_ = grey_img
          grey_img = np.zeros((grey_img_.shape[0] + 2 * border,
            grey_img_.shape[1] + 2 * border), dtype = 'uint8')
          grey_img[border:-border, border:-border] = grey_img_
        grey_img_l.append(grey_img)
      #passed_smp_l, dt_idx_l, passed_smp_conf_l, scan_wnd_num_l, raw_resp_l = ObjDetectorCPP.HardNegativeSampling_MT(grey_img_l, model, True, 2, 1000000, det_para.scan_stride, det_para.scan_scale[0], det_para.scan_scale[1], det_para.scan_scale[2], False, False, True)
      if reg_model is None:
        scan_wnd_num_l, resp_boxes_l, passed_smp_l, dt_hist_x_l, dt_hist_y_l = ObjDetectorCPP.detectImageMT(model, grey_img_l, det_para.scan_stride, det_para.scan_scale[0], det_para.scan_scale[1], det_para.scan_scale[2], False)
      else:
        scan_wnd_num_l, resp_boxes_l, passed_smp_l, dt_hist_x_l, dt_hist_y_l = ObjDetectorCPP.detectImageWithBBoxRegMT(model, reg_model, grey_img_l, det_para.scan_stride, det_para.scan_scale[0], det_para.scan_scale[1], det_para.scan_scale[2], False)

      if det_para.cal_stat:
        stat_pixel_num_l += [img.shape[0] * img.shape[1] for img in grey_img_l]
        stat_wnd_num_l += scan_wnd_num_l
        dt_hist_x = np.array(dt_hist_x_l)
        dt_hist_y = np.array(dt_hist_y_l)
        if stat_dt_hist_x == None:
          stat_dt_hist_x = dt_hist_x
          stat_dt_hist_y = dt_hist_y
        else:
          stat_dt_hist_y += dt_hist_y

      for idx in xrange(si, ei):
        raw_resp = resp_boxes_l[idx - si][:, :4]
        confs = resp_boxes_l[idx - si][:, 4]
        passed_indices = np.where(confs >= det_para.conf_thres)[0]
        raw_resp = raw_resp[passed_indices]
        if det_para.pad_border > 0:
          border = det_para.pad_border
          raw_resp -= [border, border, border, border]
        merged_resp = MergeDetResp(raw_resp, det_para.merge_overlap)
        indices = np.where(merged_resp[:,4] >= det_para.min_resp_num)[0]
        merged_resp = merged_resp[indices]
        raw_resp = AdjustROI(raw_resp, det_para.obj_roi)
        merged_resp = AdjustROI(merged_resp, det_para.obj_roi)
        print '{}'.format(os.path.relpath(img_fname_list[idx], base_path)),
        for resp in merged_resp:
          print (' {:.1f}' * 5).format(*resp),
        print

    if det_para.cal_stat:
      pixel_num = sum(stat_pixel_num_l)
      wnd_num = sum(stat_wnd_num_l)
      dt_num = sum(stat_dt_hist_x * stat_dt_hist_y)
      print 'statistics: image pixels {}, scanned wnd num {}, used dt num {}'.format(
          pixel_num, wnd_num, dt_num)
      print 'per pixel stat:  scanned wnd num {:.3f}, used dt num {:.3f}'.format(
          float(wnd_num) / pixel_num, float(dt_num) / pixel_num)
      print 'dt_hist_x: ', stat_dt_hist_x
      print 'dt_hist_y: ', stat_dt_hist_y
      print 'dt_hist_y_norm: ', stat_dt_hist_y.astype('float') / stat_dt_hist_y.sum()

  else:
    #process single image at a time, showing detection results with image
    idx = 0
    show_merged = True
    show_raw = True
    show_passed_wnd = False
    show_gt = True
    while True:
      img = cv2.imread(img_fname_list[idx])
      grey_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
      if det_para.pad_border > 0:
        border = det_para.pad_border
        grey_img_ = grey_img
        grey_img = np.zeros((grey_img_.shape[0] + 2 * border,
          grey_img_.shape[1] + 2 * border), dtype = 'uint8')
        grey_img[border:-border, border:-border] = grey_img_

      st = time()
      #passed_smp_l, dt_idx_l, passed_smp_conf_l, scan_wnd_num_l, raw_resp_l = ObjDetectorCPP.HardNegativeSampling_MT([grey_img], model, True, 2, 1000000, det_para.scan_stride, det_para.scan_scale[0], det_para.scan_scale[1], det_para.scan_scale[2], show_passed_wnd, False, True)
      if reg_model is None:
        scan_wnd_num_l, resp_boxes_l, passed_smp_l, dt_hist_x_l, dt_hist_y_l = ObjDetectorCPP.detectImageMT(model, [grey_img], det_para.scan_stride, det_para.scan_scale[0], det_para.scan_scale[1], det_para.scan_scale[2], show_passed_wnd)
      else:
        scan_wnd_num_l, resp_boxes_l, passed_smp_l, dt_hist_x_l, dt_hist_y_l = ObjDetectorCPP.detectImageWithBBoxRegMT(model, reg_model, [grey_img], det_para.scan_stride, det_para.scan_scale[0], det_para.scan_scale[1], det_para.scan_scale[2], show_passed_wnd)
      raw_resp = resp_boxes_l[0][:,:4]
      confs = resp_boxes_l[0][:,4]
      passed_indices = np.where(confs >= det_para.conf_thres)[0]
      raw_resp = raw_resp[passed_indices]
      if det_para.pad_border > 0:
        border = det_para.pad_border
        raw_resp -= [border, border, border, border]

      merged_resp = MergeDetResp(raw_resp, det_para.merge_overlap)
      indices = np.where(merged_resp[:,4] >= det_para.min_resp_num)[0]
      merged_resp = merged_resp[indices]
      raw_resp = AdjustROI(raw_resp, det_para.obj_roi)
      merged_resp = AdjustROI(merged_resp, det_para.obj_roi)
      dt_num = sum(np.array(dt_hist_x_l) * np.array(dt_hist_y_l))
      print '#{}/{} {}: scan wnd {}, dt {}, raw resp {}, merged resp {}, time costs {} sec'.format(idx, len(img_fname_list), os.path.relpath(img_fname_list[idx], base_path), scan_wnd_num_l[0], dt_num, len(raw_resp), len(merged_resp), time() - st)
      if show_raw:
        for resp in raw_resp:
          cv2.rectangle(img, (int(resp[0]), int(resp[1])), (int(resp[2]), int(resp[3])), (0, 0, 255), 1)
      if show_merged:
        for resp in merged_resp:
          #cv2.rectangle(img, (int(resp[0]), int(resp[1])), (int(resp[2]), int(resp[3])), (0, 255, 0), 1 + int(np.log1p(resp[4])))
          cv2.rectangle(img, (int(resp[0]), int(resp[1])), (int(resp[2]), int(resp[3])), (0, 255, 0), int(np.power(resp[4], 1.0/3)))
          cv2.putText(img, "{:.0f}".format(resp[4]), (int(resp[0]), int(resp[1])), cv2.FONT_HERSHEY_PLAIN, 2.0, (0, 255, 0))
      if show_gt and anno_list != None:
        for anno in anno_list[idx]:
          cv2.rectangle(img, (int(anno[0]), int(anno[1])), (int(anno[2]), int(anno[3])), (255, 0, 0) if anno[4] > 0 else (255, 255, 0), 1)
      cv2.imshow('img', img)

      if show_passed_wnd:
        from misc import TileImagePatches
        canvas = TileImagePatches(passed_smp_l[0])
        cv2.imshow('passed_wnd', canvas)

      key = chr(cv2.waitKey(-1) % 256)
      if key in ['q', 'Q', chr(27)]:
        break
      elif key in ['=', ' ']:
        idx = min(len(img_fname_list) - 1, idx + 1)
      elif key in ['-']:
        idx = max(0, idx - 1)
      elif key in [']']:
        idx = min(len(img_fname_list) - 1, idx + 10)
      elif key in ['[']:
        idx = max(0, idx - 10)
      elif key in ['\'']:
        idx = min(len(img_fname_list) - 1, idx + 100)
      elif key in [';']:
        idx = max(0, idx - 100)
      elif key in ['m']:
        show_merged = not show_merged
      elif key in ['r']:
        show_raw = not show_raw
      elif key in ['w']:
        show_passed_wnd = not show_passed_wnd
      elif key in ['g']:
        show_gt = not show_gt


if __name__ == '__main__':
  para = ParseArgDetection(sys.argv[1:])
  DetectImage(para)

