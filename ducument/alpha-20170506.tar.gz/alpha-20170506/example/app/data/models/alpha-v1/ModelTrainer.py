##
# Alpha Detection Plus Detector Trainer
##

import os
import sys
import time
import logging
import struct
import cv2
import copy
import numpy as np
import cPickle
import gc
from smp import *
import ObjDetectorCPP
from Model import CascadeBoostedDNN
from ClassifierTrainer import AlphaClassifierTrainer, log, SetLogFileName


def ScreenSamples(smp_arr, cascade_py=None, cascade_cpp_l=None):
    if cascade_cpp_l is not None:
        assert len(cascade_cpp_l) == ObjDetectorCPP.GetThreadNum()
        model_l = cascade_cpp_l
    else:
        from ObjDetectorCPP import ScreeningSamples_CascadeBoostedDNN_MT
        model_str = cascade_py.tostring()
        model_l = []
        for i in xrange(ObjDetectorCPP.GetThreadNum()):
            model = ObjDetectorCPP.SCascadeBoostedDNN()
            model.FromString(model_str)
            model_l.append(model)

    pass_arr, conf_arr, dt_indices_arr = ObjDetectorCPP.ScreeningSamples_CascadeBoostedDNN_MT(
        smp_arr, model_l, True, 2, False)
    return pass_arr, conf_arr


def ScreenAndSelectPassedSamples(smp_arr, cascade_py=None, cascade_cpp_l=None):
    pass_arr, conf_arr = ScreenSamples(smp_arr, cascade_py, cascade_cpp_l)
    passed_indices = np.where(pass_arr > 0)[0]
    return smp_arr[passed_indices], conf_arr[passed_indices]


def ScreenAndSelectPassedSamplesEx(smp_arr, max_sel_num, cascade_py=None, cascade_cpp_l=None):
    passed_smp, passed_conf = ScreenAndSelectPassedSamples(
        smp_arr, cascade_py, cascade_cpp_l)
    if len(passed_smp) > max_sel_num:
        sel_indices = np.random.choice(len(passed_smp), max_sel_num, False)
        sel_indices = np.sort(sel_indices)
        return passed_smp[sel_indices], passed_conf[sel_indices], passed_smp
    else:
        return passed_smp, passed_conf, passed_smp


def LoadSmpFileList(smp_fn_list):
    from glob import glob
    smp_fn_l = []
    for smp_fn in smp_fn_list:
        if '*' in smp_fn or '?' in smp_fn:
            smp_fn_l += sorted(glob(smp_fn))
        else:
            smp_fn_l += [smp_fn]

    smp_list = []
    for smp_fn_ in smp_fn_l:
        ext_fname = os.path.splitext(smp_fn_)[-1]
        if ext_fname == '.smp':
            smps, info = LoadSmpFile(smp_fn_)
        elif ext_fname == '.npy':
            smps = np.load(smp_fn_)
        else:
            raise ValueError('Unknown smp format {}'.format(smp_fn_))
        smp_list.append(smps)
        log.info('{} samples are loaded from {}.'.format(len(smps), smp_fn_))
    smp_arr = np.vstack(smp_list)
    log.info('Totally {} samples are loaded from {}; smp size {}.'.format(
        len(smp_arr), smp_fn_list, smp_arr.shape[1:]))
    return smp_arr


def LoadRect5AnnotationFile(annotation_fn, fname_prefix=None):
    # Rect5 annotation format:
    # image_fname left0 top0 right0 bottom0 conf0 left1 top1 right1 bottom1
    # conf1 ...
    fn_l = []
    gt_l = []
    for line in open(annotation_fn):
        items = line.strip().split()
        fn = fname_prefix + items[0] if fname_prefix else items[0]
        gt = np.array(items[1:], dtype='float').reshape(-1, 5)
        fn_l.append(fn)
        gt_l.append(gt)
    return fn_l, gt_l


def PerturbSamples(raw_smp_arr, dst_w, dst_h, perturb_para):
    from util import GetPerturbedSamples
    if perturb_para is None:
        return raw_smp_arr
    smp_l = []
    for smp_i, smp in enumerate(raw_smp_arr):
        if smp_i % 100 == 0:
            print 'perturbing {}/{}  \r'.format(smp_i, len(raw_smp_arr)),
        for i in xrange(perturb_para['times']):
            nsmp, info = GetPerturbedSamples(
                smp, (dst_w, dst_h), perturb_para, verbose=False)
            if nsmp is not None:
                smp_l.append(nsmp.reshape(1, dst_h, dst_w))

    return np.vstack(smp_l)


def LoadPerturbScreenSamples(smp_fn_list, perturb_para, cascade_py):
        # load samples
    raw_smps = LoadSmpFileList(smp_fn_list)

    if cascade_py:
        ref_w = cascade_py.ref['w']
        ref_h = cascade_py.ref['h']
    else:
        ref_h, ref_w = raw_smps.shape[1:]
    # perturb if needed
    smps = PerturbSamples(
        raw_smps, ref_w, ref_h, perturb_para) if perturb_para else raw_smps

    # screening
    if cascade_py:
        pass_arr, conf_arr = ScreenSamples(smps, cascade_py)
        pass_indices = np.where(pass_arr > 0)[0]
        passed_smps = smps[pass_indices]
        passed_confs = conf_arr[pass_indices]
    else:
        passed_smps = smps
        passed_confs = None

    return raw_smps, smps, passed_smps, passed_confs


def CalcIntersectionVsUnionBetweenDetectionAndGroundtruth(det_rect_arr, gt_rect_arr):
    assert det_rect_arr.shape[1] == 4 and gt_rect_arr.shape[1] == 4
    det_num = len(det_rect_arr)
    gt_num = len(gt_rect_arr)
    dd = np.repeat(det_rect_arr, gt_num, axis=0)
    gg = np.tile(gt_rect_arr, (det_num, 1))
    ii_lt = np.maximum(dd[:, :2], gg[:, :2])
    ii_rb = np.minimum(dd[:, 2:], gg[:, 2:])
    ii_w = np.maximum(0, ii_rb[:, 0] - ii_lt[:, 0])
    ii_h = np.maximum(0, ii_rb[:, 1] - ii_lt[:, 1])
    ii_a = ii_w * ii_h
    dd_a = (dd[:, 2] - dd[:, 0]) * (dd[:, 3] - dd[:, 1])
    gg_a = (gg[:, 2] - gg[:, 0]) * (gg[:, 3] - gg[:, 1])
    ivu = ii_a.astype('float32') / (gg_a + dd_a - ii_a)
    ivd = ii_a.astype('float32') / dd_a
    return ivu.reshape(det_num, gt_num), ivd.reshape(det_num, gt_num)


def HardNegativeSampling(cascade_py,  # cascade model for hard negative sampling
                         # paramters for scanning images
                         xy_step, start_scale, end_scale, scale_step,
                         # background image fname list, ground truth list and
                         # cache fname list
                         bg_fn_l, bg_gt_l, bg_cache_fn_l,
                         # the number of negative smaples you want to collect
                         neg_smp_num,
                         # overlap ratio to remove detections that are too
                         # close to ground truth
                         gt_neg_overlap,
                         bg_perturb_para,  # background image perturbation
                         bg_resp_log_fn,  # detection respose log filename
                         smp_gt_rect=None,    # gt rect (l,t,r,b) in smp window
                         ):

    smp_per_img = int(10 * neg_smp_num / len(bg_fn_l))
    log.info(' smp_per_img {}, bg_fn_l {}, neg_smp_num {}, smp cache {}'.format(
        smp_per_img, len(bg_fn_l), neg_smp_num, 'enabled' if bg_cache_fn_l else 'disabled'))
    log.info(' xy_step {}, start_scale {}, end_scale {}, scale_step {}'.format(
        xy_step, start_scale, end_scale, scale_step))

    try:
        start_scale_lb, start_scale_ub = start_scale
        assert bg_perturb_para is None
        if bg_cache_fn_l is not None:
            log.info('Disable bg cache due to flexible start scale')
            bg_cache_fn_l = None
    except TypeError:
        start_scale_lb = start_scale_ub = start_scale

    try:
        scale_step_lb, scale_step_ub = scale_step
        assert bg_perturb_para is None
        if bg_cache_fn_l is not None:
            log.info('Disable bg cache due to flexible scale_step')
            bg_cache_fn_l = None
    except TypeError:
        scale_step_lb = scale_step_ub = scale_step

    if bg_perturb_para:
        assert bg_cache_fn_l is None
        assert bg_gt_l is None

    # get c++ version cascade
    model_str = cascade_py.tostring()
    model_l = []
    for i in xrange(ObjDetectorCPP.GetThreadNum()):
        model = ObjDetectorCPP.SCascadeBoostedDNN()
        model.FromString(model_str)
        model_l.append(model)

    batch_sz = 256
    smp_l = []
    conf_l = []
    scanned_wnd_num = 0
    passed_wnd_num = 0
    collected_smp_num = 0

    batch_img_l = []
    batch_idx_l = []
    img_i = 0
    if bg_resp_log_fn is not None:
        log_fid = open(bg_resp_log_fn, 'wt')

    while img_i < len(bg_fn_l):
        print 'processing #{}/{}: {}'.format(img_i, len(bg_fn_l), bg_fn_l[img_i])
        if bg_cache_fn_l is not None and os.path.exists(bg_cache_fn_l[img_i]):
            # load samples from cached files
            cache_smps, info = LoadSmpFile(bg_cache_fn_l[img_i])
            wnd_num = int(info)
            selected_smp_arr, selected_conf_arr, passed_smp_arr = ScreenAndSelectPassedSamplesEx(
                cache_smps, smp_per_img, cascade_cpp_l=model_l)
            if len(selected_smp_arr) > 0:
                smp_l.append(selected_smp_arr)
                conf_l.append(selected_conf_arr.reshape(-1, 1))
            scanned_wnd_num += wnd_num
            passed_wnd_num += len(passed_smp_arr)
            collected_smp_num += len(selected_smp_arr)
            # update cache smp file
            if len(passed_smp_arr) < len(cache_smps):
                SaveSmpFile(passed_smp_arr, info, bg_cache_fn_l[img_i])

            print '  #{}/{}: {} collected, {} passed, {} scanned, avg pass rate {:.5g}'.format(img_i, len(bg_fn_l), collected_smp_num, passed_wnd_num, scanned_wnd_num, float(passed_wnd_num) / scanned_wnd_num)

        else:
            # load the image into batch
            try:
                img = cv2.imread(bg_fn_l[img_i], cv2.CV_LOAD_IMAGE_GRAYSCALE)
            except Exception:
                img = None

            if img is None:
                log.info('failed in loading image {}'.format(bg_fn_l[img_i]))
                img_i += 1
                continue

            batch_img_l.append(img)
            batch_idx_l.append(img_i)

        img_i += 1
        if img_i >= len(bg_fn_l) or len(batch_img_l) >= batch_sz:
            # process batch
            max_resp_per_img = 10 * smp_per_img
            start_scale = np.random.rand() * (start_scale_ub - start_scale_lb) + \
                start_scale_lb
            scale_step = np.random.rand() * (scale_step_ub - scale_step_lb) + \
                scale_step_lb
            print 'HardNegativeSampling_MT with start scale {}, scale_step {}'.format(start_scale, scale_step)
            img_patches_l, dt_indices_l, confs_l, wnd_nums_l, det_rect_l = ObjDetectorCPP.HardNegativeSampling_MT(
                batch_img_l, model_l[0], True, 2, max_resp_per_img, xy_step, start_scale, end_scale, scale_step, True, False, True)
            all_wnd_scanned_l = [(xy_step == 1 and len(
                img_patches) < max_resp_per_img) for img_patches in img_patches_l]

            if bg_gt_l is not None:
                # remove detections that are too close to ground truth
                for idx, det_rect in enumerate(det_rect_l):
                    if smp_gt_rect is not None:
                        det_w = det_rect[:, 2] - det_rect[:, 0]
                        det_h = det_rect[:, 3] - det_rect[:, 1]
                        det_rect[:, 0] += det_w * smp_gt_rect[0]
                        det_rect[:, 1] += det_h * smp_gt_rect[1]
                        det_rect[:, 2] -= det_w * (1.0 - smp_gt_rect[2])
                        det_rect[:, 3] -= det_h * (1.0 - smp_gt_rect[3])
                    gt_rect = bg_gt_l[batch_idx_l[idx]]
                    if len(gt_rect) > 0 and len(det_rect) > 0:
                        ivu, ivd = CalcIntersectionVsUnionBetweenDetectionAndGroundtruth(
                            det_rect[:, :4], gt_rect[:, :4])
                        gt_ign = gt_rect[:, 4] > 0
                        ivud = ivu * (~gt_ign) + ivd * gt_ign
                        max_ivud = ivud.max(axis=1)
                        is_hardnegs = max_ivud < gt_neg_overlap
                        keep_indices = np.where(is_hardnegs)[0]
                        num_removed = len(max_ivud) - len(keep_indices)
                        # dump detection responses into log file
                        if bg_resp_log_fn is not None:
                            log_fid.write('%s' % (bg_fn_l[batch_idx_l[idx]]))
                            for one_rect, is_hardneg in zip(det_rect, is_hardnegs):
                                log_fid.write(' %.2f %.2f %.2f %.2f %d' % (
                                    one_rect[0], one_rect[1], one_rect[2], one_rect[3], 0 if is_hardneg else 1))
                            for one_gt in gt_rect:
                                log_fid.write(' %.2f %.2f %.2f %.2f %d' % (
                                    one_gt[0], one_gt[1], one_gt[2], one_gt[3], 2 if one_gt[4] < 1 else 3))
                            log_fid.write("\n")
                        if num_removed > 0:
                            print '{} det rect removed as they are too close to groundtruth'.format(num_removed)
                        img_patches_l[idx] = img_patches_l[idx][keep_indices]
                        confs_l[idx] = confs_l[idx][keep_indices]
                        det_rect_l[idx] = det_rect_l[idx][keep_indices]
                    else:
                        # dump detection responses into log file
                        if bg_resp_log_fn is not None:
                            log_fid.write('%s' % (bg_fn_l[batch_idx_l[idx]]))
                            # 5th column: 0-det,hardneg, 1-det,not hardneg,
                            # 2-gt,not ignore, 3-gt,ignore
                            for one_rect in det_rect:
                                log_fid.write(' %.2f %.2f %.2f %.2f %d' % (
                                    one_rect[0], one_rect[1], one_rect[2], one_rect[3], 0))
                            for one_gt in gt_rect:
                                log_fid.write(' %.2f %.2f %.2f %.2f %d' % (
                                    one_gt[0], one_gt[1], one_gt[2], one_gt[3], 2 if one_gt[4] < 1 else 3))
                            log_fid.write("\n")
            if bg_cache_fn_l is not None:
                # dump collected samples into cache files
                for idx, img_patches in enumerate(img_patches_l):
                    if all_wnd_scanned_l[idx]:
                        cache_fn = bg_cache_fn_l[batch_idx_l[idx]]
                        cache_path = os.path.dirname(cache_fn)
                        if not os.path.exists(cache_path):
                            os.makedirs(cache_path)
                        SaveSmpFile(
                            img_patches, '{}'.format(wnd_nums_l[idx]), cache_fn)

            # screen collected samples
            for idx, image_patches in enumerate(img_patches_l):
                selected_smp_arr, selected_conf_arr, passed_smp_arr = ScreenAndSelectPassedSamplesEx(
                    image_patches, smp_per_img, cascade_cpp_l=model_l)
                if len(selected_smp_arr) > 0:
                    smp_l.append(selected_smp_arr)
                    conf_l.append(selected_conf_arr.reshape(-1, 1))
                scanned_wnd_num += wnd_nums_l[idx]
                passed_wnd_num += len(passed_smp_arr)
                collected_smp_num += len(selected_smp_arr)

            # clear batch
            batch_img_l = []
            batch_idx_l = []

            print '  #{}/{}: {} collected, {} passed, {} scanned, avg pass rate {:.5g}'.format(img_i, len(bg_fn_l), collected_smp_num, passed_wnd_num, scanned_wnd_num, float(passed_wnd_num) / scanned_wnd_num)

        if collected_smp_num >= neg_smp_num:
            break

    log.info('  HardNegativeSampling done: image scanned {}/{}, {} collected, {} passed, {} scanned, avg pass rate {:.5g}'.format(img_i,
                                                                                                                                  len(bg_fn_l), collected_smp_num, passed_wnd_num, scanned_wnd_num, float(passed_wnd_num) / scanned_wnd_num))

    return np.vstack(smp_l), np.vstack(conf_l)


def LearnConfConverterAndConvert(pos_confs, neg_confs, conf_ub=1E10, disable_scale=False):

    def CalConfGradHess(pos_confs, neg_confs, x, conf_ub):
            # for pos
        pos_sat_ioi = np.where(pos_confs >= conf_ub)[0]
        pn = pos_confs.size
        norm_factor = 0.5 / (pn * np.log1p(1))
        exp_nmargin = np.exp(- np.minimum(conf_ub, pos_confs)
                             * x[1] - x[0]).astype('float')
        pos_loss = norm_factor * np.log1p(exp_nmargin)
        pos_grad = - norm_factor * exp_nmargin / (1 + exp_nmargin)
        pos_grad[pos_sat_ioi] = 0
        exp_margin = 1.0 / exp_nmargin
        pos_hess = norm_factor * exp_margin / (1 + exp_margin) ** 2
        pos_hess[pos_sat_ioi] = 0

        # for neg
        neg_sat_ioi = np.where(neg_confs >= conf_ub)[0]
        nn = neg_confs.size
        norm_factor = 0.5 / (nn * np.log1p(1))
        exp_nmargin = np.exp(
            (np.minimum(neg_confs, conf_ub) * x[1] + x[0]).astype('float'))
        neg_loss = norm_factor * np.log1p(exp_nmargin)
        neg_grad = norm_factor * exp_nmargin / (1 + exp_nmargin)
        neg_grad[neg_sat_ioi] = 0
        exp_margin = 1.0 / exp_nmargin
        neg_hess = norm_factor * exp_margin / (1 + exp_margin) ** 2
        neg_hess[neg_sat_ioi] = 0

        # compute loss and grad hess
        grad_vec = np.zeros(2)
        hess_mat = np.zeros((2, 2))

        grad_vec[0] = pos_grad.sum() + neg_grad.sum()
        grad_vec[1] = (pos_grad * pos_confs).sum() + \
            (neg_grad * neg_confs).sum()
        hess_mat[0, 0] = pos_hess.sum() + neg_hess.sum()
        hess_mat[0, 1] = hess_mat[1, 0] = (
            pos_hess * pos_confs).sum() + (neg_hess * neg_confs).sum()
        hess_mat[1, 1] = (pos_hess * pos_confs**2).sum() + \
            (neg_hess * neg_confs**2).sum()

        loss = pos_loss.sum() + neg_loss.sum()

        return loss, grad_vec, hess_mat

    x = np.zeros(2)
    if disable_scale:
        x[1] = 1
    min_loss = prev_loss = 1E10
    opt_x = None
    for R in range(30):
        loss, grad_vec, hess_mat = CalConfGradHess(
            pos_confs, neg_confs, x, conf_ub)
        print 'scale {}, offset {}, conf_ub {}, loss {}'.format(x[1], x[0], conf_ub, loss)
        if loss < min_loss - 1E-10:
            min_loss = loss
            opt_x = x
        else:
            break

        prev_loss = loss

        if disable_scale:
            x[0] -= grad_vec[0] / hess_mat[0, 0]
        else:
            x = x - np.dot(grad_vec, np.linalg.inv(hess_mat))

    new_pos_confs = np.minimum(pos_confs * opt_x[1] + opt_x[0], conf_ub)
    new_neg_confs = np.minimum(neg_confs * opt_x[1] + opt_x[0], conf_ub)

    log.info('conf converter: scale {}, offset {}, conf_ub {}, pos conf max {} -> {},  neg confmax {} -> {}'.format(
        opt_x[1], opt_x[0], conf_ub, pos_confs.max(), new_pos_confs.max(), neg_confs.max(), new_neg_confs.max()))

    return {'scale': opt_x[1], 'offset': opt_x[0], 'conf_ub': conf_ub}, new_pos_confs, new_neg_confs


##########################################################################

class AlphaModelTrainer(object):

    def __init__(self, cfg):
        self.cfg = cfg
        workplace = cfg['workplace']
        if not os.path.exists(workplace):
            os.makedirs(workplace)
        log_fn = os.path.join(workplace, cfg['log_fname'])
        SetLogFileName(log_fn)
        log.info(cfg)
        ObjDetectorCPP.init_cuda(self.cfg['boosting_cfg']['device'], 2)

    def CollectPosSmp(self, cascade_py):
        log.info('\nStart collecting positive samples........')
        raw_smps = LoadSmpFileList(self.cfg['pos_data_fn_list'])
        ref_w = cascade_py.ref['w']
        ref_h = cascade_py.ref['h']
        # perturb if needed
        # keep using same seed
        # np.random.seed(0)
        smps = PerturbSamples(raw_smps, ref_w, ref_h, self.cfg[
                              'pos_perturb_para']) if 'pos_perturb_para' in self.cfg else raw_smps
        # screening
        passed_smps, passed_confs = ScreenAndSelectPassedSamples(
            smps, cascade_py)
        log.info('raw samples {}, perturbed {}, passed {}, pass rate {}'.format(
            raw_smps.shape, smps.shape, passed_smps.shape, float(len(passed_smps)) / len(smps)))
        return passed_smps, passed_confs

    def CollectNegSmp(self, cascade_py):
        lv_i = cascade_py.get_layer_num()

        extr_lv_val = lambda x: x(lv_i) if hasattr(x, '__call__') else x
        # the ratio of too hard negative samples in all negative samples, possible to be outliers
        too_hard_neg_ratio = extr_lv_val(self.cfg['too_hard_neg_ratio']) if 'too_hard_neg_ratio' in self.cfg else 0
        # accept rate of too hard negative samples
        too_hard_neg_accept_rate = extr_lv_val(self.cfg['too_hard_neg_accept_rate']) if 'too_hard_neg_accept_rate' in self.cfg else 1

        if lv_i == 0 and 'neg_data_fn_list' in self.cfg and self.cfg['neg_data_fn_list'] is not None:
            # collect negative samples from given smp files
            log.info(
                '\nStart collecting negative samples from given smp files........')
            ref_w = cascade_py.ref['w']
            ref_h = cascade_py.ref['h']
            raw_smps = LoadSmpFileList(self.cfg['neg_data_fn_list'])
            smps = PerturbSamples(raw_smps, ref_w, ref_h, self.cfg[
                                  'neg_perturb_para']) if 'neg_perturb_para' in self.cfg else raw_smps
            confs = None

        else:
            # collect from background images
            log.info(
                '\nStart collecting negative samples from background images.........')
            neg_smp_num = self.cfg['bg_neg_smp_num']
            gt_neg_overlap = self.cfg['bg_gt_neg_overlap']
            # set scanning para by heuristics
            xy_step = self.cfg['bg_scan_xy_step']
            scale_step = self.cfg['bg_scan_scale_step']
            start_scale = self.cfg['bg_scan_starting_scale']
            end_scale = self.cfg['bg_scan_ending_scale']
            smp_gt_rect = self.cfg['boosting_cfg'][
                'smp_gt_rect'] if 'smp_gt_rect' in self.cfg['boosting_cfg'] else None
            if hasattr(xy_step, '__call__'):
                xy_step = xy_step(lv_i)
            if hasattr(scale_step, '__call__'):
                scale_step = scale_step(lv_i)
            if hasattr(start_scale, '__call__'):
                start_scale = start_scale(lv_i)

            bg_perturb_para = self.cfg[
                'bg_perturb_para'] if 'bg_perturb_para' in self.cfg else None

            bg_fn_l = []
            bg_gt_l = []
            bg_cache_fn_l = []
            cache_smp_fold = os.path.join(self.cfg['workplace'], 'data/')
            for lst_fn in self.cfg['bg_img_list_fn']:
                base_path = os.path.dirname(lst_fn)
                fn_l, gt_l = LoadRect5AnnotationFile(lst_fn, base_path + '/')
                bg_fn_l += fn_l
                bg_gt_l += gt_l
                bg_cache_fn_l += [os.path.join(
                    cache_smp_fold, os.path.relpath(fn, base_path)) + '.smp' for fn in fn_l]

            # get background detection response log fname if set
            bg_resp_log_fn = None
            if 'bg_resp_log_fn' in self.cfg and self.cfg['bg_resp_log_fn'] is not None:
                if isinstance(self.cfg['bg_resp_log_fn'], str):
                    bg_resp_log_fn = os.path.join(
                        self.cfg['workplace'], self.cfg['bg_resp_log_fn'])
                else:
                    bg_resp_log_fn = os.path.join(
                        self.cfg['workplace'], self.cfg['bg_resp_log_fn'](lv_i))

            # shuffle lists
            shuffle_indices = np.random.permutation(len(bg_fn_l))
            bg_fn_l = [bg_fn_l[i] for i in shuffle_indices]
            bg_gt_l = [bg_gt_l[i] for i in shuffle_indices]
            bg_cache_fn_l = [bg_cache_fn_l[i] for i in shuffle_indices]

            if bg_perturb_para is not None or xy_step > 1 or bg_resp_log_fn is not None:
                bg_cache_fn_l = None


            neg_smp_num_ = int(neg_smp_num / (1 - too_hard_neg_ratio * (1 - too_hard_neg_accept_rate)))

            # collecting samples
            smps, confs = HardNegativeSampling(cascade_py,
                            xy_step, start_scale, end_scale, scale_step,
                            bg_fn_l, bg_gt_l, bg_cache_fn_l,
                            neg_smp_num_,
                            gt_neg_overlap, bg_perturb_para,
                            bg_resp_log_fn, smp_gt_rect)


        # screening
        passed_smps, passed_confs = ScreenAndSelectPassedSamples(
            smps, cascade_py)
        assert len(passed_smps) == len(smps)

        # reject some of too hard negatives as they might be outliers or missed labels
        if too_hard_neg_ratio != 0 and too_hard_neg_accept_rate < 1:
            si = np.argsort(passed_confs)
            too_hard_num = len(passed_confs) * too_hard_neg_ratio
            thres = passed_confs[si[-too_hard_num]]
            too_hard_si = np.where(passed_confs >= thres)[0]
            reject_num = too_hard_num * (1 - too_hard_neg_accept_rate)
            np.random.shuffle(too_hard_si)
            rejected_si = sorted(too_hard_si[:reject_num])
            accepted_si = np.setdiff1d(np.arange(len(passed_confs)), rejected_si)
            accepted_smps = passed_smps[accepted_si]
            accepted_confs = passed_confs[accepted_si]
            rejected_smps = passed_smps[rejected_si]
            rejected_confs = passed_confs[rejected_si]
            log.info('too hard neg ratio {}, accept rate {}, conf thres {}'.format(
              too_hard_neg_ratio, too_hard_neg_accept_rate, thres))
            log.info('out of all collected neg smp, {} rejected, {} accepted'.format(
              len(rejected_si), len(accepted_si)))
            log.info('rejected conf {}'.format(sorted(rejected_confs)))
        else:
            accepted_smps = passed_smps
            accepted_confs = passed_confs
            rejected_smps = None
            rejected_confs = None

        return accepted_smps, accepted_confs, rejected_smps, rejected_confs


    def AddDecisionTrees(self, cascade_py, WCs, opt_thres, conf_conv):
        ret = copy.deepcopy(cascade_py)

        # add decision trees
        lut_l = []
        for WC in WCs:
            dt = {'modes': WC['modes'],
                  'pixels': WC['pixels'],
                  'biases': WC['biases'],
                  }
            if WC['bdt_type'] == 'naive':
                dt['dt_type'] = 3
            elif WC['bdt_type'] == 'balanced':
                dt['dt_type'] = 2
            else:
                raise ValueError("unkonwn bdt type {}".format(WC['bdt_type']))

            ret.DTs.append(dt)
            lut = WC['lut'].reshape(-1, 1)
            lut_l.append(lut)

        # add boosted dnn
        layer_agg_lut = {'act_type': -1,
                         'luts': lut_l
                         }
        layers_fc = []
        bd = {'layer_agg_lut': layer_agg_lut,
              'layers_fc': layers_fc,
              }
        ret.boosted_DNNs.append(bd)

        # add check points
        indices = ret.check_points['indices']
        thresholds = ret.check_points['thresholds']
        indices = np.resize(indices, indices.size + 1)
        thresholds = np.resize(thresholds, thresholds.size + 1)
        indices[-1] = len(WCs) if indices.size == 1 else indices[-2] + len(WCs)
        thresholds[-1] = opt_thres

        ret.check_points['indices'] = indices
        ret.check_points['thresholds'] = thresholds

        # add confidence convertor
        ret.conf_convs += [conf_conv['scale'],
                           conf_conv['offset'], conf_conv['conf_ub']]

        return ret

    def Learn(self):
        cfg = self.cfg
        bcfg = cfg['boosting_cfg']
        # set thread number of c++ module
        if 'thread_num' in cfg:
            ObjDetectorCPP.SetThreadNum(cfg['thread_num'])

        if 'bg_Nyquist_freq_ratio' in cfg:
            ObjDetectorCPP.setNyquistFreqRatio(cfg['bg_Nyquist_freq_ratio'])

        if 'bg_pad_border' in cfg:
            ObjDetectorCPP.setPadBorder(cfg['bg_pad_border'])

        # locate the last layer for resuming cascade training
        cascade_fn_tmpl = cfg['cascade_fn_tmpl']
        lv_i = 0
        workplace = cfg['workplace']
        while os.path.exists(os.path.join(workplace, cascade_fn_tmpl.format(lv_i))):
            lv_i += 1

        while lv_i < cfg['max_layer_num']:
            #
            # Step 1: initialize cascade model
            #
            if lv_i == 0:
                # create an empty cascade with only reference window size,
                # scale and channel types specified
                cascade_py = CascadeBoostedDNN.empty_cascade(bcfg['ref_w'], bcfg['ref_h'],
                                                             bcfg['starting_scale'], bcfg['scale_num'], bcfg['chan_types'])

            else:
                # load latest trained cascade model
                cascade_fn = os.path.join(
                    workplace, cascade_fn_tmpl.format(lv_i - 1))
                cascade_py = CascadeBoostedDNN()
                if not cascade_py.fromstring(open(cascade_fn, 'r').read()):
                    raise IOError('failed in loading {}'.format(cascade_fn))
                log.info(
                    'Latest existing cascade {} (lv {}) loaded'.format(cascade_fn, lv_i - 1))

            #
            # Step 2: collect data for boosting decision trees
            #
            neg_smp, neg_conf, too_hard_neg_smp, too_hard_neg_conf = self.CollectNegSmp(cascade_py)
            pos_smp, pos_conf = self.CollectPosSmp(cascade_py)

            # show smp examples
            if 'show_smp_examples' in self.cfg and self.cfg['show_smp_examples']:
                def randomTile(smps):
                    rows, cols = 20, 32
                    smp_h, smp_w = smps.shape[1:]
                    example_img = np.zeros(
                        (rows * smp_h, cols * smp_w), dtype='uint8')
                    if len(smps) > rows * cols:
                      for idx, si in enumerate(np.random.choice(len(smps), rows * cols, False)):
                          r = idx / cols
                          c = idx % cols
                          example_img[
                              r * smp_h: (r + 1) * smp_h, c * smp_w: (c + 1) * smp_w] = smps[si]
                    else:
                      for idx, smp in enumerate(smps):
                          r = idx / cols
                          c = idx % cols
                          example_img[
                              r * smp_h: (r + 1) * smp_h, c * smp_w: (c + 1) * smp_w] = smps[idx]
                    return example_img

                pos_smp_example = randomTile(pos_smp)
                cv2.imwrite(
                    workplace + '/pos_smp_example.lv{:02d}.png'.format(lv_i), pos_smp_example)
                neg_smp_example = randomTile(neg_smp)
                cv2.imwrite(
                    workplace + '/neg_smp_example.lv{:02d}.png'.format(lv_i), neg_smp_example)

                if too_hard_neg_smp is not None:
                  too_hard_neg_smp_example = randomTile(too_hard_neg_smp)
                  cv2.imwrite(
                      workplace + '/too_hard_neg_smp_example.lv{:02d}.png'.format(lv_i),
                      too_hard_neg_smp_example)

            #cPickle.dump({  'pos_smp' : pos_smp,
            #                'pos_conf' : pos_conf,
            #                'neg_smp' : neg_smp,
            #                'neg_conf' : neg_conf},
            #                open('smp.pkl', 'wb'), -1)

            # dump smp files if needed
            if 'pos_smp_fn_tmpl' in cfg:
                SaveSmpFile(pos_smp, None, os.path.join(
                    workplace, cfg['pos_smp_fn_tmpl'].format(lv_i)))
            if 'neg_smp_fn_tmpl' in cfg:
                SaveSmpFile(neg_smp, None, os.path.join(
                    workplace, cfg['neg_smp_fn_tmpl'].format(lv_i)))

            #
            # Step 3.1: learn a linear convertor for confidence calculated by previous layer
            #
            if lv_i > 0:
                conf_ub = self.cfg[
                    'conf_ub'] if 'conf_ub' in self.cfg else 1E10
                fix_point_bits = self.cfg[
                    'cum_fix_point_bits'] if 'cum_fix_point_bits' in self.cfg else -1
                conf_conv, new_pos_conf, new_all_neg_conf = LearnConfConverterAndConvert(
                    pos_conf, neg_conf, conf_ub, disable_scale=fix_point_bits > 1)
                if fix_point_bits > 1:
                    N = 1 << fix_point_bits
                    conf_conv['offset'] = round(conf_conv['offset'] * N) / N
                    assert conf_conv['scale'] == 1
            else:
                conf_conv = {'scale': 0, 'offset': 0, 'conf_ub': 0}

            log.info('conf_conv: scale {}, offset {}, ub {}'.format(
                conf_conv['scale'], conf_conv['offset'], conf_conv['conf_ub']))

            #
            # Step 3.2: boosting decision trees
            #
            extr_lv_val = lambda x: x(lv_i) if hasattr(x, '__call__') else x
            boosting_cfg = dict(cfg['boosting_cfg'])
            boosting_cfg['target_false_neg_rate'] = extr_lv_val(
                cfg['target_false_neg_rate'])
            boosting_cfg['target_false_pos_rate'] = extr_lv_val(
                cfg['target_false_pos_rate'])
            boosting_cfg['threshold_false_neg_weight'] = extr_lv_val(
                cfg['threshold_false_neg_weight'])
            boosting_cfg['max_bdt_num'] = extr_lv_val(cfg['max_bdt_num'])
            WCs = []
            # concatenate samples
            samples = np.vstack([pos_smp, neg_smp])
            labels = np.empty((len(samples), 1), dtype='float32')
            labels[:len(pos_smp)] = 1
            labels[len(pos_smp):] = -1
            pos_weights = 0.5 / \
                len(pos_smp) * np.ones((len(pos_smp), 1), dtype='float32')
            neg_weights = 0.5 / \
                len(neg_smp) * np.ones((len(neg_smp), 1), dtype='float32')
            weights = np.vstack([pos_weights, neg_weights])
            # get initial conf
            pos_init_outputs = pos_conf.astype(dtype='float32').reshape(-1, 1)
            neg_init_outputs = neg_conf.astype(dtype='float32').reshape(-1, 1)
            init_outputs = np.vstack([pos_init_outputs, neg_init_outputs])
            # apply linear conversion
            init_outputs = np.minimum(
                conf_conv['scale'] * init_outputs + conf_conv['offset'], conf_conv['conf_ub'])
            # manully delete unused smp data
            del pos_smp, neg_smp
            gc.collect()
            log.info("Initializing classifier learner....")
            learner = AlphaClassifierTrainer(
                boosting_cfg, samples, labels, weights, init_outputs)
            WCs, opt_thres = learner.LearnBoostedBDT(lv_i, WCs)

            # add the learned decision trees into cascade model, here we set a
            # low opt_thres in favor of the coming data collection for dnn
            # training
            cascade_py = self.AddDecisionTrees(
                cascade_py, WCs, opt_thres=opt_thres, conf_conv=conf_conv)

            # save model file
            cascade_fn = os.path.join(workplace, cascade_fn_tmpl.format(lv_i))
            open(cascade_fn, 'w').write(cascade_py.tostring())
            log.info('cascade is saved to {}'.format(cascade_fn))
            lv_i += 1
            del learner
            gc.collect()
