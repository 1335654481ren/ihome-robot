import os
import sys
import numpy as np
import cv2
from scipy.misc import imresize
from scipy.misc import imsave
from smp import LoadSmpFile


def uniform_sampling(score, num):
    m1 = score.min()
    m2 = score.max()
    idx = np.argsort(score)[::-1]
    score_sorted = np.sort(score)[::-1]
    seed = np.sort((np.random.rand(num) * (m2 - m1) + m1))[::-1]
    sampled_idx = []
    k = 0
    for i, s in enumerate(score_sorted):
        if k >= num:
            break
        if s < seed[k]:
            sampled_idx.append(idx[i])
            k += 1
    return sampled_idx


def pad_img(img, border):
    h = img.height
    w = img.width
    img = np.fromstring(img.tostring(), dtype=np.uint8)
    img = img.reshape(h, w)
    n_img = np.zeros((h + 2 * border, w + 2 * border), img.dtype)
    n_img[border:-border, border:-border] = img
    return n_img


def overlap(b, bbgt_l):
    ov = 0
    nnbox = None
    for bbgt in bbgt_l:
        bi = [max(b[0], bbgt[0]), max(b[1], bbgt[1]), min(
            b[2], bbgt[2]), min(b[3], bbgt[3])]
        iw = bi[2] - bi[0] + 1
        ih = bi[3] - bi[1] + 1
        if iw > 0 and ih > 0:
            ua = (b[2] - b[0] + 1) * (b[3] - b[1] + 1) + \
                (bbgt[2] - bbgt[0] + 1) * (bbgt[3] - bbgt[1] + 1) - \
                iw * ih
            if ov < iw * ih / ua:
                ov = iw * ih / ua
                nnbox = bbgt
    return ov, nnbox


def crop(im, x1, y1, x2, y2):
    if len(im.shape) > 2:
        out = nyzeros((y2 - y1, x2 - x1, im.shape[2]), dtype=im.dtype)
    else:
        out = np.zeros((y2 - y1, x2 - x1), dtype=im.dtype)

    h = im.shape[0]
    w = im.shape[1]
    srcx1 = max(x1, 0)
    srcx2 = min(x2, w)
    srcy1 = max(y1, 0)
    srcy2 = min(y2, h)

    dstx1 = 0 if x1 > 0 else -x1
    dsty1 = 0 if y1 > 0 else -y1
    dstx2 = x2 - x1 if x2 <= w else w - x2
    dsty2 = y2 - y1 if y2 <= h else h - y2

    if len(im.shape) > 2:
        out[dsty1:dsty2, dstx1:dstx2, :] = im[srcy1:srcy2, srcx1:srcx2, :]
    else:
        out[dsty1:dsty2, dstx1:dstx2] = im[srcy1:srcy2, srcx1:srcx2]
    return out


def extract_blobs(im, boxes, ratio, fsize):
    x1, y1, x2, y2 = boxes
    w = (x2 - x1 + 1) / 2.0
    h = (y2 - y1 + 1) / 2.0
    cx = (x2 + x1 + 1) / 2.0
    cy = (y2 + y1 + 1) / 2.0
    patch = crop(im, int(cx - w * ratio), int(cy - h * ratio),
                 int(cx + w * ratio), int(cy + h * ratio))
    smp = imresize(patch, (fsize, fsize))
    return smp


def shuffle_data_and_alignment(data, label, conf, mini_batch):
    data, label, conf = shuffle_data(data, label, conf)

    num128 = data.shape[0] / mini_batch * mini_batch
    data = data[0:num128]
    label = label[0:num128]
    conf = conf[0:num128]

    data = np.float32(data.reshape(data.shape[0], data.shape[1], 1, 1))
    label = np.float32(label.reshape(label.shape[0], 1, 1, 1))
    conf = np.float32(conf.reshape(conf.shape[0], conf.shape[1], 1, 1))
    return data, label, conf


def shuffle_data(data, label, conf=None):
    num = range(0, data.shape[0])
    np.random.shuffle(num)
    data = data[num]
    label = label[num]
    if conf is None:
        return data, label
    else:
        conf = conf[num]
        return data, label, conf


def indices2feat(indices, dims):
    dim = sum(dims)
    feat = np.zeros((indices.shape[0], dim), dtype=np.float32)
    for j, id in enumerate(indices):
        k = 0
        for i, d in enumerate(dims):
            feat[j, k + id[i]] = 1
            k += d
    return feat


def crop_border(smp, border, random=False, flip=False, rotation=0):
    assert(smp.shape[1] > 2 * border + 1)
    assert(smp.shape[2] > 2 * border + 1)
    inner_size_height = smp.shape[1] - 2 * border
    inner_size_width = smp.shape[2] - 2 * border
    if random:
        croped = np.zeros(
            (smp.shape[0], inner_size_height, inner_size_width), dtype=smp.dtype)
        for i, s in enumerate(smp):
            if rotation > 0:
                # random rotate and get valid patch
                # please pay attention to the rotation angle that size of valid
                # patch MUST larger than inner size
                pass
            h = s.shape[0]
            w = s.shape[1]
            left = np.random.randint(0, h - inner_size_height)
            top = np.random.randint(0, w - inner_size_width)
            croped[i, :, :] = s[
                top:top + inner_size_height, left:left + inner_size_width]
            if flip and np.random.randint(0, 2) == 1:
                croped[i, :, :] = croped[i, :, ::-1]
        return croped

    else:
        return smp[:, border:-border, border:-border]


def GetPerturbedSamples(src_img, dst_sz, para, verbose=False):
    src_h, src_w = src_img.shape
    if dst_sz is None:
        dst_w, dst_h = src_w, src_h
    else:
        dst_w, dst_h = dst_sz

    info = {}

    if 'geo_tran' not in para or para['geo_tran']:
        cx = 0.5 * (src_w - 1)
        cy = 0.5 * (src_h - 1)
        rs_low, rs_high = para['rand_scale']
        ra_low, ra_high = para['rand_angel']
        rl_low, rl_high = para['rand_location']
        scale = np.random.rand() * (rs_high - rs_low) + rs_low
        angel = np.random.rand() * (ra_high - ra_low) + ra_low
        rot_mat = cv2.getRotationMatrix2D((cx, cy), angel, scale)
        rot_mat[:, 2] += np.random.rand(2) * (rl_high - rl_low) + rl_low \
            + (0.5 * (dst_w - 1) - cx, 0.5 * (dst_h - 1) - cy)
        dst_img = cv2.warpAffine(
            src_img, rot_mat, (dst_w, dst_h), borderMode=cv2.BORDER_REPLICATE)
        info['rot_mat'] = rot_mat
    else:
        dst_img = src_img

    if 'rand_gaussian_blur_sigma' in para and para['rand_gaussian_blur_sigma'] > 0:
        gaussian_blur_sigma = np.abs(
            np.random.randn() * para['rand_gaussian_blur_sigma'])
        dst_img = cv2.GaussianBlur(dst_img, (0, 0), gaussian_blur_sigma)
        info['gaussian_blur_sigma'] = gaussian_blur_sigma

    if 'randn_white_noise' in para:
        randn_white_noise = np.random.randn(
            *dst_img.shape) * para['randn_white_noise']
        dst_img = np.clip(dst_img + randn_white_noise, 0, 255).astype('uint8')
        info['randn_white_noise'] = randn_white_noise

    if 'mean_std_norm' in para:
        p = para['mean_std_norm']
        mean = dst_img.mean()
        std = dst_img.std()
        new_mean = np.clip(
            p['mean'] + np.random.randn() * p['randn_mean'], 0, 255)
        new_std = np.clip(
            p['std'] + np.random.randn() * p['randn_std'], 5, 255)
        dst_img = (dst_img - mean) * (new_std / std) + new_mean
        dst_img = np.clip(dst_img, 0, 255).astype('uint8')
        info['new_mean'] = new_mean
        info['new_std'] = new_std

    if verbose:
        cv2.imshow('img', dst_img)
        print '{} -> {}, {} -> {}'.format(mean, new_mean, std, new_std)
        cv2.waitKey(-1)

    return dst_img, info


def OldModel2NewModel(old_model_fn, new_model_fn):
    om = Cascade()
    om.fromstring(open(old_model_fn).read())

    ref = {'w': om.ref_w,
           'h': om.ref_h,
           'start_scale': 0,
           'end_scale': om.ref_scale,
           'chan_types': om.chan_types,
           }

    indices = np.cumsum([len(BC['WCs']) for BC in om.BCs])
    thresholds = np.array([BC['threshold'] for BC in om.BCs])
    check_points = {'indices': indices,
                    'thresholds': thresholds,
                    }
    DTs = []
    boosted_DNNs = []
    conf_convs = []
    for BC in om.BCs:
        lut_l = []
        for WC in BC['WCs']:
            dt = {'dt_type': 0,
                  'pixels': WC['pixels'],
                  'thresholds': np.empty([0], dtype='uint8'),
                  }
            DTs.append(dt)
            lut = WC['leaf_confs'].reshape(16, 1)
            lut_l.append(lut)

        layer_agg_lut = {'act_type': -1,
                         'luts': lut_l
                         }
        layers_fc = []

        bd = {'layer_agg_lut': layer_agg_lut,
              'layers_fc': layers_fc,
              }
        boosted_DNNs.append(bd)

        conf_convs += [BC['conf_converter']['scale'],
                       BC['conf_converter']['offset']]

    print 'decision tree number {}, layer number {}'.format(len(DTs), len(boosted_DNNs))

    nm = CascadeBoostedDNN(ref, DTs, check_points, boosted_DNNs, conf_convs)
    dst_fn = new_model_fn if new_model_fn is not None else old_model_fn + \
        '.new.bin'
    open(dst_fn, 'wb').write(nm.tostring())
    print 'new model is saved to ', dst_fn


def StatisticModelXYCS(model_fn):
    nm = CascadeBoostedDNN()
    nm.fromstring(open(model_fn).read())
    hist = [[0] * 8, [0] * 4]
    for dt in nm.DTs:
        for p in dt['pixels']:
            hist[0][p['c']] += 1
            hist[1][p['s']] += 1
        print hist


def NewModel2OldModel(new_model_fn, old_model_fn):
    nm = CascadeBoostedDNN()
    nm.fromstring(open(new_model_fn).read())
    ref_w = nm.ref['w']
    ref_h = nm.ref['h']
    ref_scale = nm.ref['end_scale']
    assert nm.ref['start_scale'] == 0
    chan_types = nm.ref['chan_types']
    conf_convs = nm.conf_convs

    BCs = []
    for l, dt_ei in enumerate(nm.check_points['indices']):
        bdnn = nm.boosted_DNNs[l]
        assert len(bdnn['layers_fc']) == 0
        layer_agg_lut = bdnn['layer_agg_lut']
        assert layer_agg_lut['act_type'] == -1
        luts = layer_agg_lut['luts']
        dt_si = dt_ei - len(luts)
        assert dt_si == (0 if l == 0 else nm.check_points['indices'][l - 1])
        WCs = []
        for dt_i in xrange(dt_si, dt_ei):
            dt = nm.DTs[dt_i]
            assert dt['dt_type'] == 0
            WC = {'pixels': dt['pixels'],
                  'leaf_confs': luts[dt_i - dt_si].reshape(-1),
                  }
            WCs.append(WC)
        conf_converter = {
            'scale': conf_convs[l * 2], 'offset': conf_convs[l * 2 + 1]}
        BC = {'conf_converter': conf_converter,
              'threshold': nm.check_points['thresholds'][l],
              'WCs': WCs,
              }
        BCs.append(BC)

    om = Cascade(ref_w, ref_h, ref_scale, chan_types, BCs)
    print 'decision tree number {}, layer number {}'.format(sum([len(BC['WCs']) for BC in BCs]), len(BCs))

    dst_fn = old_model_fn if old_model_fn is not None else new_model_fn + \
        '.old.bin'
    open(dst_fn, 'wb').write(om.tostring())
    print 'old model is saved to ', dst_fn


def TestPerturbSample():
    img = cv2.imread('/home/huangchang/data/Lenna.png', 0)
    dst_sz = (200, 200)
    para = {'rand_scale': (0.5, 0.5),
            'rand_angel': (-5, 5),
            'rand_location': (-2, 2),
            'rand_gaussian_blur_sigma': 0.1,
            'randn_mean': 32,
            'randn_std': 16,
            }
    while True:
        dst_img = GetPerturbedSamples(img, dst_sz, para)
        cv2.imshow('perturbed img', dst_img)
        key = cv2.waitKey()
        if chr(key) in ['q', 'Q']:
            break


def VisualizeSmp(smp_file, out_dir, num=100):
    d = LoadSmpFile(smp_file)
    num = min(num, d[0].shape[0])
    perm = np.random.permutation(d[0].shape[0])
    idx = perm[:num]
    for i in idx:
        if not os.path.exists(out_dir):
            os.system('mkdir -p ' + out_dir)
        #d[0][i][16,16] = 0
        imsave(out_dir + '/%04d.png' % (i), d[0][i])

if __name__ == '__main__':
    op = sys.argv[1]
    if op == 'o2n':
        OldModel2NewModel(
            sys.argv[2], None if len(sys.argv) < 4 else sys.argv[3])
    elif op == 'n2o':
        NewModel2OldModel(
            sys.argv[2], None if len(sys.argv) < 4 else sys.argv[3])
    elif op == 'id':
        idx = np.random.randint(0, 16, (100, 2))
        feat = indices2feat(idx, [16, 16])
    elif op == 'sf':
        data = np.random.randn(100, 32)
        label = np.arange(100).reshape(100, 1)
        d2, l2 = shuffle_data(data, label)
    elif op == 'pe':
        TestPerturbSample()
    elif op == 'st':
        StatisticModelXYCS(sys.argv[2])
    elif op == 'sm':
        y = np.arange(0, 200000) / 30000.0
        x = np.exp(y)
        h, edge = np.histogram(x, 30)
        print h
        idx = uniform_sampling(x, 100000)
        h, edge = np.histogram(x[idx], 30)
        print h
    elif op == 'vis':
        smp_file = sys.argv[2]
        out_dir = sys.argv[3]
        num = int(sys.argv[4])
        VisualizeSmp(smp_file, out_dir, num)
    elif op == 'mean':
        smp_file = sys.argv[2]
        out_file = sys.argv[3]
        smps = LoadSmpFile(smp_file)[0]
        print smps.shape
        mean = np.mean(smps, axis=0)
        imsave(out_file, mean)
    else:
        print 'Unkonwn command'
