# AlphaDet Training Tool V1.1

This is a python + cpp module tool for training AlphaDet V1.1. It contains

- ./gpuXX-series: cpp modules for servers whose hostname contains "gpu".
- ./pirateXX-seris: cpp modules for servers whose hostname contains "pirate".
- ./sample_gen: a python tool for collecting training samples from images and corresponding groundtruth labels.
- ./tools: a set of tools for analyzing, testing and evaluating trained models.
and some other python source codes (or compiled ones). Notice that two versions of cpp modules are provided due to different linux environments between pirataXXX and gpuXXX. You can run "ln  -s gpuXX-series/*.so ." to make a symbolic link to the correct version for your environment.

### Training Script Examples
A couple of python script examples are also given to illustrate how to train a detection and bounding box regressor.

- ./det.face.py.example: an example of python script for training a face detector.
- ./reg.face.py.example: an example for training a face bounding box regressor.

----------

# Guidelines of Setting Parameters in Training Scripts #

As shown in the provided script examples, many training-related parameters need to be set properly. The following guidelines could help you better understand what is their effectiveness to training procedure and result.

### Training a Cascade Classifier
- **gpu_id**: choose which GPU card to use.
- **ref_w**: reference window width; must be same as the sample width; no more than 72.
- **ref_h**: reference window height; must be same as the sample height; no more than 64.
- **pos_smp_fname**: a positive sample list including a set of numpy arrays, whose shape is (N, H, W), where N is the sample number, H and W are sample height and width respectively.
- **bg_img_list_fname**: a background image list consisting of plain image lists and/or annotation lists.
 ***plain image list***: with ".lst" or ".txt" as ext filename. It simply lists image filenames (relative to the path of the list file itself), one per line, none of which contains objects of interest.
 ***annotation list***: with ".anno" as ext filename. In addition to the plain image list, it describes rectangle regions related to objects of interes in the targetting image. For example, as a line in annotation file,

```
image_fname l0 t0 r0 b0 i0 l1 t1 r1 b1 i1
```

means there are two rectangular regions in the image. (l0, t0, r0, b0) are left, top, right, bottom of the first one, i0 = 0 indicates it is a ground truth label of object of interest, while i0 = 1 indicates it is an ignored region for objects of interest as it contains many difficult cases.
- **bg_neg_smp_num**: the number of negative samples to be collected from background images. Recommended value is comparable to the total number of positive samples, or simply use the same number.
- **too_hard_neg_ratio**: a cutting ratio for too hard negative samples. All collected negative samples are sorted by their confidence to be positive ones. too_hard_neg_ratio = 0.1 means top 10 percents are considered as "too hard". Notice that a lambda function can be used here since the training program will try to call it with cascade level index as argument.
- **too_hard_neg_accept_rate**: the accept rate of too hard negative samples for training program. e.g., too_hard_neg_accept_rate = 0.6 means 40% of the too hard ones are randomly rejected, to alleviate the effects of miss labels in annotation files. Lambda function is accepted.
- **bg_gt_neg_overlap**: a overlap threshold for judging whether a detection window corresponds to an annotated rectangle. This parameter is adopted in negative sample collection in annotated images. Any detection window whose object bounding box overlaps with an annotation for more than this parameter is refused to be a valid negative sample. See smp_gt_rect for more details.
- **smp_gt_rect**: a four dimension vector depicting the coordinates of ground truth rectange in a sample (i.e., reference window). It is used to roughly estimate the object bounding box within a detection window. Make sure it is the same as the one adopted in positive sample generation.
- **bg_scan_starting_scale**: the starting image scale to scan background images for negative sample collection. Lambda function is accepted. If returning a tuple/list/array of size two, e.g., (0.7, 1.2), an uniformly random value will be drawn within this range for each batch of processing background images.
- **bg_scan_scale_step**: the image scale down step to scan background images. Typically we set it to be (0.65, 0.85) to enable the randomness similarly.
- **func_lv_bdt_num**: a function to calculate how many decision trees to be used at each level, with level index as argument. Specifically for chip design, the first layer must be 4 decision trees and all the coming layers must be a multiple of 8.
- **target_false_neg_rate**: this is the targeting false negative rate at each layer (i.e., positive sample reject rate). Lambda function is accepted. Usually a relatively large value is set at the beginning layer (e.g., 0.01), and gradully reduced till the end (e.g., 0.001).
- **target_false_pos_rate**: this is the targeting false positive rate at each layer (i.e., negative sample pass rate). Lambda function is accepted. Usually a reasonably large value is consistently adopted across the training of entire cascade, e.g., 0.4.
- **threshold_false_neg_weight**: the two targets set above give two different confidence thresholds for a layer classifier. A weighted average of the two thresholds is adopted as the compromise of the two targets. This weight is for threshold given by false negative target, in range [0, 1].
- **feat_set_size**: the size of feature set for searching during training. Options include "small", "medium" and "large", based on which "disable_mode4" and "max_init_efp_diff_axis" are properly set.
- **feat_constraint**: feature constraint mode. Options includes "cpu", "pangu" and "fpga". Choose the right platform for the trained model to run.
- **max_init_efp_diff_axis**: set it as 3 to search more features, and 2 to search fewer.

### Training a Bounding Box Regressor

- **smp_fname_l**: a list of training sample files, similar with **pos_smp_fname** when training a cascade classifier.
- **label_fname_l**: a list of bounding box label files with numpy array format, each corresponding to a sample file. Each label file is a N * 4 numpy array, where N is the number of samples and the four values are left, top, right, bottom of the ground truth bounding box in sample image coordinate.
- **func_lv_bdt_num**: the number of decision trees used for bounding box regression; must be a multiple of 8, no more than 256.
