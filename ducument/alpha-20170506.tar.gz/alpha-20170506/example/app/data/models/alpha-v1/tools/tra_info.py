import numpy as np
import os, sys


def ParseArg(arg_list):
  import argparse
  parser = argparse.ArgumentParser(description='Training infomation & statistics.')
  parser.add_argument('--pass_rate', type=str, metavar='log_fname', default=None, help='display pass rate of positive and negative training data.')
  parser.add_argument('--screen', type=str, nargs='+', default=None, metavar=('model_fname', 'sample_fname'), help='screen samples with model')
  return parser.parse_args(arg_list)

def print_list(l, fmt):
    for val in l:
      print fmt.format(val),
    print

def getAvgPrecFromLog(log_fname):
    import re
    pat = re.compile('avg prec [0-9.e\-]+')
    avg_prec_info = pat.findall(open(log_fname).read())
    tra_ap_l = [float(item.split()[-1]) for item in avg_prec_info[::2]]
    tst_ap_l = [float(item.split()[-1]) for item in avg_prec_info[1::2]]
    print log_fname.split('/')[-2]
    print tra_ap_l
    print tst_ap_l

def getCascadeAp(log_fname):
    import re
    p_pos_pass = re.compile('\, pass rate [0-9.e\-]+')
    p_neg_pass = re.compile('\, avg pass rate [0-9.e\-]+')
    s = open(log_fname).read()
    pos_pass_l = [float(item.split()[-1]) for item in p_pos_pass.findall(s)]
    neg_pass_l = [float(item.split()[-1]) for item in p_neg_pass.findall(s)]
    print
    print log_fname.split('/')[-2]
    print_list(pos_pass_l, '{:.5f} ')
    print_list(neg_pass_l, '{:.1e} ')

def screenSamples(model_fname_l, sample_fname):
  sys.path.append('../')
  import ModelTrainer, Model, smp
  import ObjDetectorCPP
  for model_fname in model_fname_l:
    print '{}:'.format(model_fname),
    model = ObjDetectorCPP.SCascadeBoostedDNN()
    if not model.FromString(open(model_fname).read()):
      raise IOError('Failed in loading model {}'.format(model_fname))
    if sample_fname.endswith('.smp'):
      smp_arr, info = smp.LoadSmpFile(sample_fname)
    elif sample_fname.endswith('.npy'):
      smp_arr = np.load(sample_fname)
    else:
      raise ValueError('Unknown smp file type.')
    ObjDetectorCPP.SetThreadNum(1)
    pass_arr, conf_arr = ModelTrainer.ScreenSamples(smp_arr, cascade_cpp_l = [model])
    print '{} passed out of {}, pass rate {}'.format(pass_arr.sum(), len(smp_arr), float(pass_arr.sum()) / len(smp_arr))


if __name__ == '__main__':
  para = ParseArg(sys.argv[1:])
  if para.pass_rate is not None:
    getCascadeAp(para.pass_rate)
  if para.screen is not None:
    screenSamples(para.screen[0:-1], para.screen[-1])




