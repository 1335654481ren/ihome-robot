import os, sys
import numpy as np
import struct
import cPickle
sys.path.append('../')
from Model import CascadeBoostedDNN
from model_conv_util import layer_floating_to_fixed_point, float2fp

def ArrayToString(dtype, arr):
    if type(arr) in [tuple, list]:
        s = struct.pack('i', len(arr)) + struct.pack(dtype * len(arr), *arr)
    elif type(arr) == np.ndarray:
        s = struct.pack('i' * len(arr.shape), *arr.shape) + arr.astype(dtype).tostring()
    else:
        raise NotImplementedError
    return s


def train_format_to_general_format(para):
  src_det_fname = para.src_fname
  src_reg_fname = para.src_reg_fname
  dst_fname = para.dst_prefix + '.alpha+.pkl'
  init_reg_outputs = para.init_reg_outputs if para.init_reg_outputs is not None and len(para.init_reg_outputs) > 0 else None

  # parse detection model
  print 'parsing ', src_det_fname
  tm = CascadeBoostedDNN()
  tm.fromstring(open(src_det_fname).read())
  mm = {}
  mm['ref'] = {'chan_types' : tm.ref['chan_types'],
            'fw' : tm.ref['w'] / 2,
            'fh' : tm.ref['h'] / 2,
            }
  mm['det_layers'] = []

  lv_num = len(tm.boosted_DNNs)
  dt_num_l = []
  #ensemble classifiers
  for lv_i in xrange(lv_num):
    bd = tm.boosted_DNNs[lv_i]
    dt_si = 0 if lv_i == 0 else tm.check_points['indices'][lv_i - 1]
    dt_ei = tm.check_points['indices'][lv_i]
    dts = tm.DTs[dt_si:dt_ei]
    luts = bd['layer_agg_lut']['luts']

    assert len(dts) == len(luts)
    dt_num = len(dts)
    dt_depth = None
    lut_dim = None
    dt_num_l.append(dt_num)

    pixels = []
    biases = []

    for dt_i in xrange(dt_num):
      dt = dts[dt_i]
      assert dt['dt_type'] == 3
      assert np.min([m in [0, 4] for m in dt['modes']])
      if dt_depth == None:
        dt_depth = len(dt['pixels']) >> 1
      else:
        assert dt_depth == len(dt['pixels']) >> 1
      assert len(dt['biases']) == dt_depth

      lut = luts[dt_i]
      assert lut.shape[0] == 1 << dt_depth
      if lut_dim == None:
        lut_dim = lut.shape[1]
      else:
        assert lut_dim == lut.shape[1]

      for p in dt['pixels']:
        assert p['x'] % 2 == 0
        assert p['y'] % 2 == 0
        p['x'] >>= 1
        p['y'] >>= 1
        p['s'] -= 1
        pixels.append(p)

      for di, b in enumerate(dt['biases']):
        if dt['modes'][di] == 0:
          #original comparison
          assert b == 0
          b = 256
        elif dt['modes'][di] == 4:
          #div bias
          assert b > 0 and b < 256
        else:
          raise ValueError
        biases.append(b - 1)

    layer = { 'dt_num' : dt_num,
              'dt_depth' : dt_depth,
              'lut_dim' : lut_dim,
              'pixels' : pixels,
              'biases' : biases,
              'luts' : luts,
              'pre_conf_bias' : tm.conf_convs[lv_i * 3 + 1],
              'pre_conf_ub' : tm.conf_convs[lv_i * 3 + 2],
              'threshold' : tm.check_points['thresholds'][lv_i],
            }
    assert tm.conf_convs[lv_i * 3] == 1 or lv_i == 0

    mm['det_layers'].append(layer)

  print 'total dt_num {}, layer-wise {}'.format(sum(dt_num_l), dt_num_l)

  # parse regression model
  if src_reg_fname is not None:
    print '\nparsing ', src_reg_fname
    rm = CascadeBoostedDNN()
    rm.fromstring(open(src_reg_fname).read())
    assert (rm.ref['chan_types'] == tm.ref['chan_types']).all()
    assert rm.ref['w'] == tm.ref['w']
    assert rm.ref['h'] == tm.ref['h']
    assert len(rm.boosted_DNNs) == 1
    bd = rm.boosted_DNNs[0]
    dt_si = 0
    dt_ei = rm.check_points['indices'][0]
    dts = rm.DTs[dt_si:dt_ei]
    luts = bd['layer_agg_lut']['luts']

    assert len(dts) == len(luts)
    dt_num = len(dts)
    dt_depth = None
    lut_dim = None

    pixels = []
    biases = []

    for dt_i in xrange(dt_num):
      dt = dts[dt_i]
      assert dt['dt_type'] == 3
      assert np.min([m in [0, 4] for m in dt['modes']])
      if dt_depth == None:
        dt_depth = len(dt['pixels']) >> 1
      else:
        assert dt_depth == len(dt['pixels']) >> 1
      assert len(dt['biases']) == dt_depth

      lut = luts[dt_i]
      assert lut.shape[0] == 1 << dt_depth
      if lut_dim == None:
        lut_dim = lut.shape[1]
      else:
        assert lut_dim == lut.shape[1]

      for p in dt['pixels']:
        assert p['x'] % 2 == 0
        assert p['y'] % 2 == 0
        p['x'] >>= 1
        p['y'] >>= 1
        p['s'] -= 1
        pixels.append(p)

      for di, b in enumerate(dt['biases']):
        if dt['modes'][di] == 0:
          #original comparison
          assert b == 0
          b = 256
        elif dt['modes'][di] == 4:
          #div bias
          assert b > 0 and b < 256
        else:
          raise ValueError
        biases.append(b - 1)

    layer = { 'dt_num' : dt_num,
              'dt_depth' : dt_depth,
              'lut_dim' : lut_dim,
              'pixels' : pixels,
              'biases' : biases,
              'luts' : luts,
            }

    mm['reg_layer'] = layer
    mm['reg_init_output'] = rm.init_reg_outputs
    if init_reg_outputs is not None:
      mm['reg_init_output'] = init_reg_outputs
      print 'bbox reg init output is updated as ', init_reg_outputs

    print 'dt_num ', dt_num

  cPickle.dump(mm, open(dst_fname, 'wb'), -1)
  print 'the model in general format is dumped to ', dst_fname


##############################################################

def layer_fixed_point_to_lib_format_string(l):
  dt_num = l['dt_num']
  dt_depth = l['dt_depth']
  lut_dim = l['lut_dim']
  ss_head = struct.pack('iii', dt_num, dt_depth, lut_dim)

  ss_pixels = ''
  ss_biases = ''
  ss_lut_base = ''
  ss_lut_exp = ''
  assert len(l['pixels']) == dt_depth * 2 * dt_num
  for p in l['pixels']:
    ss_pixels += struct.pack('BBBB', p['x'], p['y'], p['c'], p['s'])
  assert len(l['biases']) == dt_depth * dt_num
  for b in l['biases']:
    ss_biases += struct.pack('B', b)
  for lut in l['luts']:
    lut_base = lut['base']
    lut_exp = lut['exp']
    assert lut_base.size == lut_dim * (1 << dt_depth)
    if lut_base.max() > 127 or lut_base.min() < -128:
      raise ValueError('lib format requires lut_base in range [-128, 127], however {}'.format(lut_base.flatten()))
    ss_lut_base += lut_base.astype('int8').tostring()
    ss_lut_exp += struct.pack('B', lut_exp)
  return ss_head + ss_pixels + ss_biases + ss_lut_base + ss_lut_exp


def general_format_to_lib_format(para):
  src_fname = para.src_fname
  dst_fname = para.dst_prefix
  int_prec, dec_prec, lut_base_prec = para.prec_bits
  max_prec_loss = para.max_prec_loss
  ign_lut_prec_loss = para.ign_lut_prec_loss

  sm = cPickle.load(open(src_fname))
  ss = 'Alpha+ v1.1'
  ss += '\0' * (32 - len(ss))
  ss += struct.pack('ii', sm['ref']['fw'], sm['ref']['fh'])
  dls = sm['det_layers']
  lv_num = len(dls)
  if para.layer_num > 0:
      if para.layer_num > lv_num:
          raise ValueError("Invalid layer number {} is set; only {} layers are available.".format(para.layer_num, lv_num))
      lv_num = para.layer_num
  ss += struct.pack('i', lv_num)

  _layer_fl2fp = lambda l, is_reg : layer_floating_to_fixed_point(l, int_prec, dec_prec, lut_base_prec, max_prec_loss, ign_lut_prec_loss, is_reg)
  _fl2fp = lambda vals : float2fp(vals, int_prec, dec_prec, max_prec_loss)

  # detection classifiers
  det_dt_num = 0
  for lv_i in xrange(lv_num):
    l = _layer_fl2fp(dls[lv_i], False)
    ss += layer_fixed_point_to_lib_format_string(l)
    det_dt_num += dls[lv_i]['dt_num']

  pre_conf_bias = _fl2fp([l['pre_conf_bias'] for l in dls])
  pre_conf_ub = _fl2fp([l['pre_conf_ub'] for l in dls])
  threshold = _fl2fp([l['threshold'] for l in dls])

  ss += ArrayToString('int32', pre_conf_bias)
  ss += ArrayToString('int32', pre_conf_ub)
  ss += ArrayToString('int32', threshold)
  ss += struct.pack('i', dec_prec)

  # reg layer
  reg_dt_num = 0
  if 'reg_layer' in sm:
    assert len(sm['reg_init_output']) == 4
    ss += ArrayToString('int32', _fl2fp(sm['reg_init_output']))
    ss += layer_fixed_point_to_lib_format_string(_layer_fl2fp(sm['reg_layer'], True))
    ss += struct.pack('i', dec_prec)
    reg_dt_num = sm['reg_layer']['dt_num']

  if dst_fname is None or len(dst_fname) == 0:
    print 'dry run only!'
  else:
    dst_fname += '.ln{:02d}.fp{}_{}_{}.bin'.format(lv_num, int_prec, dec_prec, lut_base_prec)
    open(dst_fname, 'wb').write(ss)
    print 'Done: {} -> {}'.format(src_fname, dst_fname)
  print 'det dt num {}, reg dt num {}'.format(det_dt_num, reg_dt_num)


def ParseArg(arg_list):
  import argparse
  parser = argparse.ArgumentParser(description='Convert a trained model to fixed point one ')
  parser.add_argument('src_fname', help='source filename')
  parser.add_argument('-r', '--src_reg_fname',  help='source regression filename (only for separate training)', default=None)
  parser.add_argument('dst_prefix', help='destination model filename prefix')
  parser.add_argument('-i', '--init_reg_outputs', metavar=('left', 'top', 'right', 'bottom'), type=float, nargs=4, default=None, help='override initial outputs for regression model (default: None)')
  parser.add_argument('--t2g', action='store_true', help='convert separately trained models (det and reg) to general format (default: false)')
  parser.add_argument('-p', '--prec_bits', metavar=('int_prec', 'dec_prec', 'lut_base_prec'), type=int, nargs=3, default=(8, 10, 4), help='precision bits for interger, decimal and lut base (default: 8, 10 and 4)')
  parser.add_argument('--max_prec_loss', type=float, default=1E-6, help='maximum precision loss allowed in converting a floating number to fixed point (default: 1E-6)')
  parser.add_argument('--ign_lut_prec_loss', action='store_true', help='ignore precision loss in converting LUT (default: false)')
  parser.add_argument('--g2l', action='store_true', help='convert general format to lib format (default: false)')
  parser.add_argument('-l', '--layer_num', type=int, default=-1, help='the number of adopted layers (default: -1, i.e., all available layers)')
  return parser.parse_args(arg_list)


if __name__ == '__main__':
  para = ParseArg(sys.argv[1:])
  if para.t2g:
    train_format_to_general_format(para)
  elif para.g2l:
    general_format_to_lib_format(para)
  else:
    raise ValueError
  #else:
  #  training_model_to_golden_c_fp32_model(para)





