import os
import sys
import time
import logging
import struct
import numpy as np
from scipy.misc import imsave


def LoadSmpFile(smp_fn):
    fid = open(smp_fn)
    if fid == None:
        raise IOError('Failed in loading {}'.format(smp_fn))
    ref_w, ref_h, ref_step, num = struct.unpack('iiii', fid.read(4 * 4))

    data_sz = num * ref_h * ref_step
    smp = np.fromstring(fid.read(data_sz), dtype='uint8')
    if num * ref_h * ref_step != smp.shape[0]:
        print 'error in load smp: {} read, but size is {} {} {}'.format(smp.shape[0], num, ref_h, ref_step)
    smp = smp.reshape(num, ref_h, ref_step)
    if ref_step != ref_w:
        smp = np.array(smp[:, :, :ref_w])  # remove padding
    info = fid.read()
    fid.close()
    #log.debug('{} loaded, ref_w {}, ref_h {}, num {}'.format(smp_fn, ref_w, ref_h, num))
    # print smp_fn, ref_w, ref_h, ref_step, num
    return smp, info


def SaveSmpFile(smp, info, smp_fn):
    fid = open(smp_fn, 'wb')
    if fid == None:
        raise IOError('Failed in loading {}'.format(smp_fn))

    num, ref_h, ref_w = smp.shape
    fid.write(struct.pack('i', ref_w))
    fid.write(struct.pack('i', ref_h))
    fid.write(struct.pack('i', ref_w))
    fid.write(struct.pack('i', num))
    fid.write(smp.tostring())
    if info != None:
        fid.write(info)
    #log.debug('{} saved, ref_w {}, ref_h {}, num {}'.format(smp_fn, ref_w, ref_h, num))
    fid.close()


def SplitSmpFile(smp_fn, nsplit):
    smp, info = LoadSmpFile(smp_fn)
    num = smp.shape[0]
    num_per_split = (num + nsplit - 1) / nsplit
    for i in xrange(nsplit):
        subsmp = smp[i * num_per_split:min((i + 1) * num_per_split, num), :, :]
        SaveSmpFile(subsmp, info, '.'.join(
            smp_fn.split('.')[0:-1]) + '_%03d' % i + '.smp')
        print 'split %03d' % i, subsmp.shape

if __name__ == '__main__':
    #SplitSmpFile(sys.argv[1], int(sys.argv[2]))
    smp, info = LoadSmpFile(sys.argv[1])
    print smp.dtype, smp.shape
    im = smp.mean(axis=0)
    imsave('mean.png', im)
