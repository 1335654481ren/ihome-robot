#include "opencv2/opencv.hpp"
#include "opencv/highgui.h"
#include "opencv/cv.h"
using namespace std;

int main()
{ 
	IplImage* pFrame = NULL;
	cvNamedWindow("result", 1);
	CvCapture* pCapture = cvCreateCameraCapture(-1);
	cvSetCaptureProperty(pCapture,CV_CAP_PROP_FRAME_WIDTH,320);
	cvSetCaptureProperty(pCapture,CV_CAP_PROP_FRAME_HEIGHT,240);

	while(true)
	{
		pFrame = cvQueryFrame( pCapture );
		
		if(!pFrame) break;

		char c = cvWaitKey(33);
		if(c == 32) break;

		cvShowImage("result", pFrame);
	}

	return 0;
}

