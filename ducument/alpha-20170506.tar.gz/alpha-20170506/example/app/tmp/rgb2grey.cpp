#include <iostream>
#include <opencv2/opencv.hpp>  
#include <string>
using namespace cv;
using namespace std;

int main()
{
    string fileName, grayFile;
 
    for(int i = 101; i <= 150; i++)
        for(int j = 0; j <= 23; j++)
        {
            //int 转换为 string
            stringstream ss1,ss2;  
            string str1, str2;  
            ss1 << i;    
            ss1 >> str1;  
            ss2 << j;
            ss2 >> str2;

            fileName = "srcImage/Tester_" + str1 + "TrainingPosepose_" + str2 + ".jpg";
            grayFile = "grayImage/Gray_Tester_" + str1 + "TrainingPosepose_" + str2 + ".jpg";
            //cout << fileName << endl;

            Mat srcImage = imread(fileName), grayImage;
            cvtColor(srcImage,grayImage,CV_BGR2GRAY);
            
            imwrite( grayFile, grayImage);
        }
    system("pause");
    return 0;
}
