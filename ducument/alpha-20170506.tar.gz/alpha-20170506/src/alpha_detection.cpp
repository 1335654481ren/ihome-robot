//
//  Alpha Detection
//  Copyright (c) 2016 by Horizon Robotics Inc.
//  Author: Chang Huang (chang.huang@hobot.cc)
//

#include "mcms_neon.h"
#include "alpha_detection.h"
#include "base.h"
#include "mcms.h"
#include "alpha_cascade.h"
#ifdef SHOW_TIME
#include <sys/time.h>
#endif

namespace hobot {
namespace vision {
namespace alpha {

AlphaDetector::AlphaDetector(int max_img_w, int max_img_h) {
#if defined(HOBOT_SYXC)
  mcms_ = new ImageMcmsNeon(max_img_w, max_img_h, 8, 3);
#elif defined(HOBOT_SCYX)
  mcms_ = new ImageMcms(max_img_w, max_img_h, 8, 3);
#endif
#ifdef SHOW_TIME
  ClearTimer();
#endif
}

AlphaDetector::~AlphaDetector() {
  Release();
  delete mcms_;
}

void AlphaDetector::Release() {
  for (uint i = 0; i < cascades_.size(); i++) {
    if (cascades_[i])
      delete cascades_[i];
  }
  cascades_.clear();
}

void AlphaDetector::InitModels(std::vector<std::istream *> &iss) {
  Release();
  int xstep, ystep, cstep, sstep;
  mcms_->GetSteps(xstep, ystep, cstep, sstep);
  int max_scale_num = mcms_->GetMaxScaleNum();
  cascades_.resize(iss.size());
  for (uint i = 0; i < iss.size(); i++) {
    cascades_[i] = new AlphaCascade(*iss[i]);
    cascades_[i]->UpdateFeatOffsets(xstep, ystep, cstep, sstep);
  }
#ifdef CAL_DET_STAT
  model_stats_.resize(cascades_.size());
#endif
}

void AlphaDetector::Detect(const GreyImagePyramid &img_pyr,
                           ScanMode scan_mode, int coarse2fine_layer_num,
                           std::vector<std::list<SDetRespFP> > &raw_resp_list) {

  int lv_num = img_pyr.GetLevelNum();
  int pad_border = img_pyr.GetPadBorder();
  ERROR_IF(0 != pad_border % 2, "pad_border must be even, %d", pad_border);
  int pad_border_feat = pad_border >> 1;
  const unsigned char
      *feat_ptr = mcms_->GetWndPtr(pad_border_feat, pad_border_feat);
  int xstep, ystep, cstep, sstep;
  mcms_->GetSteps(xstep, ystep, cstep, sstep);

  raw_resp_list.clear();
  raw_resp_list.resize(cascades_.size());

  const int mcms_scale_num = 3;
  ChannelType chan_types[8];
  for (int c = 0; c < 8; c++)
    chan_types[c] = ChannelType(c);

  //scan images at each scale
  for (int lv_i = 0; lv_i < lv_num; lv_i++) {
    const GreyImage *lv_img = img_pyr.GetLevel(lv_i);
    int lv_w = lv_img->GetWidth();
    int lv_h = lv_img->GetHeight();
    int lv_step = lv_img->GetWidthStep();
    const uchar *lv_data = lv_img->GetConstData();
    // compute mcms feature
#if SAME_AS_GOLDEN_C
    mcms_->Compute(lv_data + 1, lv_w - 1, lv_h, lv_step,
                  8, chan_types, mcms_scale_num);
#else
#ifdef SHOW_TIME
    tmp_timer_ = GetTimeStamp();
#endif
    mcms_->Compute(lv_data, lv_w, lv_h, lv_step,
                   8, chan_types, mcms_scale_num);
#ifdef SHOW_TIME
    mcms_time_ += GetTimeStamp() - tmp_timer_;
#endif
#endif
    int fimg_w, fimg_h;
    mcms_->GetFeatImageSize(fimg_w, fimg_h);
    int curr_img_scale_recip =
        int((1 << kImageScaleRecipDecPrec) / img_pyr.GetScale(lv_i));
    // scan

#ifdef SHOW_TIME
    tmp_timer_ = GetTimeStamp();
#endif
    for (uint ci = 0; ci < cascades_.size(); ci++) {
      AlphaCascade &cas = *cascades_[ci];
      int bgn_x = -pad_border_feat;
      int bgn_y = -pad_border_feat;
      int end_x = fimg_w + 1 - cas.ref_fw_ + bgn_x;
      int end_y = fimg_h + 1 - cas.ref_fh_ + bgn_y;
      AlphaScanFP(cas, feat_ptr, ystep, xstep,
                  bgn_x, bgn_y, end_x, end_y,
                  scan_mode, coarse2fine_layer_num,
                  curr_img_scale_recip, kImageScaleRecipDecPrec,
                  raw_resp_list[ci]
#ifdef CAL_DET_STAT
          , model_stats_[ci]
#endif
      );
#ifdef CAL_DET_STAT
      model_stats_[i].image_pixel_num += lv_w * lv_h;
      model_stats_[ci].layer_num = cas.classifiers_.size();
      int64 cum_dt_num = 0;
      for (uint lv = 0; lv < model_stats_[ci].layer_num; lv++) {
        cum_dt_num += cas.classifiers_[lv]->dt_num_;
        model_stats_[ci].cum_dt_num_each_layer[lv] = cum_dt_num;
      }
      model_stats_[ci].cum_dt_num_each_layer[model_stats_[ci].layer_num] = cum_dt_num;
#endif
    }
#ifdef SHOW_TIME
    scan_time_ += GetTimeStamp() - tmp_timer_;
#endif
  }
}

void AlphaDetector::Detect(const GreyImagePyramid &img_pyr,
                          ScanMode scan_mode, int coarse2fine_layer_num,
                          std::vector<TSRect<int> > image_roi_l,
                          std::vector<std::list<SDetRespFP> > &raw_resp_list) {

  int lv_num = img_pyr.GetLevelNum();
  int pad_border = img_pyr.GetPadBorder();
  ERROR_IF(0 != pad_border % 2, "pad_border must be even, %d", pad_border);
  int pad_border_feat = pad_border >> 1;
  const unsigned char
    *feat_ptr = mcms_->GetWndPtr(pad_border_feat, pad_border_feat);
  int xstep, ystep, cstep, sstep;
  mcms_->GetSteps(xstep, ystep, cstep, sstep);

  raw_resp_list.clear();
  raw_resp_list.resize(cascades_.size());

  const int mcms_scale_num = 3;
  ChannelType chan_types[8];
  for (int c = 0; c < 8; c++)
    chan_types[c] = ChannelType(c);

  //scan images at each scale
  for (int lv_i = 0; lv_i < lv_num; lv_i++) {
    const GreyImage *lv_img = img_pyr.GetLevel(lv_i);
    int lv_w = lv_img->GetWidth();
    int lv_h = lv_img->GetHeight();
    int lv_step = lv_img->GetWidthStep();
    const uchar *lv_data = lv_img->GetConstData();
    // compute mcms feature
#if SAME_AS_GOLDEN_C
    mcms_->Compute(lv_data + 1, lv_w - 1, lv_h, lv_step,
      8, chan_types, mcms_scale_num);
#else
#ifdef SHOW_TIME
    tmp_timer_ = GetTimeStamp();
#endif
    mcms_->Compute(lv_data, lv_w, lv_h, lv_step,
      8, chan_types, mcms_scale_num);
#ifdef SHOW_TIME
    mcms_time_ += GetTimeStamp() - tmp_timer_;
#endif
#endif
    int fimg_w, fimg_h;
    mcms_->GetFeatImageSize(fimg_w, fimg_h);
    int curr_img_scale_recip =
      int((1 << kImageScaleRecipDecPrec) / img_pyr.GetScale(lv_i));
    // scan

#ifdef SHOW_TIME
    tmp_timer_ = GetTimeStamp();
#endif
    for (uint ci = 0; ci < cascades_.size(); ci++) {
      AlphaCascade &cas = *cascades_[ci];
      int bgn_x = -pad_border_feat;
      int bgn_y = -pad_border_feat;
      int end_x = fimg_w + 1 - cas.ref_fw_ + bgn_x;
      int end_y = fimg_h + 1 - cas.ref_fh_ + bgn_y;
      AlphaScanFP(cas, feat_ptr, ystep, xstep,
        bgn_x, bgn_y, end_x, end_y,
        scan_mode, coarse2fine_layer_num,
        curr_img_scale_recip, kImageScaleRecipDecPrec,
        raw_resp_list[ci], image_roi_l[lv_i].l << 2, image_roi_l[lv_i].t << 2
#ifdef CAL_DET_STAT
        , model_stats_[ci]
#endif
        );
#ifdef CAL_DET_STAT
      model_stats_[i].image_pixel_num += lv_w * lv_h;
      model_stats_[ci].layer_num = cas.classifiers_.size();
      int64 cum_dt_num = 0;
      for (uint lv = 0; lv < model_stats_[ci].layer_num; lv++) {
        cum_dt_num += cas.classifiers_[lv]->dt_num_;
        model_stats_[ci].cum_dt_num_each_layer[lv] = cum_dt_num;
      }
      model_stats_[ci].cum_dt_num_each_layer[model_stats_[ci].layer_num] = cum_dt_num;
#endif
    }
#ifdef SHOW_TIME
    scan_time_ += GetTimeStamp() - tmp_timer_;
#endif
  }
}

#ifdef CAL_DET_STAT
void AlphaDetector::ResetDetStat() {
  for (uint i = 0; i < model_stats_.size(); i++) {
    model_stats_[i].Reset();
  }
}

void AlphaDetector::PrintDetStat() {
  for (uint i = 0; i < model_stats_.size(); i++) {
    DetStat &ds = model_stats_[i];
    int64 used_dt_num = 0;
    for (int lv = 0; lv < ds.layer_num + 1; lv++) {
      used_dt_num += ds.cum_dt_num_each_layer[lv] * ds.wnd_num_each_layer[lv];
    }
    printf("============ Statistics, Model #%d ============\n", i);
    printf("image pixel num %ld, layer num %ld, scanned wnd num %ld (%.3lf pp), used_dt_num %ld (%.3lf pp %.3lf pw)\n",
        ds.image_pixel_num, ds.layer_num, ds.scanned_wnd_num,
        double(ds.scanned_wnd_num) / ds.image_pixel_num, used_dt_num,
        double(used_dt_num) / ds.image_pixel_num,
        double(used_dt_num) / ds.scanned_wnd_num);

    printf("wnd num:");
    for (int lv = 0; lv < ds.layer_num + 1; lv++) {
      printf(" %ld", ds.wnd_num_each_layer[lv]);
    }
    printf("\n");
    printf("cum dt num:");
    for (int lv = 0; lv < ds.layer_num + 1; lv++) {
      printf(" %ld", ds.cum_dt_num_each_layer[lv]);
    }
    printf("\n");

  }
}
#endif

#ifdef SHOW_TIME
long long AlphaDetector::GetTimeStamp() {
#ifdef _WIN32
  LARGE_INTEGER freq, curr_time;
  QueryPerformanceFrequency(&freq);
  QueryPerformanceCounter(&curr_time);
  return curr_time.QuadPart * 1000 / freq.QuadPart;

#elif defined(__linux__) || defined(__APPLE__)
  struct timeval curr_time;
  gettimeofday(&curr_time, NULL);
  return curr_time.tv_sec * 1000 + curr_time.tv_usec / 1000;

#else
  REPORT_ERROR_POSITION
  ;
#endif
}

void AlphaDetector::ClearTimer()
{
  mcms_time_ = 0;
  scan_time_ = 0;
}
#endif

} // namespace alpha
} // namespace vision
} // namespace hobot
