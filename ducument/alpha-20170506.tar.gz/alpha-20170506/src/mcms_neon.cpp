//
// Created by Bear on 16/9/20.
// Copyright (c) 2016 Horizon Robotics. All rights reserved.
//

#include "mcms_neon.h"
#ifdef DEBUG_MCMS_IMG
#include "opencv/cv.h"
#include "opencv/highgui.h"
#endif

namespace hobot
{
namespace vision
{
namespace alpha
{

void ImageMcmsNeon::Compute(const uchar *grey_img,
                            const int w,
                            const int h,
                            const int step,
                            const int chan_num,
                            const ChannelType *chan_types,
                            const int scale_num)
{
  //check whether input image exceeds the pre-set size
  ERROR_IF(mcms_img_.shape_[mcms_s_i] < scale_num
               || mcms_img_.shape_[mcms_c_i] < chan_num
               || mcms_img_.shape_[mcms_y_i] < (h >> 1)
               || mcms_img_.shape_[mcms_x_i] < (w >> 1),
           "input image size %d x %d, exceeds maximum value %d x %d. Shrink the image or modify settings.",
           w,
           h,
           mcms_img_.shape_[mcms_x_i] * 2,
           mcms_img_.shape_[mcms_y_i] * 2);
  ERROR_IF(8 != chan_num, "ONLY SUPPORT CHAN_NUM EQUALS 8!\n");

  img_w_ = w;
  img_h_ = h;
  scale_num_ = scale_num;

  int sstep = mcms_img_.steps_[mcms_s_i];
  int ystep = mcms_img_.steps_[mcms_y_i];
  int xstep = mcms_img_.steps_[mcms_x_i];
  int cstep = mcms_img_.steps_[mcms_c_i];

  uchar *fimg = mc_img_.ptr();
  int mc_ystep = mc_img_.steps_[mc_y_i];
  int mc_xstep = mc_img_.steps_[mc_x_i];
  int mc_cstep = mc_img_.steps_[mc_c_i];
  //prepare multi-channel image
  ComputeChannelFeatureNeon(img_w_,
                            img_h_,
                            step,
                            grey_img,
                            mc_ystep,
                            mc_xstep,
                            mc_cstep,
                            fimg);

  //first scale
  uchar *src = mc_img_.ptr();
  uchar *dst = mcms_img_.ptr();
  TriangularFilterNeon(w,
                       h,
                       mc_ystep,
                       mc_xstep,
                       mc_cstep,
                       src,
                       1,                // radius
                       2,                // stride
                       ystep,
                       xstep,
                       cstep,
                       dst);

  //other scales
  for (int i = 1; i < scale_num_; i++) {
    const int radius = 1 << (i - 1);
    const int stride = 1;
    src = dst;
    dst = mcms_img_.ptr() + i * sstep;
    TriangularFilterNeon(w >> 1,
                         h >> 1,
                         ystep,
                         xstep,
                         cstep,
                         src,
                         radius,              // radius
                         stride,              // stride
                         ystep,
                         xstep,
                         cstep,
                         dst);
  }
#if DEBUG_MCMS_IMG
  // debug image
//    int wid = mc_img_.shape_[mc_x_i];
//    int hei = mc_img_.shape_[mc_y_i];
//    int cs = mc_img_.steps_[mc_c_i];
//    uchar *ptr = mc_img_.ptr();
    int wid = mcms_img_.shape_[mcms_x_i];
    int hei = mcms_img_.shape_[mcms_y_i];
    int cs = mcms_img_.steps_[mcms_c_i];
    uchar *ptr = mcms_img_.ptr();

    printf("width = %d, height = %d\n", wid, hei);
    cv::Mat img(hei, wid, CV_8UC(8), ptr);
    std::vector<cv::Mat> imgs;
    cv::split(img, imgs);
    cv::Mat roi;
    roi = cv::Mat(imgs[0], cv::Rect(0, 0, wid/2, hei/2));
    cv::imshow("mc_img0", roi);
    roi = cv::Mat(imgs[1], cv::Rect(0, 0, wid/2, hei/2));
    cv::imshow("mc_img1", roi);
    roi = cv::Mat(imgs[2], cv::Rect(0, 0, wid/2, hei/2));
    cv::imshow("mc_img2", roi);
    roi = cv::Mat(imgs[3], cv::Rect(0, 0, wid/2, hei/2));
    cv::imshow("mc_img3", roi);
    roi = cv::Mat(imgs[4], cv::Rect(0, 0, wid/2, hei/2));
    cv::imshow("mc_img4", roi);
    roi = cv::Mat(imgs[5], cv::Rect(0, 0, wid/2, hei/2));
    cv::imshow("mc_img5", roi);
    roi = cv::Mat(imgs[6], cv::Rect(0, 0, wid/2, hei/2));
    cv::imshow("mc_img6", roi);
    roi = cv::Mat(imgs[7], cv::Rect(0, 0, wid/2, hei/2));
    cv::imshow("mc_img7", roi);
    cv::waitKey(-1);
#endif
}

} // namespace alpha
} // namespace vision
} // namespace hobot
