//
//  Merge Responses for Alpha Detection
//  Copyright (c) 2016 by Horizon Robotics Inc.
//  Author: Chang Huang (chang.huang@hobot.cc)
//

#include "alpha_merge.h"

namespace hobot {
namespace vision {
namespace alpha {

inline unsigned int DivFp(unsigned int numer, unsigned int denom) {
  return (numer * (1 << kDivDecPrec) + denom / 2) / denom;
}

inline int DetRespOnlineClusteringFP_(const std::list<SDetRespFP> &raw_resp_list,
                                      int overlap_ratio_numer,
                                      int overlap_ratio_bits,                // threshold for merge two resposes
                                      std::list<SDetRespFP> &merged_resp_list) {

  merged_resp_list.clear();
  for (std::list<SDetRespFP>::const_iterator itrD = raw_resp_list.begin();
       itrD != raw_resp_list.end(); itrD++) {
    std::list<SDetRespFP>::iterator itrM, itrMatchM = merged_resp_list.end();
    uint max_overlap_inter = 0;
    uint max_overlap_union = 1;
    uint areaD = itrD->rect.CalArea();
    for (itrM = merged_resp_list.begin(); itrM != merged_resp_list.end();
         itrM++) {
      // compute overlap ratio
      TSRect<int> r;
      if (GetIntersectionRect(itrD->rect, itrM->rect, r)) {
        uint inter_area = r.CalArea();
        uint areaM = itrM->rect.CalArea();
        uint union_area = areaD + areaM - inter_area;
        // avoid overflow
        while (inter_area > (1 << 16) || union_area > (1 << 16)) {
          inter_area >>= 1;
          union_area >>= 1;
        }
        if (inter_area * max_overlap_union > union_area * max_overlap_inter) {
          max_overlap_inter = inter_area;
          max_overlap_union = union_area;
          itrMatchM = itrM;
        }
      }
    }

    //avoid overflow
    while (max_overlap_union >= uint(1 << (31 - overlap_ratio_bits))) {
      max_overlap_union >>= 1;
      max_overlap_inter >>= 1;
    }

    if ((max_overlap_inter << overlap_ratio_bits)
        >= max_overlap_union * overlap_ratio_numer) {
      //merge with existing cluster
      unsigned int denom = itrMatchM->conf + itrD->conf;
      unsigned int numer = itrMatchM->conf;
      int wM = DivFp(numer, denom);
      int wD = (1 << kDivDecPrec) - wM;
      const int hDivDecPrec = 1 << (kDivDecPrec - 1);
      itrMatchM->rect.l =
          (itrMatchM->rect.l * wM + itrD->rect.l * wD + hDivDecPrec)
              >> kDivDecPrec;
      itrMatchM->rect.t =
          (itrMatchM->rect.t * wM + itrD->rect.t * wD + hDivDecPrec)
              >> kDivDecPrec;
      itrMatchM->rect.r =
          (itrMatchM->rect.r * wM + itrD->rect.r * wD + hDivDecPrec)
              >> kDivDecPrec;
      itrMatchM->rect.b =
          (itrMatchM->rect.b * wM + itrD->rect.b * wD + hDivDecPrec)
              >> kDivDecPrec;
      itrMatchM->conf += itrD->conf;
    } else {
      //create a new cluster
      merged_resp_list.push_back(*itrD);
    }
  }

  return merged_resp_list.size();
}

int DetRespOnlineClusteringFP(const std::list<SDetRespFP> &raw_resp_list,     // input detection responses
                              const float overlap_ratio_thres,                                // threshold for merge two resposes
                              std::list<SDetRespFP> &merged_resp_list) {                      // merged results
  const int overlap_ratio_numer =
      int(overlap_ratio_thres * (1 << kMergeRatioDecPrec));
  merged_resp_list = raw_resp_list;
  while (true) {
    std::list<SDetRespFP> raw_resp_list_ = merged_resp_list;
    merged_resp_list.clear();
//    printf("raw %u, merged %u\n", raw_resp_list_.size(), merged_resp_list.size());
    DetRespOnlineClusteringFP_(raw_resp_list_, overlap_ratio_numer,
                               kMergeRatioDecPrec, merged_resp_list);
    if (raw_resp_list_.size() == merged_resp_list.size()) {
      break;
    }
  }
  return merged_resp_list.size();
}

int NonMaximumSuppresionFP(std::list<SDetRespFP> &resp_list,    // input detection responses
                           const float conf_thres,                               // confidence threshold
                           const float max_overlap,                              // max overlap ratio
                           const float max_contain) {                            // max contain ratio

  const int conf_thres_numer = int(conf_thres * (1 << kScoreDecPrec));
  const int max_overlap_numer = int(max_overlap * (1 << kMergeRatioDecPrec));
  const int max_contain_numer = int(max_contain * (1 << kMergeRatioDecPrec));

  for (std::list<SDetRespFP>::iterator itr = resp_list.begin();
       itr != resp_list.end();) {
    if (itr->conf < conf_thres_numer)
      itr = resp_list.erase(itr);
    else
      itr++;
  }

  for (std::list<SDetRespFP>::iterator itrM = resp_list.begin();
       itrM != resp_list.end(); itrM++) {
    std::list<SDetRespFP>::iterator itrN = itrM;
    itrN++;

    while (itrN != resp_list.end()) {
      bool eraseM, eraseN;
      eraseM = eraseN = false;
      int areaM = itrM->rect.CalArea();
      //calculate overlap ratio
      TSRect<int> r;
      if (GetIntersectionRect(itrM->rect, itrN->rect, r)) {
        int areaN = itrN->rect.CalArea();
        int inter_area = r.CalArea();
        int union_area = areaM + areaN - inter_area;
        int min_MN = MIN(areaM, areaN);
        //check if overlapped
        //avoid overflow
        while (union_area >= (1 << (31 - kMergeRatioDecPrec))) {
          union_area >>= 1;
          inter_area >>= 1;
          min_MN >>= 1;
        }
        if (inter_area * (1 << kMergeRatioDecPrec)
            > union_area * max_overlap_numer) {
          if (itrM->conf > itrN->conf)
            eraseN = true;
          else
            eraseM = true;
        }
        //check if contained
        if (inter_area * (1 << kMergeRatioDecPrec)
            > min_MN * max_contain_numer) {
          if (itrM->conf > itrN->conf)
            eraseN = true;
          else
            eraseM = true;
        }
      }

      if (eraseN) {
        itrN = resp_list.erase(itrN);
      } else if (eraseM) {
        *itrM = *itrN;
        resp_list.erase(itrN);
        itrN = itrM;
        itrN++;
      } else {
        itrN++;
      }
    }
  }

  return resp_list.size();
}

} // namespace alpha
} // namespace vision
} // namespace hobot
