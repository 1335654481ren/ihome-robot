//
//  Multi-Channel Multi-Scale (MCMS) feature image
//  Copyright (c) 2016 by Horizon Robotics Inc.
//  Author: Chang Huang (chang.huang@hobot.cc)
//

#include "mcms.h"
#include "base.h"
#ifdef DEBUG_MCMS_IMG
#include "opencv/cv.h"
#include "opencv/highgui.h"
#endif
#include <sstream>
#include <memory.h>

namespace hobot {
namespace vision {
namespace alpha {

ImageMcms::ImageMcms(int img_w, int img_h, int chan_num, int scale_num) {
  int shapes[4];
  shapes[mcms_s_i] = scale_num;
  shapes[mcms_c_i] = chan_num;
  shapes[mcms_y_i] = img_h >> 1;
  shapes[mcms_x_i] = AlignedStepRoundUp(img_w >> 1);
  if (!mcms_img_.Resize(4, shapes)) REPORT_ERROR_POSITION;

  shapes[mc_c_i] = chan_num;
  shapes[mc_y_i] = img_h;
  shapes[mc_x_i] = AlignedStepRoundUp(img_w);
  if (!mc_img_.Resize(3, shapes)) REPORT_ERROR_POSITION;

  img_w_ = img_h_ = scale_num_ = 0;
}

void ImageMcms::GetSteps(int &xstep, int &ystep, int &cstep, int &sstep) const {
  xstep = mcms_img_.steps_[mcms_x_i];
  ystep = mcms_img_.steps_[mcms_y_i];
  cstep = mcms_img_.steps_[mcms_c_i];
  sstep = mcms_img_.steps_[mcms_s_i];
}

void ImageMcms::GetImageSize(int &img_w, int &img_h) const {
  img_w = img_w_;
  img_h = img_h_;
}

void ImageMcms::GetFeatImageSize(int &fimg_w, int &fimg_h) const {
  fimg_w = img_w_ >> 1;
  fimg_h = img_h_ >> 1;
}

void ImageMcms::Compute(const uchar *grey_img,
                        const int w,
                        const int h,
                        const int step,
                        const int chan_num,
                        const ChannelType *chan_types,
                        const int scale_num) {
  //check whether input image exceeds the pre-set size
  ERROR_IF(mcms_img_.shape_[mcms_s_i] < scale_num
               || mcms_img_.shape_[mcms_c_i] < chan_num
               || mcms_img_.shape_[mcms_y_i] < (h >> 1)
               || mcms_img_.shape_[mcms_x_i] < (w >> 1),
           "input image size %d x %d, exceeds maximum value %d x %d. Shrink the image or modify settings.",
           w,
           h,
           mcms_img_.shape_[mcms_x_i] * 2,
           mcms_img_.shape_[mcms_y_i] * 2);

  img_w_ = w;
  img_h_ = h;
  chan_types_.assign(chan_types, chan_types + chan_num);
  scale_num_ = scale_num;

  int sstep = mcms_img_.steps_[mcms_s_i];
  int cstep = mcms_img_.steps_[mcms_c_i];
  int ystep = mcms_img_.steps_[mcms_y_i];
  int xstep = mcms_img_.steps_[mcms_x_i];

  int mc_cstep = mc_img_.steps_[mc_c_i];
  int mc_ystep = mc_img_.steps_[mc_y_i];

#if defined(HOBOT_SYXC)
  ERROR_INFO("Not completed!");
#elif defined(HOBOT_SCYX)
  //prepare multi-channel image
  for (int c = 0; c < chan_num; c++) {
    const int cf_radius = 1;
    ComputeChannelFeature(w, h, step, grey_img,
                          chan_types[c], cf_radius, mc_ystep,
                          mc_img_.ptr() + c * mc_cstep);
  }

  //first scale
  for (int c = 0; c < chan_num; c++) {
    const int radius = 1;
    const int stride = 2;
    uchar *dst = mcms_img_.ptr() + c * cstep;
    uchar *src = mc_img_.ptr() + c * mc_cstep;
    TriangularFilter(w, h, mc_img_.steps_[1], src, radius, stride, ystep, dst);
  }

  //other scales
  for (int s = 1; s < scale_num_; s++) {
    int radius = (1 << (s - 1));
    for (int c = 0; c < chan_num; c++) {
      uchar *dst = mcms_img_.ptr() + s * sstep + c * cstep;
      uchar *src = mcms_img_.ptr() + (s - 1) * sstep + c * cstep;
      const int stride = 1;
      TriangularFilter(w >> 1, h >> 1, ystep, src, radius, stride, ystep, dst);
    }
  }
#else
  ERROR_INFO("Not support!");
#endif

#if DEBUG_MCMS_IMG
  // debug image
//    int wid = mc_img_.shape_[mc_x_i];
//    int hei = mc_img_.shape_[mc_y_i];
//    int cs = mc_cstep;
//    uchar *ptr = mc_img_.ptr();
    int wid = mcms_img_.shape_[mcms_x_i];
    int hei = mcms_img_.shape_[mcms_y_i];
    int cs = cstep;
    uchar *ptr = mcms_img_.ptr() + 2*sstep;
    printf("width = %d, height = %d\n", wid, hei);
    cv::Mat img0(hei, wid, CV_8UC1, ptr);
    cv::Mat img1(hei, wid, CV_8UC1, ptr + 1*cs);
    cv::Mat img2(hei, wid, CV_8UC1, ptr + 2*cs);
    cv::Mat img3(hei, wid, CV_8UC1, ptr + 3*cs);
    cv::Mat img4(hei, wid, CV_8UC1, ptr + 4*cs);
    cv::Mat img5(hei, wid, CV_8UC1, ptr + 5*cs);
    cv::Mat img6(hei, wid, CV_8UC1, ptr + 6*cs);
    cv::Mat img7(hei, wid, CV_8UC1, ptr + 7*cs);
    cv::Mat roi;
    roi = cv::Mat(img0, cv::Rect(0, 0, wid/2, hei/2));
    cv::imshow("mc_img0", roi);
    roi = cv::Mat(img1, cv::Rect(0, 0, wid/2, hei/2));
    cv::imshow("mc_img1", roi);
    roi = cv::Mat(img2, cv::Rect(0, 0, wid/2, hei/2));
    cv::imshow("mc_img2", roi);
    roi = cv::Mat(img3, cv::Rect(0, 0, wid/2, hei/2));
    cv::imshow("mc_img3", roi);
    roi = cv::Mat(img4, cv::Rect(0, 0, wid/2, hei/2));
    cv::imshow("mc_img4", roi);
    roi = cv::Mat(img5, cv::Rect(0, 0, wid/2, hei/2));
    cv::imshow("mc_img5", roi);
    roi = cv::Mat(img6, cv::Rect(0, 0, wid/2, hei/2));
    cv::imshow("mc_img6", roi);
    roi = cv::Mat(img7, cv::Rect(0, 0, wid/2, hei/2));
    cv::imshow("mc_img7", roi);
    cv::waitKey(-1);
#endif
}

} // namespace alpha
} // namespace vision
} // namespace hobot
