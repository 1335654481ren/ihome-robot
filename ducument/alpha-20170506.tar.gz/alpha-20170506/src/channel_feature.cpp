//
//  Functions for Channel Features
//  Copyright (c) 2016 by Horizon Robotics Inc.
//  Author: Chang Huang (chang.huang@hobot.cc)
//

#include "channel_feature.h"
#include "base.h"
#include <memory.h>
#include <stdio.h>

#ifdef __ARM_NEON__
#include <arm_neon.h>
#include "channel_feature_neon.h"
#endif

namespace hobot
{
namespace vision
{
namespace alpha
{

/**
 * @brief src0 - src1
 * @param src0
 * @param src1
 * @param dst
 * @param line_num
 * @param line_step_src
 * @param line_step_dst
 * @param line_width
 */
__inline void lines_sub_abs(const unsigned char *src0,
                            const unsigned char *src1,
                            unsigned char *dst,
                            int line_num,
                            int line_step_src,
                            int line_step_dst,
                            int line_width)
{
  const unsigned char *s0, *s1, *s0_, *s1_;
  unsigned char *d, *d_, *d_end_;
  int y;
  s0 = src0;
  s1 = src1;
  d = dst;

  for (y = 0; y < line_num; y++) {
    s0_ = s0;
    s1_ = s1;
    d_ = d;
    d_end_ = d + line_width;
    while (d_ < d_end_) {
      const unsigned char v0 = *s0_++;
      const unsigned char v1 = *s1_++;
      *d_++ = (v0 > v1) ? (v0 - v1) : (v1 - v0);
    }
    d += line_step_dst;
    s0 += line_step_src;
    s1 += line_step_src;
  }
}

/**
 * @brief abs(((src0 + src1 + 1) >> 1) - ((src2 + src3 + 1) >> 1))
 * @param src0
 * @param src1
 * @param src2
 * @param src3
 * @param dst
 * @param line_num
 * @param line_step_src
 * @param line_step_dst
 * @param line_width
 */
__inline void lines_sum_sub_abs(const unsigned char *src0,
                                const unsigned char *src1,
                                const unsigned char *src2,
                                const unsigned char *src3,
                                unsigned char *dst,
                                int line_num,
                                int line_step_src,
                                int line_step_dst,
                                int line_width)
{
  const unsigned char *s0, *s1, *s2, *s3, *s0_, *s1_, *s2_, *s3_;
  unsigned char *d, *d_, *d_end_;
  int y;
  s0 = src0;
  s1 = src1;
  s2 = src2;
  s3 = src3;
  d = dst;

  for (y = 0; y < line_num; y++) {
    s0_ = s0;
    s1_ = s1;
    s2_ = s2;
    s3_ = s3;
    d_ = d;
    d_end_ = d + line_width;
    while (d_ < d_end_) {
      const unsigned char v0 = ((*s0_++) + (*s1_++) + 1) >> 1;
      const unsigned char v1 = ((*s2_++) + (*s3_++) + 1) >> 1;
      *d_++ = (v0 > v1) ? (v0 - v1) : (v1 - v0);
    }
    d += line_step_dst;
    s0 += line_step_src;
    s1 += line_step_src;
    s2 += line_step_src;
    s3 += line_step_src;
  }
}

/**
 * @brief abs(((((src0 + src1 + 1) >> 1) + ((src2 + src3 + 1) >> 1)) >> 1) - src4)
 * @param src0
 * @param src1
 * @param src2
 * @param src3
 * @param src4
 * @param dst
 * @param line_num
 * @param line_step_src
 * @param line_step_dst
 * @param line_width
 */
__inline void lines_sum4_sub_abs(const unsigned char *src0,
                                 const unsigned char *src1,
                                 const unsigned char *src2,
                                 const unsigned char *src3,
                                 const unsigned char *src4,
                                 unsigned char *dst,
                                 int line_num,
                                 int line_step_src,
                                 int line_step_dst,
                                 int line_width)
{
  const unsigned char *s0, *s1, *s2, *s3, *s4, *s0_, *s1_, *s2_, *s3_, *s4_;
  unsigned char *d, *d_, *d_end_;
  int y;
  s0 = src0;
  s1 = src1;
  s2 = src2;
  s3 = src3;
  s4 = src4;
  d = dst;

  for (y = 0; y < line_num; y++) {
    s0_ = s0;
    s1_ = s1;
    s2_ = s2;
    s3_ = s3;
    s4_ = s4;
    d_ = d;
    d_end_ = d + line_width;
    while (d_ < d_end_) {
      const unsigned char v01 = ((*s0_++) + (*s1_++) + 1) >> 1;
      const unsigned char v23 = ((*s2_++) + (*s3_++) + 1) >> 1;
      const unsigned char v0123 = (v01 + v23 + 1) >> 1;
      const unsigned char v4 = *s4_++;
      *d_++ = (v0123 > v4) ? (v0123 - v4) : (v4 - v0123);
    }
    d += line_step_dst;
    s0 += line_step_src;
    s1 += line_step_src;
    s2 += line_step_src;
    s3 += line_step_src;
    s4 += line_step_src;
  }
}

void ComputeChannelFeature(const int img_w, const int img_h,
                           const int img_step, const unsigned char *img,
                           const ChannelType chan_type, const int radius,
                           const int fimg_step, unsigned char *fimg)
{
  if (radius <= 0) ERROR_INFO("radius <= 0");

  if (chan_type == CF_Original) {
    for (int y = 0; y < img_h; y++) {
      memcpy(fimg + y * fimg_step, img + y * img_step, img_w);
    }

  } else {
    unsigned char *dst = fimg + radius * fimg_step + radius;
    int fimg_w = img_w - 2 * radius;
    int fimg_h = img_h - 2 * radius;
    if (chan_type == CF_AbsGradX) {                   // 3 - 5
      lines_sub_abs(img + radius * img_step,
                    img + radius * img_step + 2 * radius,
                    dst, fimg_h, img_step, fimg_step, fimg_w);
    } else if (chan_type == CF_AbsGradY) {            // 1 - 7
      lines_sub_abs(img + radius,
                    img + 2 * radius * img_step + radius,
                    dst, fimg_h, img_step, fimg_step, fimg_w);
    } else if (chan_type == CF_AbsGradLTRB) {         // 0 - 8
      lines_sub_abs(img,
                    img + 2 * radius * img_step + 2 * radius,
                    dst, fimg_h, img_step, fimg_step, fimg_w);
    } else if (chan_type == CF_AbsGradRTLB) {         // 2 - 6
      lines_sub_abs(img + 2 * radius,
                    img + 2 * radius * img_step,
                    dst, fimg_h, img_step, fimg_step, fimg_w);
    } else if (chan_type == CF_AbsGradDXY) {          // (3+5)/2 - (1+7)/2
      lines_sum_sub_abs(img + radius * img_step,
                        img + radius * img_step + 2 * radius,
                        img + radius,
                        img + 2 * radius * img_step + radius,
                        dst, fimg_h, img_step, fimg_step, fimg_w);
    } else if (chan_type == CF_AbsGradDLTRB) {        // (0+8)/2 - (2+6)/2
      lines_sum_sub_abs(img,
                        img + 2 * radius * img_step + 2 * radius,
                        img + 2 * radius,
                        img + 2 * radius * img_step,
                        dst, fimg_h, img_step, fimg_step, fimg_w);
    } else if (chan_type == CF_AbsGradDiffC) {        // ((0+8)/2+(2+6)/2)/2 - 4
      lines_sum4_sub_abs(img,
                         img + 2 * radius * img_step + 2 * radius,
                         img + 2 * radius,
                         img + 2 * radius * img_step,
                         img + radius * img_step + radius,
                         dst, fimg_h, img_step, fimg_step, fimg_w);
    } else {
      ERROR_INFO("Unknown channel type %d\n", chan_type);
    }
  }
}

void TriangularFilter(const int img_w, const int img_h,
                      const int img_step, const unsigned char *img,
                      const int radius, const int stride,
                      const int fimg_step, unsigned char *fimg)
{
  unsigned char *dst, *dst_end;
  const unsigned char *src0, *src1, *src2;

  if (radius < 1 || stride < 1) {
    ERROR_INFO("invalid parameter: radius %d, stride %d", radius, stride);
  }

  int bgn_src_y = radius, end_src_y = img_h - 1 - radius;
  int bgn_dst_y = (bgn_src_y + stride - 1) / stride,
      end_dst_y = end_src_y / stride;
  int bgn_src_x = radius, end_src_x = img_w - 1 - radius;
  int bgn_dst_x = (bgn_src_x + stride - 1) / stride,
      end_dst_x = end_src_x / stride;

  for (int y = bgn_dst_y; y <= end_dst_y; y++) {
    src1 = img + stride * y * img_step + stride * bgn_dst_x;
    src0 = src1 - radius * img_step;
    src2 = src1 + radius * img_step;
    dst = fimg + y * fimg_step + bgn_dst_x;
    dst_end = fimg + y * fimg_step + end_dst_x;
    while (dst <= dst_end) {
      *dst++ =
          (((((((src0[-radius] + src0[radius] + 1) >> 1) + src0[0] + 1) >> 1)
              + ((((src2[-radius] + src2[radius] + 1) >> 1) + src2[0] + 1) >> 1)
              + 1) >> 1) +
              ((((src1[-radius] + src1[radius] + 1) >> 1) + src1[0] + 1) >> 1)
              + 1) >> 1;
      src0 += stride;
      src1 += stride;
      src2 += stride;
    }
  }
}

inline void pixel_channel_feature_yxc(const uchar *&src0,
                                      const uchar *&src1,
                                      const uchar *&src2,
                                      uchar *&dst)
{
  *dst++ = src1[1];                               // 4 -> 0
  *dst++ = abs(src1[0] - src1[2]);                // 3 - 5
  *dst++ = abs(src0[1] - src2[1]);                // 1 - 7
  *dst++ = abs(src0[0] - src2[2]);                // 0 - 8
  *dst++ = abs(src0[2] - src2[0]);                // 2 - 6
  *dst++ = abs(((src1[0] + src1[2] + 1) >> 1) -   // (3+5)/2 - (1+7)/2
      ((src0[1] + src2[1] + 1) >> 1));
  *dst++ = abs(((src0[0] + src2[2] + 1) >> 1) -   // (0+8)/2 - (2+6)/2
      ((src0[2] + src2[0] + 1) >> 1));
  *dst++ = abs(((((src0[0] + src2[2] + 1) >> 1) + // ((0+8)/2+(2+6)/2)/2 - 4
      ((src0[2] + src2[0] + 1) >> 1) + 1) >> 1) - src1[1]);
  src0++;
  src1++;
  src2++;
}

#ifdef __ARM_NEON__
void line_triangular_filter_12(const uchar *src0,  // radius = 1, stride = 2
                               const uchar *src1,
                               const uchar *src2,
                               const int width,
                               uchar *dst)
{
  int i = 0;
  uint8x8_t d0 = vld1_u8(src0);
  uint8x8_t d1 = vld1_u8(src1);
  uint8x8_t d2 = vld1_u8(src2);
  src0 += 8;
  src1 += 8;
  src2 += 8;
  uint8x8_t d3 = vld1_u8(src0);
  uint8x8_t d4 = vld1_u8(src1);
  uint8x8_t d5 = vld1_u8(src2);
  src0 += 8;
  src1 += 8;
  src2 += 8;
  uint8x8_t d6 = vld1_u8(src0);
  uint8x8_t d7 = vld1_u8(src1);
  uint8x8_t d8 = vld1_u8(src2);
  src0 += 8;
  src1 += 8;
  src2 += 8;
  for (; i < width; i++) {
    uint8x8_t d9 = vld1_u8(src0);
    uint8x8_t d10 = vld1_u8(src1);
    uint8x8_t d11 = vld1_u8(src2);
    src0 += 8;
    src1 += 8;
    src2 += 8;
    uint8x8_t d12 = vld1_u8(src0);
    uint8x8_t d13 = vld1_u8(src1);
    uint8x8_t d14 = vld1_u8(src2);
    src0 += 8;
    src1 += 8;
    src2 += 8;
    d0 = vrhadd_u8(d0, d6);
    d1 = vrhadd_u8(d1, d7);
    d2 = vrhadd_u8(d2, d8);
    d3 = vrhadd_u8(d0, d3);
    d4 = vrhadd_u8(d1, d4);
    d5 = vrhadd_u8(d2, d5);
    d3 = vrhadd_u8(d3, d5);
    d3 = vrhadd_u8(d3, d4);
    vst1_u8(dst, d3);
    dst += 8;
    d0 = d6;
    d1 = d7;
    d2 = d8;
    d3 = d9;
    d4 = d10;
    d5 = d11;
    d6 = d12;
    d7 = d13;
    d8 = d14;
  } // end for i
  d0 = vrhadd_u8(d0, d6);
  d1 = vrhadd_u8(d1, d7);
  d2 = vrhadd_u8(d2, d8);
  d3 = vrhadd_u8(d0, d3);
  d4 = vrhadd_u8(d1, d4);
  d5 = vrhadd_u8(d2, d5);
  d3 = vrhadd_u8(d3, d5);
  d3 = vrhadd_u8(d3, d4);
  vst1_u8(dst, d3);
}

void line_triangular_filter_11(const uchar *src0,  // radius = 1, stride = 1
                               const uchar *src1,
                               const uchar *src2,
                               const int width,
                               uchar *dst)
{
  int i = 0;
  uint8x8_t d0 = vld1_u8(src0);
  uint8x8_t d1 = vld1_u8(src1);
  uint8x8_t d2 = vld1_u8(src2);
  src0 += 8;
  src1 += 8;
  src2 += 8;
  uint8x8_t d3 = vld1_u8(src0);
  uint8x8_t d4 = vld1_u8(src1);
  uint8x8_t d5 = vld1_u8(src2);
  src0 += 8;
  src1 += 8;
  src2 += 8;
  for (; i <= width; i++) {
    uint8x8_t d6 = vld1_u8(src0);
    uint8x8_t d7 = vld1_u8(src1);
    uint8x8_t d8 = vld1_u8(src2);
    src0 += 8;
    src1 += 8;
    src2 += 8;
    d0 = vrhadd_u8(d0, d6);
    d1 = vrhadd_u8(d1, d7);
    d2 = vrhadd_u8(d2, d8);
    d0 = vrhadd_u8(d0, d3);
    d1 = vrhadd_u8(d1, d4);
    d2 = vrhadd_u8(d2, d5);
    d0 = vrhadd_u8(d0, d2);
    d0 = vrhadd_u8(d0, d1);
    vst1_u8(dst, d0);
    dst += 8;
    d0 = d3;
    d1 = d4;
    d2 = d5;
    d3 = d6;
    d4 = d7;
    d5 = d8;
  } // end for i
}

void line_triangular_filter_21(const uchar *src0,  // radius = 2, stride = 1
                               const uchar *src1,
                               const uchar *src2,
                               const int width,
                               uchar *dst)
{
  int i = 0;
  uint8x8_t d0 = vld1_u8(src0);
  uint8x8_t d1 = vld1_u8(src1);
  uint8x8_t d2 = vld1_u8(src2);
  src0 += 8;
  src1 += 8;
  src2 += 8;
  uint8x8_t d3 = vld1_u8(src0);
  uint8x8_t d4 = vld1_u8(src1);
  uint8x8_t d5 = vld1_u8(src2);
  src0 += 8;
  src1 += 8;
  src2 += 8;
  uint8x8_t d6 = vld1_u8(src0);
  uint8x8_t d7 = vld1_u8(src1);
  uint8x8_t d8 = vld1_u8(src2);
  src0 += 8;
  src1 += 8;
  src2 += 8;
  uint8x8_t d9 = vld1_u8(src0);
  uint8x8_t d10 = vld1_u8(src1);
  uint8x8_t d11 = vld1_u8(src2);
  src0 += 8;
  src1 += 8;
  src2 += 8;
  for (; i < width; i += 2) {
    uint8x8_t d12 = vld1_u8(src0);
    uint8x8_t d13 = vld1_u8(src1);
    uint8x8_t d14 = vld1_u8(src2);
    src0 += 8;
    src1 += 8;
    src2 += 8;
    uint8x8_t d15 = vld1_u8(src0);
    uint8x8_t d16 = vld1_u8(src1);
    uint8x8_t d17 = vld1_u8(src2);
    src0 += 8;
    src1 += 8;
    src2 += 8;
    d0 = vrhadd_u8(d0, d12);
    d1 = vrhadd_u8(d1, d13);
    d2 = vrhadd_u8(d2, d14);
    d0 = vrhadd_u8(d0, d6);
    d1 = vrhadd_u8(d1, d7);
    d2 = vrhadd_u8(d2, d8);
    d0 = vrhadd_u8(d0, d2);
    d0 = vrhadd_u8(d0, d1);
    vst1_u8(dst, d0);
    dst += 8;
    d3 = vrhadd_u8(d3, d15);
    d4 = vrhadd_u8(d4, d16);
    d5 = vrhadd_u8(d5, d17);
    d3 = vrhadd_u8(d3, d9);
    d4 = vrhadd_u8(d4, d10);
    d5 = vrhadd_u8(d5, d11);
    d3 = vrhadd_u8(d3, d5);
    d3 = vrhadd_u8(d3, d4);
    vst1_u8(dst, d3);
    dst += 8;
    d0 = d6;
    d1 = d7;
    d2 = d8;
    d3 = d9;
    d4 = d10;
    d5 = d11;
    d6 = d12;
    d7 = d13;
    d8 = d14;
    d9 = d15;
    d10 = d16;
    d11 = d17;
  } // end for i
  // compute tails
  if (i == width) {
    uint8x8_t d12 = vld1_u8(src0);
    uint8x8_t d13 = vld1_u8(src1);
    uint8x8_t d14 = vld1_u8(src2);
    d0 = vrhadd_u8(d0, d12);
    d1 = vrhadd_u8(d1, d13);
    d2 = vrhadd_u8(d2, d14);
    d6 = vrhadd_u8(d0, d6);
    d7 = vrhadd_u8(d1, d7);
    d8 = vrhadd_u8(d2, d8);
    d6 = vrhadd_u8(d6, d8);
    d6 = vrhadd_u8(d6, d7);
    vst1_u8(dst, d6);
  }
}
#endif

void ComputeChannelFeatureNeon(const int img_w,
                               const int img_h,
                               const int img_step,
                               const unsigned char *img,
                               const int fimg_ystep,
                               const int fimg_xstep,
                               const int fimg_cstep,
                               unsigned char *fimg)
{
#if defined(HOBOT_SYXC)
  for (int i = 1; i < img_h - 1; i++) {
    const uchar *src1 = img + img_step * i;
    const uchar *src0 = src1 - img_step;
    const uchar *src2 = src1 + img_step;
    uchar *dst = fimg + fimg_ystep * i + fimg_xstep;
#ifdef __ARM_NEON__
    line_channel_feature_yxc_neon(src0, src1, src2, img_w, dst);
#else
    for (int j = 1; j < img_w - 1; j++) {
      pixel_channel_feature_yxc(src0, src1, src2, dst);
    }
#endif
  }
#elif defined(HOBOT_SCYX)
  int fimg_w = img_w - 2;
  int fimg_h = img_h - 2;
  uchar *dst = fimg + fimg_ystep + 1;

  // 0 -> 0
  for (int y = 0; y < img_h; y++)
    memcpy(fimg + y * fimg_ystep, img + y * img_step, sizeof(uchar) * img_w);
  dst += fimg_cstep;

  // 3 - 5
  lines_sub_abs(img + img_step,
                img + img_step + 2,
                dst, fimg_h, img_step, fimg_ystep, fimg_w);
  dst += fimg_cstep;
  // 1 - 7
  lines_sub_abs(img + 1,
                img + 2 * img_step + 1,
                dst, fimg_h, img_step, fimg_ystep, fimg_w);
  dst += fimg_cstep;
  // 0 - 8
  lines_sub_abs(img,
                img + 2 * img_step + 2,
                dst, fimg_h, img_step, fimg_ystep, fimg_w);
  dst += fimg_cstep;
  // 2 - 6
  lines_sub_abs(img + 2,
                img + 2 * img_step,
                dst, fimg_h, img_step, fimg_ystep, fimg_w);
  dst += fimg_cstep;
  // (3+5)/2 - (1+7)/2
  lines_sum_sub_abs(img + img_step,
                    img + img_step + 2,
                    img + 1,
                    img + 2 * img_step + 1,
                    dst, fimg_h, img_step, fimg_ystep, fimg_w);
  dst += fimg_cstep;
  // (0+8)/2 - (2+6)/2
  lines_sum_sub_abs(img,
                    img + 2 * img_step + 2,
                    img + 2,
                    img + 2 * img_step,
                    dst, fimg_h, img_step, fimg_ystep, fimg_w);
  dst += fimg_cstep;
  // ((0+8)/2+(2+6)/2)/2 - 4
  lines_sum4_sub_abs(img,
                     img + 2 * img_step + 2,
                     img + 2,
                     img + 2 * img_step,
                     img + img_step + 1,
                     dst, fimg_h, img_step, fimg_ystep, fimg_w);
#endif
}

void TriangularFilterNeon(const int img_w,
                          const int img_h,
                          const int img_ystep,
                          const int img_xstep,
                          const int img_cstep,
                          const unsigned char *img,
                          const int radius,
                          const int stride,
                          const int fimg_ystep,
                          const int fimg_xstep,
                          const int fimg_cstep,
                          unsigned char *fimg)
{
  unsigned char *dst, *dst_end;
  const unsigned char *src0, *src1, *src2;

  if (radius < 1 || stride < 1) {
    ERROR_INFO("invalid parameter: radius %d, stride %d", radius, stride);
  }
//  printf("ystep %d, xstep %d, ystep %d, xstep %d\n", img_ystep, img_xstep, fimg_ystep, fimg_xstep);

  int bgn_src_y = radius;
  int end_src_y = img_h - 1 - radius;
  int bgn_dst_y = (bgn_src_y + stride - 1) / stride;
  int end_dst_y = end_src_y / stride;
  int bgn_src_x = radius;
  int end_src_x = img_w - 1 - radius;
  int bgn_dst_x = (bgn_src_x + stride - 1) / stride;
  int end_dst_x = end_src_x / stride;

#if defined(HOBOT_SYXC)
  int x_stride = stride * img_xstep;
  int x_radius = radius * img_xstep;
  for (int y = bgn_dst_y; y <= end_dst_y; y++) {
    src1 = img + stride * y * img_ystep + stride * bgn_dst_x * img_xstep;
    src0 = src1 - radius * img_ystep;
    src2 = src1 + radius * img_ystep;
    dst = fimg + y * fimg_ystep + bgn_dst_x * fimg_xstep;
    dst_end = fimg + y * fimg_ystep + end_dst_x * fimg_xstep;
#ifdef __ARM_NEON__
    if (radius == 1 && stride == 2) {
      line_triangular_filter_12_neon(src0 - x_radius,
                                     src1 - x_radius,
                                     src2 - x_radius,
                                     end_dst_x - bgn_dst_x,
                                     dst);
    } else if (radius == 1 && stride == 1) {
      line_triangular_filter_11(src0 - x_radius,
                                src1 - x_radius,
                                src2 - x_radius,
                                end_dst_x - bgn_dst_x,
                                dst);
    } else if (radius == 2 && stride == 1) {
      line_triangular_filter_21(src0 - x_radius,
                                src1 - x_radius,
                                src2 - x_radius,
                                end_dst_x - bgn_dst_x,
                                dst);
    } else {
      REPORT_ERROR_POSITION;
    }
#else
    while (dst <= dst_end) {
      *dst++ =
          (((((((src0[-x_radius] + src0[x_radius] + 1) >> 1) + src0[0] + 1) >> 1)
           + ((((src2[-x_radius] + src2[x_radius] + 1) >> 1) + src2[0] + 1) >> 1)
              + 1) >> 1) +
             ((((src1[-x_radius] + src1[x_radius] + 1) >> 1) + src1[0] + 1) >> 1)
              + 1) >> 1;
      *dst++ =
          (((((((src0[-x_radius + 1] + src0[x_radius + 1] + 1) >> 1) + src0[1] + 1) >> 1)
           + ((((src2[-x_radius + 1] + src2[x_radius + 1] + 1) >> 1) + src2[1] + 1) >> 1)
              + 1) >> 1) +
             ((((src1[-x_radius + 1] + src1[x_radius + 1] + 1) >> 1) + src1[1] + 1)
                  >> 1)
              + 1) >> 1;
      *dst++ =
          (((((((src0[-x_radius + 2] + src0[x_radius + 2] + 1) >> 1) + src0[2] + 1) >> 1)
           + ((((src2[-x_radius + 2] + src2[x_radius + 2] + 1) >> 1) + src2[2] + 1) >> 1)
              + 1) >> 1) +
             ((((src1[-x_radius + 2] + src1[x_radius + 2] + 1) >> 1) + src1[2] + 1)
                  >> 1)
              + 1) >> 1;
      *dst++ =
          (((((((src0[-x_radius + 3] + src0[x_radius + 3] + 1) >> 1) + src0[3] + 1) >> 1)
           + ((((src2[-x_radius + 3] + src2[x_radius + 3] + 1) >> 1) + src2[3] + 1) >> 1)
              + 1) >> 1) +
             ((((src1[-x_radius + 3] + src1[x_radius + 3] + 1) >> 1) + src1[3] + 1)
                  >> 1)
              + 1) >> 1;
      *dst++ =
          (((((((src0[-x_radius + 4] + src0[x_radius + 4] + 1) >> 1) + src0[4] + 1) >> 1)
           + ((((src2[-x_radius + 4] + src2[x_radius + 4] + 1) >> 1) + src2[4] + 1) >> 1)
              + 1) >> 1) +
             ((((src1[-x_radius + 4] + src1[x_radius + 4] + 1) >> 1) + src1[4] + 1)
                  >> 1)
              + 1) >> 1;
      *dst++ =
          (((((((src0[-x_radius + 5] + src0[x_radius + 5] + 1) >> 1) + src0[5] + 1) >> 1)
           + ((((src2[-x_radius + 5] + src2[x_radius + 5] + 1) >> 1) + src2[5] + 1) >> 1)
              + 1) >> 1) +
             ((((src1[-x_radius + 5] + src1[x_radius + 5] + 1) >> 1) + src1[5] + 1)
                  >> 1)
              + 1) >> 1;
      *dst++ =
          (((((((src0[-x_radius + 6] + src0[x_radius + 6] + 1) >> 1) + src0[6] + 1) >> 1)
           + ((((src2[-x_radius + 6] + src2[x_radius + 6] + 1) >> 1) + src2[6] + 1) >> 1)
              + 1) >> 1) +
             ((((src1[-x_radius + 6] + src1[x_radius + 6] + 1) >> 1) + src1[6] + 1) >> 1)
              + 1) >> 1;
      *dst++ =
          (((((((src0[-x_radius + 7] + src0[x_radius + 7] + 1) >> 1) + src0[7] + 1) >> 1)
           + ((((src2[-x_radius + 7] + src2[x_radius + 7] + 1) >> 1) + src2[7] + 1) >> 1)
              + 1) >> 1) +
             ((((src1[-x_radius + 7] + src1[x_radius + 7] + 1) >> 1) + src1[7] + 1)
                  >> 1)
              + 1) >> 1;
      src0 += x_stride;
      src1 += x_stride;
      src2 += x_stride;
    }
#endif
  }
#elif defined(HOBOT_SCYX)
  for (int c = 0; c < 8; c++) {
    for (int y = bgn_dst_y; y <= end_dst_y; y++) {
      src1 = img + c * img_cstep + stride * y * img_ystep + stride * bgn_dst_x;
      src0 = src1 - radius * img_ystep;
      src2 = src1 + radius * img_ystep;
      dst = fimg + c * fimg_cstep + y * fimg_ystep + bgn_dst_x;
      dst_end = fimg + c * fimg_cstep + y * fimg_ystep + end_dst_x;
      while (dst <= dst_end) {
        *dst++ =
            (((((((src0[-radius] + src0[radius] + 1) >> 1) + src0[0] + 1) >> 1)
                + ((((src2[-radius] + src2[radius] + 1) >> 1) + src2[0] + 1) >> 1)
                + 1) >> 1) +
                ((((src1[-radius] + src1[radius] + 1) >> 1) + src1[0] + 1) >> 1)
                + 1) >> 1;
        src0 += stride;
        src1 += stride;
        src2 += stride;
      }
    }
  }
#endif
}

} // namespace alpha
} // namespace vision
} // namespace hobot
