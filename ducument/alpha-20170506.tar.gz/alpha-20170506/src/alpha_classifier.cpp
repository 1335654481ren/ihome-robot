//
//  Classifiers for Alpha Detection
//  Copyright (c) 2016 by Horizon Robotics Inc.
//  Author: Chang Huang (chang.huang@hobot.cc)
//

#include "mcms.h"
#include "alpha_classifier.h"

namespace hobot {
namespace vision {
namespace alpha {

AlphaClassifier::AlphaClassifier() {
  Init();
}

AlphaClassifier::AlphaClassifier(std::istream &is) {
  Init();
  FromStream(is);
}

AlphaClassifier::~AlphaClassifier() {
  Release();
}

void AlphaClassifier::Init() {
  dt_num_ = 0;
  dt_depth_ = 0;
  lut_dim_ = 0;
  mcms_pixels_ = NULL;
  biases_ = NULL;
  mcms_pixel_offsets_ = NULL;
  luts_ = NULL;
  fp_bits_ = NULL;
}

void AlphaClassifier::Release() {
  if (mcms_pixels_) delete[]mcms_pixels_;
  if (biases_) delete[]biases_;
  if (mcms_pixel_offsets_) delete[]mcms_pixel_offsets_;
  if (luts_) delete[]luts_;
  if (fp_bits_) delete[]fp_bits_;
  Init();
}

int AlphaClassifier::GetOutputDim() const {
  return lut_dim_;
}

void AlphaClassifier::UpdatePixelOffsets(const int xstep, const int ystep,
                                         const int cstep, const int sstep) {
  int pixel_num = 2 * dt_num_ * dt_depth_;
  if (mcms_pixel_offsets_)
    delete[]mcms_pixel_offsets_;
  mcms_pixel_offsets_ = new int[pixel_num];
  for (int i = 0; i < pixel_num; i++) {
    uchar *xycs = mcms_pixels_ + i * 4;
    int offset = xycs[0] * xstep + xycs[1] * ystep
        + xycs[2] * cstep + xycs[3] * sstep;
    mcms_pixel_offsets_[i] = offset;
    //printf("mcms_pixel_offsets[%d] = %d\n", i, offset);
  }
}

#if 0
void AlphaClassifier::Predict(const uchar *ref_pointer, int *outputs) const {
  const int *offset = mcms_pixel_offsets_;
  const uchar *bias = biases_;
  const signed char *lut = luts_;
  const uchar *fp_bit = fp_bits_;
  const int lut_size = (1 << dt_depth_) * lut_dim_;

  for (int ti = 0; ti < dt_num_; ti++) {
    int leaf_i = 0;
    for (int di = 0; di < dt_depth_; di++) {
      uchar v0 = ref_pointer[*offset++];
      uchar v1 = ref_pointer[*offset++];
      if ((v0 << 8) >= (v1 * ((*bias++) + 1))) {
        leaf_i |= 1 << di;
      }
    }
    const signed char *l = lut + leaf_i * lut_dim_;
    for (int i = 0; i < lut_dim_; i++) {
      outputs[i] += (*l++) << (*fp_bit);
    }
    lut += lut_size;
    fp_bit++;
  }
}
#else
inline void _predict(const uchar *ref_pointer,
                     int *outputs,
                     const int *offset,
                     const uchar *bias,
                     const int16_t *lut,
                     const int dt_num,
                     const int lut_size,
                     const int lut_dim)
{
//  int output[4] = {0, 0, 0, 0};
  int output0[4] = {0, 0, 0, 0};
  int output1[4] = {0, 0, 0, 0};
  int output2[4] = {0, 0, 0, 0};
  int output3[4] = {0, 0, 0, 0};
  for (int ti = 0; ti < dt_num; ti+=4) {
//    volatile uint16_t left[16], right[16];
    int leaf_0 = 0;
    int leaf_1 = 0;
    int leaf_2 = 0;
    int leaf_3 = 0;
//    left[0] = ref_pointer[*offset++]<<8;
//    right[0] = ref_pointer[*offset++];
//    left[1] = ref_pointer[*offset++]<<8;
//    right[1] = ref_pointer[*offset++];
//    left[2] = ref_pointer[*offset++]<<8;
//    right[2] = ref_pointer[*offset++];
//    left[3] = ref_pointer[*offset++]<<8;
//    right[3] = ref_pointer[*offset++];
//    leaf_0 |= (left[0] >= (right[0] * ((*bias++) + 1)));
//    leaf_0 |= (left[1] >= (right[1] * ((*bias++) + 1)))<<1;
//    leaf_0 |= (left[2] >= (right[2] * ((*bias++) + 1)))<<2;
//    leaf_0 |= (left[3] >= (right[3] * ((*bias++) + 1)))<<3;
//    left[4] = ref_pointer[*offset++]<<8;
//    right[4] = ref_pointer[*offset++];
//    left[5] = ref_pointer[*offset++]<<8;
//    right[5] = ref_pointer[*offset++];
//    left[6] = ref_pointer[*offset++]<<8;
//    right[6] = ref_pointer[*offset++];
//    left[7] = ref_pointer[*offset++]<<8;
//    right[7] = ref_pointer[*offset++];
//    leaf_1 |= (left[4] >= (right[4] * ((*bias++) + 1)));
//    leaf_1 |= (left[5] >= (right[5] * ((*bias++) + 1)))<<1;
//    leaf_1 |= (left[6] >= (right[6] * ((*bias++) + 1)))<<2;
//    leaf_1 |= (left[7] >= (right[7] * ((*bias++) + 1)))<<3;
//    left[8] = ref_pointer[*offset++]<<8;
//    right[8] = ref_pointer[*offset++];
//    left[9] = ref_pointer[*offset++]<<8;
//    right[9] = ref_pointer[*offset++];
//    left[10] = ref_pointer[*offset++]<<8;
//    right[10] = ref_pointer[*offset++];
//    left[11] = ref_pointer[*offset++]<<8;
//    right[11] = ref_pointer[*offset++];
//    leaf_2 |= (left[8] >= (right[8] * ((*bias++) + 1)));
//    leaf_2 |= (left[9] >= (right[9] * ((*bias++) + 1)))<<1;
//    leaf_2 |= (left[10] >= (right[10] * ((*bias++) + 1)))<<2;
//    leaf_2 |= (left[11] >= (right[11] * ((*bias++) + 1)))<<3;
//    left[12] = ref_pointer[*offset++]<<8;
//    right[12] = ref_pointer[*offset++];
//    left[13] = ref_pointer[*offset++]<<8;
//    right[13] = ref_pointer[*offset++];
//    left[14] = ref_pointer[*offset++]<<8;
//    right[14] = ref_pointer[*offset++];
//    left[15] = ref_pointer[*offset++]<<8;
//    right[15] = ref_pointer[*offset++];
//    leaf_3 |= (left[12] >= (right[12] * ((*bias++) + 1)));
//    leaf_3 |= (left[13] >= (right[13] * ((*bias++) + 1)))<<1;
//    leaf_3 |= (left[14] >= (right[14] * ((*bias++) + 1)))<<2;
//    leaf_3 |= (left[15] >= (right[15] * ((*bias++) + 1)))<<3;
    uchar v0 = ref_pointer[*offset++];
    uchar v1 = ref_pointer[*offset++];
    uchar v2 = ref_pointer[*offset++];
    uchar v3 = ref_pointer[*offset++];
    uchar v4 = ref_pointer[*offset++];
    uchar v5 = ref_pointer[*offset++];
    uchar v6 = ref_pointer[*offset++];
    uchar v7 = ref_pointer[*offset++];
    leaf_0 |= ((v0 << 8) >= (v1 * ((*bias++) + 1)));
    leaf_0 |= ((v2 << 8) >= (v3 * ((*bias++) + 1)))<<1;
    leaf_0 |= ((v4 << 8) >= (v5 * ((*bias++) + 1)))<<2;
    leaf_0 |= ((v6 << 8) >= (v7 * ((*bias++) + 1)))<<3;
    v0 = ref_pointer[*offset++];
    v1 = ref_pointer[*offset++];
    v2 = ref_pointer[*offset++];
    v3 = ref_pointer[*offset++];
    v4 = ref_pointer[*offset++];
    v5 = ref_pointer[*offset++];
    v6 = ref_pointer[*offset++];
    v7 = ref_pointer[*offset++];
    leaf_1 |= ((v0 << 8) >= (v1 * ((*bias++) + 1)));
    leaf_1 |= ((v2 << 8) >= (v3 * ((*bias++) + 1)))<<1;
    leaf_1 |= ((v4 << 8) >= (v5 * ((*bias++) + 1)))<<2;
    leaf_1 |= ((v6 << 8) >= (v7 * ((*bias++) + 1)))<<3;
    v0 = ref_pointer[*offset++];
    v1 = ref_pointer[*offset++];
    v2 = ref_pointer[*offset++];
    v3 = ref_pointer[*offset++];
    v4 = ref_pointer[*offset++];
    v5 = ref_pointer[*offset++];
    v6 = ref_pointer[*offset++];
    v7 = ref_pointer[*offset++];
    leaf_2 |= ((v0 << 8) >= (v1 * ((*bias++) + 1)));
    leaf_2 |= ((v2 << 8) >= (v3 * ((*bias++) + 1)))<<1;
    leaf_2 |= ((v4 << 8) >= (v5 * ((*bias++) + 1)))<<2;
    leaf_2 |= ((v6 << 8) >= (v7 * ((*bias++) + 1)))<<3;
    v0 = ref_pointer[*offset++];
    v1 = ref_pointer[*offset++];
    v2 = ref_pointer[*offset++];
    v3 = ref_pointer[*offset++];
    v4 = ref_pointer[*offset++];
    v5 = ref_pointer[*offset++];
    v6 = ref_pointer[*offset++];
    v7 = ref_pointer[*offset++];
    leaf_3 |= ((v0 << 8) >= (v1 * ((*bias++) + 1)));
    leaf_3 |= ((v2 << 8) >= (v3 * ((*bias++) + 1)))<<1;
    leaf_3 |= ((v4 << 8) >= (v5 * ((*bias++) + 1)))<<2;
    leaf_3 |= ((v6 << 8) >= (v7 * ((*bias++) + 1)))<<3;
//    uchar v8 = ref_pointer[*offset++];
//    uchar v9 = ref_pointer[*offset++];
//    uchar v10 = ref_pointer[*offset++];
//    uchar v11 = ref_pointer[*offset++];
//    uchar v12 = ref_pointer[*offset++];
//    uchar v13 = ref_pointer[*offset++];
//    uchar v14 = ref_pointer[*offset++];
//    uchar v15 = ref_pointer[*offset++];
//    leaf_1 |= ((v8 << 8) >= (v9 * ((*bias++) + 1)));
//    leaf_1 |= ((v10 << 8) >= (v11 * ((*bias++) + 1)))<<1;
//    leaf_1 |= ((v12 << 8) >= (v13 * ((*bias++) + 1)))<<2;
//    leaf_1 |= ((v14 << 8) >= (v15 * ((*bias++) + 1)))<<3;
//    uchar v16 = ref_pointer[*offset++];
//    uchar v17 = ref_pointer[*offset++];
//    uchar v18 = ref_pointer[*offset++];
//    uchar v19 = ref_pointer[*offset++];
//    uchar v20 = ref_pointer[*offset++];
//    uchar v21 = ref_pointer[*offset++];
//    uchar v22 = ref_pointer[*offset++];
//    uchar v23 = ref_pointer[*offset++];
//    leaf_2 |= ((v16 << 8) >= (v17 * ((*bias++) + 1)));
//    leaf_2 |= ((v18 << 8) >= (v19 * ((*bias++) + 1)))<<1;
//    leaf_2 |= ((v20 << 8) >= (v21 * ((*bias++) + 1)))<<2;
//    leaf_2 |= ((v22 << 8) >= (v23 * ((*bias++) + 1)))<<3;
//    uchar v24 = ref_pointer[*offset++];
//    uchar v25 = ref_pointer[*offset++];
//    uchar v26 = ref_pointer[*offset++];
//    uchar v27 = ref_pointer[*offset++];
//    uchar v28 = ref_pointer[*offset++];
//    uchar v29 = ref_pointer[*offset++];
//    uchar v30 = ref_pointer[*offset++];
//    uchar v31 = ref_pointer[*offset++];
//    leaf_3 |= ((v24 << 8) >= (v25 * ((*bias++) + 1)));
//    leaf_3 |= ((v26 << 8) >= (v27 * ((*bias++) + 1)))<<1;
//    leaf_3 |= ((v28 << 8) >= (v29 * ((*bias++) + 1)))<<2;
//    leaf_3 |= ((v30 << 8) >= (v31 * ((*bias++) + 1)))<<3;
//    const signed char *l = lut + leaf_i * lut_dim_;
//    for (int i = 0; i < lut_dim_; i++) {
//      outputs[i] += (*l++) << (*fp_bit);
//    }
//    output[0] += lut[leaf_0] << (*fp_bit++);
//    output[1] += lut[leaf_1+16] << (*fp_bit++);
//    output[2] += lut[leaf_2+32] << (*fp_bit++);
//    output[3] += lut[leaf_3+48] << (*fp_bit++);
    if (lut_dim != 1) {
      leaf_0 *= lut_dim;
      leaf_1 *= lut_dim;
      leaf_2 *= lut_dim;
      leaf_3 *= lut_dim;
    }
    for (int i = 0; i < lut_dim; i++) {
      output0[i] += lut[leaf_0++];
      output1[i] += lut[leaf_1++ +lut_size];
      output2[i] += lut[leaf_2++ +lut_size*2];
      output3[i] += lut[leaf_3++ +lut_size*3];
    }
    lut += lut_size*4;
//    fp_bit++;
  }
  for (int i = 0; i < lut_dim; i++) {
    outputs[i] += output0[i] + output1[i] + output2[i] + output3[i];
  }
}

template<>
void AlphaClassifier::Predict<1>(const uchar *ref_pointer, int *outputs) const
{
#if 0
  const int *offset = mcms_pixel_offsets_;
  const uchar *bias = biases_;
  const int16_t *lut = lut16s_;
  int output0[4] = {0, 0, 0, 0};
  int output1[4] = {0, 0, 0, 0};
  int output2[4] = {0, 0, 0, 0};
  int output3[4] = {0, 0, 0, 0};
  for (int ti = 0; ti < dt_num_; ti+=4) {
    int leaf_0 = 0;
    int leaf_1 = 0;
    int leaf_2 = 0;
    int leaf_3 = 0;
    uchar v0 = ref_pointer[*offset++];
    uchar v1 = ref_pointer[*offset++];
    uchar v2 = ref_pointer[*offset++];
    uchar v3 = ref_pointer[*offset++];
    uchar v4 = ref_pointer[*offset++];
    uchar v5 = ref_pointer[*offset++];
    uchar v6 = ref_pointer[*offset++];
    uchar v7 = ref_pointer[*offset++];
    leaf_0 |= ((v0 << 8) >= (v1 * ((*bias++) + 1)));
    leaf_0 |= ((v2 << 8) >= (v3 * ((*bias++) + 1)))<<1;
    leaf_0 |= ((v4 << 8) >= (v5 * ((*bias++) + 1)))<<2;
    leaf_0 |= ((v6 << 8) >= (v7 * ((*bias++) + 1)))<<3;
    v0 = ref_pointer[*offset++];
    v1 = ref_pointer[*offset++];
    v2 = ref_pointer[*offset++];
    v3 = ref_pointer[*offset++];
    v4 = ref_pointer[*offset++];
    v5 = ref_pointer[*offset++];
    v6 = ref_pointer[*offset++];
    v7 = ref_pointer[*offset++];
    leaf_1 |= ((v0 << 8) >= (v1 * ((*bias++) + 1)));
    leaf_1 |= ((v2 << 8) >= (v3 * ((*bias++) + 1)))<<1;
    leaf_1 |= ((v4 << 8) >= (v5 * ((*bias++) + 1)))<<2;
    leaf_1 |= ((v6 << 8) >= (v7 * ((*bias++) + 1)))<<3;
    v0 = ref_pointer[*offset++];
    v1 = ref_pointer[*offset++];
    v2 = ref_pointer[*offset++];
    v3 = ref_pointer[*offset++];
    v4 = ref_pointer[*offset++];
    v5 = ref_pointer[*offset++];
    v6 = ref_pointer[*offset++];
    v7 = ref_pointer[*offset++];
    leaf_2 |= ((v0 << 8) >= (v1 * ((*bias++) + 1)));
    leaf_2 |= ((v2 << 8) >= (v3 * ((*bias++) + 1)))<<1;
    leaf_2 |= ((v4 << 8) >= (v5 * ((*bias++) + 1)))<<2;
    leaf_2 |= ((v6 << 8) >= (v7 * ((*bias++) + 1)))<<3;
    v0 = ref_pointer[*offset++];
    v1 = ref_pointer[*offset++];
    v2 = ref_pointer[*offset++];
    v3 = ref_pointer[*offset++];
    v4 = ref_pointer[*offset++];
    v5 = ref_pointer[*offset++];
    v6 = ref_pointer[*offset++];
    v7 = ref_pointer[*offset++];
    leaf_3 |= ((v0 << 8) >= (v1 * ((*bias++) + 1)));
    leaf_3 |= ((v2 << 8) >= (v3 * ((*bias++) + 1)))<<1;
    leaf_3 |= ((v4 << 8) >= (v5 * ((*bias++) + 1)))<<2;
    leaf_3 |= ((v6 << 8) >= (v7 * ((*bias++) + 1)))<<3;
    for (int i = 0; i < 1; i++) {
      output0[i] += lut[leaf_0++];
      output1[i] += lut[leaf_1++ + 16];
      output2[i] += lut[leaf_2++ + 32];
      output3[i] += lut[leaf_3++ + 48];
    }
    lut += 64;
  }
  for (int i = 0; i < 1; i++) {
    outputs[i] += output0[i] + output1[i] + output2[i] + output3[i];
  }
#else
  _predict(ref_pointer, outputs, mcms_pixel_offsets_, biases_,
           lut16s_, dt_num_, 16, 1);
#endif
}

template <>
void AlphaClassifier::Predict<4>(const uchar *ref_pointer, int *outputs) const
{
  _predict(ref_pointer, outputs, mcms_pixel_offsets_, biases_,
           lut16s_, dt_num_, 64, 4);
}
#endif

std::istream &AlphaClassifier::FromStream(std::istream &is) {
  Release();
  ReadFromStream(is, dt_num_);
  ReadFromStream(is, dt_depth_);
  ReadFromStream(is, lut_dim_);
  mcms_pixels_ = new uchar[4 * 2 * dt_depth_ * dt_num_];
  is.read((char *) mcms_pixels_, sizeof(uchar) * 4 * 2 * dt_depth_ * dt_num_);
  biases_ = new uchar[dt_depth_ * dt_num_];
  is.read((char *) biases_, sizeof(uchar) * dt_depth_ * dt_num_);
  luts_ = new signed char[(1 << dt_depth_) * lut_dim_ * dt_num_];
  is.read((char *)luts_, sizeof(char) * (1 << dt_depth_) * lut_dim_ * dt_num_);
  fp_bits_ = new uchar[dt_num_];
  is.read((char *) fp_bits_, sizeof(uchar) * dt_num_);
  lut16s_ = new int16_t[(1 << dt_depth_) * lut_dim_ * dt_num_];
  int idx = 0;
  for (int i = 0; i < dt_num_; i++) {
    unsigned char fp_bit = fp_bits_[i];
    for (int j = 0; j < (1 << dt_depth_) * lut_dim_; j++) {
      lut16s_[idx] = luts_[idx] << fp_bit;
      idx++;
    }
  }
  return is;
}

std::ostream &operator<<(std::ostream &out, AlphaClassifier &in)
{
  out << "dt_num_:" << in.dt_num_ << std::endl;
  out << "dt_depth_:" << in.dt_depth_ << std::endl;
  out << "lut_dim_:" << in.lut_dim_ << std::endl;
  out << "mcms_pixels_:";
  for (int i = 0; i < 4*2*in.dt_depth_ * in.dt_num_; i++) {
    out << (int)in.mcms_pixels_[i] << " ";
  }
  out << std::endl;
  out << "biases_:";
  for (int i = 0; i < in.dt_depth_ * in.dt_num_; i++) {
    out << (int)in.biases_[i] << " ";
  }
  out << std::endl;
  out << "luts_:";
  for (int i = 0; i < (1 << in.dt_depth_) * in.lut_dim_ * in.dt_num_; i++) {
    out << (int)in.luts_[i] << " ";
  }
  out << std::endl;
  out << "fp_bits_";
  for (int i = 0; i < in.dt_num_; i++) {
    out << (int)in.fp_bits_[i] << " ";
  }
  out << std::endl;
  return out;
}

} // namespace alpha
} // namespace vision
} // namespace hobot
