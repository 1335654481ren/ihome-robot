//
//  Resizing Image Functions and Classes
//  Copyright (c) 2016 by Horizon Robotics Inc.
//  Author: Chang Huang (chang.huang@hobot.cc)
//

#include "image_resizer.h"
#include <math.h>

namespace hobot {
namespace vision {
namespace alpha {
const int kBilinearInterpolationDecimalBit = 12;

inline void _hResizeBI(const uchar *src_row, const int src_w, const int dst_w,
                       const uint *row_idx_weight, uint *dst_row) {
  if (src_w == 1) {
    dst_row[0] = src_row[0];
    return;
  }

  int i = 0;
  for (; i <= dst_w - 4; i += 4) {
    uint idx0 = row_idx_weight[0];
    uint w00 = row_idx_weight[1];
    uint w10 = row_idx_weight[2];
    uint idx1 = row_idx_weight[3];
    uint w01 = row_idx_weight[4];
    uint w11 = row_idx_weight[5];
    uint idx2 = row_idx_weight[6];
    uint w02 = row_idx_weight[7];
    uint w12 = row_idx_weight[8];
    uint idx3 = row_idx_weight[9];
    uint w03 = row_idx_weight[10];
    uint w13 = row_idx_weight[11];
    w00 *= src_row[idx0++];
    w01 *= src_row[idx1++];
    w02 *= src_row[idx2++];
    w03 *= src_row[idx3++];
    w00 += w10 * src_row[idx0];
    w01 += w11 * src_row[idx1];
    w02 += w12 * src_row[idx2];
    w03 += w13 * src_row[idx3];
    dst_row[0] = w00;
    dst_row[1] = w01;
    dst_row[2] = w02;
    dst_row[3] = w03;
    dst_row += 4;
    row_idx_weight += 12;
  }// end for i

  for (; i < dst_w; i++) {
    uint idx0 = row_idx_weight[0];
    uint w00 = row_idx_weight[1];
    uint w10 = row_idx_weight[2];
    w00 *= src_row[idx0++];
    w00 += w10 * src_row[idx0];
    *dst_row++ = w00;
    row_idx_weight += 3;
  }// end for i
}

inline void _vResizeBI(const int dst_w,
                       const uint *row0, const uint w0,
                       const uint *row1, const uint w1,
                       const int prec_bits,
                       uchar *dst_row) {
  uchar *dst_row_end = dst_row + dst_w;
  const int half = 1 << (prec_bits - 1);
  while (dst_row < dst_row_end) {
    *dst_row++ = ((*row0++) * w0 + (*row1++) * w1 + half) >> prec_bits;
  }
}

int ResizeBilinearInterpolation(const int src_w, const int src_h,
                                const int src_step, const uchar *src_img,
                                const int dst_w, const int dst_h,
                                const int dst_step, uchar *dst_img,
                                const int buf_size, uint *buf) {
  //compute buffer size
  int needed_buf_size = 2 * AlignedStepRoundUp(dst_w) + 3 * dst_w;
  if (src_img == NULL || dst_img == NULL)
    return needed_buf_size;

  bool native_buf = false;
  if (buf == NULL) {
    //use native buffer
    native_buf = true;
    MallocAlignedMemory((void *&) buf, needed_buf_size * sizeof(uint));
  } else {
    //use external buffer
    if (buf_size < needed_buf_size)
      return needed_buf_size;
  }

  //set three buffer pointers
  uint *row_buf0 = buf;
  uint *row_buf1 = buf + AlignedStepRoundUp(dst_w);
  uint *row_idx_weight = row_buf1 + AlignedStepRoundUp(dst_w);

  //calculate scale factor
  float hscale = float(dst_w) / src_w;
  float vscale = float(dst_h) / src_h;
  float recip_hscale = float(src_w) / dst_w;
  float recip_vscale = float(src_h) / dst_h;

  float src_fx = 0.5f * recip_hscale - 0.5f;
  uint *p = row_idx_weight;
  int src_w_m1 = src_w - 1;
  //for each dst pixel of a row
  for (int x = 0; x < dst_w; x++) {
    int src_ix = int(src_fx);
    //compute idx0, weight0 and weight1
    if (src_ix < 0) {
      //to the left-most point
      p[0] = 0;
      p[1] = 1 << kBilinearInterpolationDecimalBit;
      p[2] = 0;
    } else if (src_ix < src_w_m1) {
      p[0] = src_ix;
      p[2] = uint(
          (src_fx - src_ix) * (1 << kBilinearInterpolationDecimalBit) + 0.5f);
      p[1] = (1 << kBilinearInterpolationDecimalBit) - p[2];
    } else {
      //to the right-most point
      p[0] = src_w_m1 - 1;
      p[1] = 0;
      p[2] = 1 << kBilinearInterpolationDecimalBit;
    }
    p += 3;
    //next dst pixel in a row
    src_fx += recip_hscale;
  }

  //for each row
  float src_fy = 0.5f * recip_vscale - 0.5f;
  int src_h_m1 = src_h - 1;
  int prev_line0 = -2;
  for (int y = 0; y < dst_h; y++) {
    int src_iy = int(src_fy);
    int line0;
    uint iw0, iw1;
    if (src_iy < 0) {
      //to the top pixel
      line0 = 0;
      iw0 = 1 << kBilinearInterpolationDecimalBit;
      iw1 = 0;
    } else if (src_iy < src_h_m1) {
      //in the middle
      line0 = src_iy;
      iw1 = uint(
          (src_fy - src_iy) * (1 << kBilinearInterpolationDecimalBit) + 0.5f);
      iw0 = (1 << kBilinearInterpolationDecimalBit) - iw1;
    } else {
      //to the bottom pixel
      line0 = src_h_m1 - 1;
      iw0 = 0;
      iw1 = 1 << kBilinearInterpolationDecimalBit;
    }

    if (line0 == prev_line0 + 1) {
      //reuse previous row_buf1
      uint *tmp = row_buf0;
      row_buf0 = row_buf1;
      row_buf1 = tmp;
      //compute row_buf1
      _hResizeBI(src_img + (line0 + 1) * src_step,
                 src_w,
                 dst_w,
                 row_idx_weight,
                 row_buf1);
    } else if (line0 != prev_line0) {
      //compute both row_buf0 and row_buf1
      _hResizeBI(src_img + line0 * src_step,
                 src_w,
                 dst_w,
                 row_idx_weight,
                 row_buf0);
      _hResizeBI(src_img + (line0 + 1) * src_step,
                 src_w,
                 dst_w,
                 row_idx_weight,
                 row_buf1);
    }

    //merge two lines
    _vResizeBI(dst_w,
               row_buf0,
               iw0,
               row_buf1,
               iw1,
               2 * kBilinearInterpolationDecimalBit,
               dst_img + y * dst_step);

    //next row
    prev_line0 = line0;
    src_fy += recip_vscale;
  }

  if (native_buf) {
    //release native buffer
    FreeAlignedMemory((void *&) buf);
  }

  return 0;
}

inline void _hFilter8Bits(const uchar *src_row, const int row_len,
                          const int filter_sz, const uchar *filter,
                          uchar *dst_row) {
  if (filter_sz % 2 != 1) {
    ERROR_INFO("filter size must be odd! %d", filter_sz);
  }
  const int filter_hsz = filter_sz >> 1;

  for (int i = 0; i < row_len; i++) {
    int sum = 0;
    for (int j = 0; j < filter_sz; j++) {
      int k = i - filter_hsz + j;
      if (k < 0) {
        k = 0;
      } else if (k >= row_len) {
        k = row_len - 1;
      }
      sum += filter[j] * src_row[k];
    }
    dst_row[i] = (sum + 128) >> 8;
  }
}

inline void _vFilter8Bits(const uchar *src_rows[], const int row_len,
                          const int filter_sz, const uchar *filter,
                          uchar *dst_row) {
  if (filter_sz % 2 != 1) {
    ERROR_INFO("filter size must be odd! %d", filter_sz);
  }
  const int filter_hsz = filter_sz >> 1;

  for (int i = 0; i < row_len; i++) {
    int sum = 0;
    for (int j = 0; j < filter_sz; j++) {
      sum += filter[j] * src_rows[j][i];
    }
    dst_row[i] = (sum + 128) >> 8;
  }
}

void FilterImage8Bits(const int width, const int height,
                      const int step, const uchar *src,
                      const int hor_filter_sz, const uchar *hor_filter,
                      const int ver_filter_sz, const uchar *ver_filter,
                      uchar *dst, uchar *buf) {

  const uchar *s;
  uchar *d;
  if (dst == NULL) {
    ERROR_INFO("dst is NULL");
  }

  if (hor_filter && hor_filter_sz > 0) {
    //apply horizontal filter
    if (ver_filter && ver_filter_sz > 0) {
      s = src;
      d = buf;
      if (d == NULL) {
        ERROR_INFO("buffer is NULL");
      }
    } else {
      s = src;
      d = dst;
    }
    for (int y = 0; y < height; y++) {
      _hFilter8Bits(s + y * step, width,
                    hor_filter_sz, hor_filter, d + y * step);
    }
  }

  if (ver_filter && ver_filter_sz > 0) {
    if (ver_filter_sz % 2 != 1) {
      ERROR_INFO("filter size must be odd! %d", ver_filter_sz);
    }
    const int ver_filter_hsz = ver_filter_sz >> 1;
    if (hor_filter && hor_filter_sz > 0) {
      s = buf;
    } else {
      s = src;
    }
    d = dst;
    const uchar **src_rows = new const uchar *[ver_filter_sz];
    for (int y = 0; y < height; y++) {
      for (int i = 0; i < ver_filter_sz; i++) {
        int row = y + i - ver_filter_hsz;
        if (row < 0) {
          row = 0;
        } else if (row >= height) {
          row = height - 1;
        }
        src_rows[i] = s + row * step;
      }
      _vFilter8Bits(src_rows, width, ver_filter_sz, ver_filter, d + y * step);
    }
    delete[]src_rows;
  }
}

//filter with template of size 5, weight sum 256
inline void _hFilter5W256(const uchar *src_row, const int row_len,
                          const uchar *filter5, uchar *dst_row) {

  uint sum0, sum1, sum2, sum3;
  if (row_len == 0) {
    return;
  } else if (row_len == 1) {
    dst_row[0] = src_row[0];
    return;
  }

  int row_len_m1 = row_len - 1;
  int row_len_m5 = row_len - 5;

  //first two pixels
  sum0 = src_row[0] * filter5[0],
      sum1 = src_row[0] * filter5[0];
  sum0 += src_row[0] * filter5[1],
      sum1 += src_row[0] * filter5[1];
  sum0 += src_row[0] * filter5[2],
      sum1 += src_row[1] * filter5[2];
  sum0 += src_row[1] * filter5[3],
      sum1 += src_row[MIN(2, row_len_m1)] * filter5[3];
  sum0 += src_row[MIN(2, row_len_m1)] * filter5[4],
      sum1 += src_row[MIN(3, row_len_m1)] * filter5[4];
  dst_row[0] = (sum0 + 128) >> 8;
  dst_row[1] = (sum1 + 128) >> 8;

  //coming pixels
  int i = 2;
  const uchar *s = src_row + 2;
  uchar *d = dst_row + 2;
  for (; i < row_len_m5; i += 4) {
    sum0 = s[-2] * filter5[0],
        sum1 = s[-1] * filter5[0];
    sum2 = s[0] * filter5[0];
    sum3 = s[1] * filter5[0];
    sum0 += s[-1] * filter5[1],
        sum1 += s[0] * filter5[1];
    sum2 += s[1] * filter5[1];
    sum3 += s[2] * filter5[1];
    sum0 += s[0] * filter5[2],
        sum1 += s[1] * filter5[2];
    sum2 += s[2] * filter5[2];
    sum3 += s[3] * filter5[2];
    sum0 += s[1] * filter5[3],
        sum1 += s[2] * filter5[3];
    sum2 += s[3] * filter5[3];
    sum3 += s[4] * filter5[3];
    sum0 += s[2] * filter5[4],
        sum1 += s[3] * filter5[4];
    sum2 += s[4] * filter5[4];
    sum3 += s[5] * filter5[4];
    d[0] = (sum0 + 128) >> 8;
    d[1] = (sum1 + 128) >> 8;
    d[2] = (sum2 + 128) >> 8;
    d[3] = (sum3 + 128) >> 8;
    s += 4;
    d += 4;
  }

  //last few pixels
  for (; i < row_len; i++) {
    sum0 = src_row[i - 2] * filter5[0],
    sum0 += src_row[i - 1] * filter5[1],
    sum0 += src_row[i] * filter5[2],
    sum0 += src_row[MIN(i + 1, row_len_m1)] * filter5[3],
    sum0 += src_row[MIN(i + 2, row_len_m1)] * filter5[4],
    dst_row[i] = (sum0 + 128) >> 8;
  }
}

void GetFilter5ForDownSample(const float down_sample_scale,
                             const float Nyquist_freq_ratio, uchar *filter5) {

  float
      sigma_recip = down_sample_scale / sqrtf(-8.0f * logf(Nyquist_freq_ratio));
  //printf("sigma %f\n", 1.0f / sigma_recip);
  float sum_w_f = 0;
  float filter5_f[5];
  for (int i = 0; i < 5; i++) {
    float dist = sigma_recip * (i - 2);
    sum_w_f += filter5_f[i] = expf(-0.5f * dist * dist);
  }
  sum_w_f = 1.0f / sum_w_f;
  int sum_w = 0;
  for (int i = 0; i < 5; i++) {
    sum_w += filter5[i] = int(256 * filter5_f[i] * sum_w_f + 0.5f);
  }
  if (sum_w < 128 || filter5[2] == sum_w) {
    ERROR_INFO("sum_w %d, filter %d %d %d %d %d", sum_w,
               filter5[0], filter5[1], filter5[2],
               filter5[3], filter5[4]);
  }
  //to make their sum 256
  filter5[2] += 256 - sum_w;
}

void HorFilter5W256(const int width, const int height,
                    const int step, const uchar *src,
                    const uchar *filter5, uchar *dst) {
  if (src == NULL || filter5 == NULL || dst == NULL) {
    ERROR_INFO("src, filter5 or dst is NULL, %p %p %p", src, filter5, dst);
  }

  for (int y = 0; y < height; y++) {
    _hFilter5W256(src + y * step, width, filter5, dst + y * step);
  }
}



////////////////////////////////////////////////////////////////////////////////

int ResizeBilinearInterpolationHW(const int src_w, const int src_h,
                                  const int src_step, const uchar *src_img,
                                  const int hb, const int hd,
                                  const int vb, const int vd,
                                  const int dst_step, uchar *dst_img,
                                  int &dst_w, int &dst_h,
                                  const int buf_size, uint *buf) {

  if (hb + vb > 24) {
    ERROR_INFO("hb + vb must not be greater than 24! %d %d", hb, vb);
  }

  //calculate dst image size
  const int hn = 1 << hb;
  const int vn = 1 << vb;
  dst_w = (src_w * hn + (hd >> 1)) / hd;
  dst_h = (src_h * vn + (vd >> 1)) / vd;
  //printf("%dx%d\n", dst_w, dst_h);

  //compute buffer size
  int needed_buf_size = 2 * AlignedStepRoundUp(dst_w) + 3 * dst_w;
  if (src_img == NULL || dst_img == NULL)
    return needed_buf_size;

  bool native_buf = false;
  if (buf == NULL) {
    //use native buffer
    native_buf = true;
    MallocAlignedMemory((void *&) buf, needed_buf_size * sizeof(uint));
  } else {
    //use external buffer
    if (buf_size < needed_buf_size)
      return needed_buf_size;
  }

  //set three buffer pointers
  uint *row_buf0 = buf;
  uint *row_buf1 = buf + AlignedStepRoundUp(dst_w);
  uint *row_idx_weight = row_buf1 + AlignedStepRoundUp(dst_w);

  //calculate horizontal interpolation weights
  const int src_w_m1 = src_w - 1;
  int src_ix = 0;              //integer part of x
  int src_rx = (hd - hn) >> 1;  //residual part of x
  int x = 0;                    //check dst width
  uint *p = row_idx_weight;

  //dst pixels that only use left-most src pixel
  while (src_rx < 0) {
    p[0] = 0;
    p[1] = hn;
    p[2] = 0;
    p += 3;
    src_rx += hd;
    x++;
  }

  //dst pixels that need interpolation
  while (1) {
    while (src_rx > hn) {
      src_ix++;
      src_rx -= hn;
    }
    if (src_ix >= src_w_m1) {
      break;
    }
    p[0] = src_ix;
    p[1] = hn - src_rx;
    p[2] = src_rx;
    p += 3;
    src_rx += hd;
    x++;
  }

  //dst pixels that only use right-most src pixel
  while (src_ix == src_w_m1 && src_rx < (hn >> 1)) {
    p[0] = src_w_m1 - 1;
    p[1] = 0;
    p[2] = hn;
    p += 3;
    src_rx += hd;
    x++;
  }

  if (x != dst_w) {
    ERROR_INFO("x != dst_w, %d, %d", x, dst_w);
  }

  //for each row
  const int src_h_m1 = src_h - 1;
  int src_iy = 0;                //integer part of y
  int src_ry = (vd - vn) >> 1;    //residual part of y
  int buf0_src_y = -100, buf1_src_y = -100;

  //dst pixels that only use top-most src pixel
  int y = 0;
  while (src_ry < 0) {
    if (buf0_src_y != 0) {
      _hResizeBI(src_img, src_w, dst_w, row_idx_weight, row_buf0);
      buf0_src_y = 0;
    }
    uchar *dst_line = dst_img + y * dst_step;
    int half = 1 << (hb - 1);
    for (x = 0; x < dst_w; x++) {
      dst_line[x] = (row_buf0[x] + half) >> hb;
    }
    src_ry += vd;
    y++;
  }

  //dst pixels that needs interpolation
  while (1) {
    while (src_ry > vn) {
      src_iy++;
      src_ry -= vn;
    }
    if (src_iy >= src_h_m1) {
      break;
    }
    uint iw0 = vn - src_ry;
    uint iw1 = src_ry;
    //update both line buffers
    if (buf1_src_y == src_iy) {
      //reuse previous line buffer
      uint *tmp = row_buf0;
      row_buf0 = row_buf1;
      row_buf1 = tmp;
      //compute row_buf1
      _hResizeBI(src_img + (src_iy + 1) * src_step,
                 src_w,
                 dst_w,
                 row_idx_weight,
                 row_buf1);
    } else if (buf0_src_y == src_iy && buf1_src_y == src_iy + 1) {
      //reuse both line buffers
    } else {
      //reuse nothing
      _hResizeBI(src_img + src_iy * src_step,
                 src_w,
                 dst_w,
                 row_idx_weight,
                 row_buf0);
      _hResizeBI(src_img + (src_iy + 1) * src_step,
                 src_w,
                 dst_w,
                 row_idx_weight,
                 row_buf1);
    }
    buf0_src_y = src_iy;
    buf1_src_y = src_iy + 1;

    //merge two lines
    _vResizeBI(dst_w,
               row_buf0,
               iw0,
               row_buf1,
               iw1,
               hb + vb,
               dst_img + y * dst_step);

    //next row
    src_ry += vd;
    y++;
  }

  //dst pixels that only use bottom-most src pixel
  while (src_iy == src_h_m1 && src_ry < (vn >> 1)) {
    if (buf1_src_y != src_h_m1) {
      _hResizeBI(src_img + (src_h_m1 - 1) * src_step,
                 src_w,
                 dst_w,
                 row_idx_weight,
                 row_buf1);
      buf1_src_y = src_h_m1;
    }
    uchar *dst_line = dst_img + y * dst_step;
    int half = 1 << (hb - 1);
    for (x = 0; x < dst_w; x++) {
      dst_line[x] = (row_buf1[x] + half) >> hb;
    }
    src_ry += vd;
    y++;
  }

  if (y != dst_h) {
    ERROR_INFO("y != dst_h, %d, %d", y, dst_h);
  }

  if (native_buf) {
    //release native buffer
    FreeAlignedMemory((void *&) buf);
  }

  return 0;

}


/////////////////////////////////////////////////


GreyImageResizer::GreyImageResizer() {
  shrink_buf_size_ = 0;
  shrink_buf_ = NULL;
  buf_size_ = 0;
  buf_ = NULL;
  filter_buf_size_ = 0;
  filter_buf_[0] = filter_buf_[1] = NULL;
}

GreyImageResizer::~GreyImageResizer() {
  if (shrink_buf_)
    FreeAlignedMemory((void *&) shrink_buf_);
  if (buf_)
    FreeAlignedMemory((void *&) buf_);
  for (int j = 0; j < 2; j++) {
    FreeAlignedMemory((void *&) filter_buf_[j]);
  }
}

void GreyImageResizer::ResizeGreyImage(const int src_w, const int src_h,
                                       const int src_step, const uchar *src_img,
                                       const int dst_w, const int dst_h,
                                       const int dst_step, uchar *dst_img) {
  int sw = src_w, sh = src_h, ss = src_step;
  const uchar *simg = src_img;

  //shrink image if needed
  while (sw >= 2 * dst_w && sh >= 2 * dst_h) {
    int shrink_img_w = sw >> 1;
    int shrink_img_h = sh >> 1;
    int shrink_img_step = AlignedStepRoundUp(shrink_img_w);
    size_t shrink_buf_needed = size_t(shrink_img_step) * shrink_img_h;
    if (shrink_buf_needed > shrink_buf_size_) {
      FreeAlignedMemory((void *&) shrink_buf_);
      MallocAlignedMemory((void *&) shrink_buf_, shrink_buf_needed);
      shrink_buf_size_ = shrink_buf_needed;
    }

    for (int y = 0; y < shrink_img_h; y++) {
      const uchar *src = simg + (y << 1) * ss;
      uchar *dst = shrink_buf_ + y * shrink_img_step;
      uchar *dst_end = dst + shrink_img_w;
      while (dst < dst_end) {
        *dst++ = (src[0] + src[1] + src[ss] + src[ss + 1] + 2) >> 2;
        src += 2;
      }
    }

    sw = shrink_img_w;
    sh = shrink_img_h;
    ss = shrink_img_step;
    simg = shrink_buf_;
  }

  //bilinear interpolation
  if (sw == dst_w && sh == dst_h) {
    //bilinear interpolation is NOT needed
    for (int y = 0; y < dst_h; y++) {
      const uchar *src = simg + y * ss;
      uchar *dst = dst_img + y * dst_step;
      for (int x = 0; x < dst_w; x++) {
        dst[x] = src[x];
      }
    }
  } else {
    int ret = ResizeBilinearInterpolation(sw, sh, ss, simg,
                                          dst_w, dst_h, dst_step, dst_img,
                                          buf_size_, buf_);
    if (ret != 0) {
      //re-allocate buffer
      FreeAlignedMemory((void *&) buf_);
      buf_size_ = ret;
      MallocAlignedMemory((void *&) buf_, buf_size_ * sizeof(uint));
      if (ResizeBilinearInterpolation(sw, sh, ss, simg,
                                      dst_w, dst_h, dst_step, dst_img,
                                      buf_size_, buf_) != 0) {
        ERROR_INFO("Failed in ResizeBilinearInterpolation\n");
      }
    }
  }
}

//resize a grey image (hardware friendly version)
void GreyImageResizer::ResizeGreyImageHW(const int src_w,
                                         const int src_h,
                                         const int src_step,
                                         const uchar *src_img,
                                         const int hor_b,
                                         const int hor_d,
                                         const int hor_filter_sz,
                                         const uchar *hor_filter,
                                         const int ver_b,
                                         const int ver_d,
                                         const int ver_filter_sz,
                                         const uchar *ver_filter,
                                         const int dst_step,
                                         uchar *dst_img,
                                         int &dst_w,
                                         int &dst_h) {

  int sw = src_w, sh = src_h, ss = src_step;
  int hd = hor_d, hb = hor_b, vd = ver_d, vb = ver_b;
  const uchar *simg = src_img;

  while (hd >= (1 << (hb + 1)) && vd >= (1 << (vb + 1))) {
    //shrink image by a half
    int shrink_img_w = sw >> 1;
    int shrink_img_h = sh >> 1;
    int shrink_img_step = AlignedStepRoundUp(shrink_img_w);
    if (simg) {
      size_t shrink_buf_needed = size_t(shrink_img_step) * shrink_img_h;
      if (shrink_buf_needed > shrink_buf_size_) {
        FreeAlignedMemory((void *&) shrink_buf_);
        MallocAlignedMemory((void *&) shrink_buf_, shrink_buf_needed);
        shrink_buf_size_ = shrink_buf_needed;
      }

      for (int y = 0; y < shrink_img_h; y++) {
        const uchar *src = simg + (y << 1) * ss;
        uchar *dst = shrink_buf_ + y * shrink_img_step;
        uchar *dst_end = dst + shrink_img_w;
        while (dst < dst_end) {
          *dst++ = (src[0] + src[1] + src[ss] + src[ss + 1] + 2) >> 2;
          src += 2;
        }
      }
    }

    //modify source image and resize scales
    sw = shrink_img_w;
    sh = shrink_img_h;
    ss = shrink_img_step;
    if (simg) {
      simg = shrink_buf_;
    }
    if (hd % 2 == 0) {
      hd >>= 1;
    } else {
      hb++;
    }
    if (vd % 2 == 0) {
      vd >>= 1;
    } else {
      vb++;
    }
  }

  //apply filter if needed
  if (simg && (hor_filter || ver_filter)) {
    size_t buf_sz = sh * ss;
    if (buf_sz > filter_buf_size_) {
      for (int j = 0; j < 2; j++) {
        FreeAlignedMemory((void *&) filter_buf_[j]);
        MallocAlignedMemory((void *&) filter_buf_[j], buf_sz);
      }
      filter_buf_size_ = buf_sz;
    }
    FilterImage8Bits(sw, sh, ss, simg,
                     hor_filter_sz, hor_filter, ver_filter_sz, ver_filter,
                     filter_buf_[0], filter_buf_[1]);
    simg = filter_buf_[0];
  }

  //bilinear interpolation
  if (hd == (1 << hb) && vd == (1 << vb)) {
    //bilinear interpolation is NOT needed
    dst_w = sw;
    dst_h = sh;
    if (simg) {
      for (int y = 0; y < dst_h; y++) {
        const uchar *src = simg + y * ss;
        uchar *dst = dst_img + y * dst_step;
        for (int x = 0; x < dst_w; x++) {
          dst[x] = src[x];
        }
      }
    }
  } else {
    int ret = ResizeBilinearInterpolationHW(sw, sh, ss, simg,
                                            hb, hd, vb, vd, dst_step, dst_img,
                                            dst_w, dst_h, buf_size_, buf_);
    if (ret != 0 && simg) {
      //re-allocate buffer
      FreeAlignedMemory((void *&) buf_);
      buf_size_ = ret;
      MallocAlignedMemory((void *&) buf_, buf_size_ * sizeof(uint));
      if (ResizeBilinearInterpolationHW(sw, sh, ss, simg,
                                        hb, hd, vb, vd, dst_step, dst_img,
                                        dst_w, dst_h, buf_size_, buf_) != 0) {
        ERROR_INFO("Failed in ResizeBilinearInterpolationHW\n");
      }
    }
  }
}

////////////////////////////////////////////////////////////////////
inline int _hResizeBI(const uchar *src_row, const int src_w,
                      const int numer_bits, const int denom,
                      uint *dst_row) {
  if (src_w == 1) {
    dst_row[0] = src_row[0];
    return 1;
  }

  const int src_w_m1 = src_w - 1;
  const int numer = 1 << numer_bits;
  const int numer_half = numer / 2;

  int ix = 0;    // integer part of x coord
  int rx = 0;    // residual part of x coord
  int dst_w = 0;   // dst image width
  while (ix < src_w_m1) {
    if (rx < numer) {
      *dst_row++ = ((numer - rx) * src_row[ix] + rx * src_row[ix + 1]
          + numer_half) >> numer_bits;
      dst_w++;
      rx += denom;
    } else {
      rx -= numer;
      ix++;
    }
  }
  return dst_w;
}

int ResizeBilinearInterpolationGC(const int src_w, const int src_h,
                                  const int src_step, const uchar *src_img,
                                  const int hb, const int hd,
                                  const int vb, const int vd,
                                  int &dst_w, int &dst_h,
                                  const int dst_step, uchar *dst_img) {
  if (hb + vb > 24) {
    ERROR_INFO("hb + vb must not be greater than 24! %d %d", hb, vb);
  }

  //calculate dst image size
  const int hn = 1 << hb;
  const int vn = 1 << vb;
  ERROR_IF(hn > hd, "hn > hd, %d %d", hn, hd);
  ERROR_IF(vn > vd, "vn > vd, %d %d", vn, vd);
  dst_w = ((src_w - 1) * hn - 1) / hd + 1;
  dst_h = ((src_h - 1) * vn - 1) / vd + 1;
  if (NULL == src_img) {
    return -1;
  }

  //compute buffer size
  uint *buf, *row_buf0, *row_buf1;
  MallocAlignedMemory((void *&) buf, 2 * dst_w * sizeof(uint));
  row_buf0 = buf;
  row_buf1 = buf + dst_w;

  //for each row
  const int src_h_m1 = src_h - 1;
  int src_iy = 0;                //integer part of y
  int src_ry = 0;                //residual part of y
  int buf0_src_y = -100, buf1_src_y = -100;

  int y = 0;
  //dst pixels that needs interpolation
  while (src_iy < src_h_m1) {
    if (src_ry >= vn) {
      src_iy++;
      src_ry -= vn;
    } else {
      int dw;
      uint iw0 = vn - src_ry;
      uint iw1 = src_ry;
      //update both line buffers
      if (buf1_src_y == src_iy) {
        //reuse previous line buffer
        uint *tmp = row_buf0;
        row_buf0 = row_buf1;
        row_buf1 = tmp;
        //compute row_buf1
        dw = _hResizeBI(src_img + (src_iy + 1) * src_step,
                        src_w,
                        hb,
                        hd,
                        row_buf1);
        ERROR_IF(dw != dst_w, "dw != dst_w, %d, %d", dw, dst_w);
      } else if (buf0_src_y == src_iy && buf1_src_y == src_iy + 1) {
        //reuse both line buffers
      } else {
        //reuse nothing
        dw = _hResizeBI(src_img + src_iy * src_step, src_w, hb, hd, row_buf0);
        ERROR_IF(dw != dst_w, "dw != dst_w, %d, %d", dw, dst_w);
        dw = _hResizeBI(src_img + (src_iy + 1) * src_step,
                        src_w,
                        hb,
                        hd,
                        row_buf1);
        ERROR_IF(dw != dst_w, "dw != dst_w, %d, %d", dw, dst_w);
      }
      buf0_src_y = src_iy;
      buf1_src_y = src_iy + 1;

      //merge two lines
      _vResizeBI(dst_w,
                 row_buf0,
                 iw0,
                 row_buf1,
                 iw1,
                 vb,
                 dst_img + y * dst_step);

      //next row
      src_ry += vd;
      y++;
    }
  }

  ERROR_IF(y != dst_h, "y != dst_h, %d, %d", y, dst_h);

  FreeAlignedMemory((void *&) buf);
  return 0;
}

//resize a grey image (hardware friendly version)
void GreyImageResizer::ResizeGreyImageHorFilter5(const int src_w,
                                                 const int src_h,
                                                 const int src_step,
                                                 const uchar *src_img,
                                                 const int hor_b,
                                                 const int hor_d,
                                                 const int ver_b,
                                                 const int ver_d,
                                                 const float Nyquist_freq_ratio,
                                                 const int dst_step,
                                                 uchar *dst_img,
                                                 int &dst_w,
                                                 int &dst_h) {

  int sw = src_w, sh = src_h, ss = src_step;
  int hd = hor_d, hb = hor_b, vd = ver_d, vb = ver_b;
  const uchar *simg = src_img;

  while (hd >= (1 << (hb + 1)) && vd >= (1 << (vb + 1))) {
    //shrink image by a half
    int shrink_img_w = sw >> 1;
    int shrink_img_h = sh >> 1;
    int shrink_img_step = AlignedStepRoundUp(shrink_img_w);
    if (simg) {
      size_t shrink_buf_needed = size_t(shrink_img_step) * shrink_img_h;
      if (shrink_buf_needed > shrink_buf_size_) {
        FreeAlignedMemory((void *&) shrink_buf_);
        MallocAlignedMemory((void *&) shrink_buf_, shrink_buf_needed);
        shrink_buf_size_ = shrink_buf_needed;
      }

      for (int y = 0; y < shrink_img_h; y++) {
        const uchar *src = simg + (y << 1) * ss;
        uchar *dst = shrink_buf_ + y * shrink_img_step;
        uchar *dst_end = dst + shrink_img_w;
        while (dst < dst_end) {
          *dst++ = (src[0] + src[1] + src[ss] + src[ss + 1] + 2) >> 2;
          src += 2;
        }
      }
    }

    //modify source image and resize scales
    sw = shrink_img_w;
    sh = shrink_img_h;
    ss = shrink_img_step;
    if (simg) {
      simg = shrink_buf_;
    }
    if (hd % 2 == 0) {
      hd >>= 1;
    } else {
      hb++;
    }
    if (vd % 2 == 0) {
      vd >>= 1;
    } else {
      vb++;
    }
  }

  //apply filter when
  //1. source image is not NULL
  //2. it is down sampling (1 << hb) < hd
  //3. Nyquist freq ratio between (0, 1)
  if (simg && (1 << hb) < hd && Nyquist_freq_ratio > 0
      && Nyquist_freq_ratio < 1) {
    uchar hor_filter5[5];
    const float hor_scale = float(1 << hb) / hd;
    GetFilter5ForDownSample(hor_scale, Nyquist_freq_ratio, hor_filter5);
    size_t buf_sz = sh * ss;
    if (buf_sz > filter_buf_size_) {
      for (int j = 0; j < 2; j++) {
        FreeAlignedMemory((void *&) filter_buf_[j]);
        MallocAlignedMemory((void *&) filter_buf_[j], buf_sz);
      }
      filter_buf_size_ = buf_sz;
    }
    HorFilter5W256(sw, sh, ss, simg, hor_filter5, filter_buf_[0]);
    simg = filter_buf_[0];
  }

  //bilinear interpolation
  if (hd == (1 << hb) && vd == (1 << vb)) {
    //bilinear interpolation is NOT needed
    dst_w = sw;
    dst_h = sh;
    if (simg) {
      for (int y = 0; y < dst_h; y++) {
        const uchar *src = simg + y * ss;
        uchar *dst = dst_img + y * dst_step;
        for (int x = 0; x < dst_w; x++) {
          dst[x] = src[x];
        }
      }
    }
  } else {
    int ret = ResizeBilinearInterpolationHW(sw, sh, ss, simg,
                                            hb, hd, vb, vd, dst_step, dst_img,
                                            dst_w, dst_h, buf_size_, buf_);
    if (ret != 0 && simg) {
      //re-allocate buffer
      FreeAlignedMemory((void *&) buf_);
      buf_size_ = ret;
      MallocAlignedMemory((void *&) buf_, buf_size_ * sizeof(uint));
      if (ResizeBilinearInterpolationHW(sw, sh, ss, simg,
                                        hb, hd, vb, vd, dst_step, dst_img,
                                        dst_w, dst_h, buf_size_, buf_) != 0) {
        ERROR_INFO("Failed in ResizeBilinearInterpolationHW\n");
      }
    }
  }
}

} // namespace alpha
} // namespace vision
} // namespace hobot
