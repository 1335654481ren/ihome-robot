//
//  Classifiers for Alpha Detection
//  Copyright (c) 2016 by Horizon Robotics Inc.
//  Author: Chang Huang (chang.huang@hobot.cc)
//

#include "alpha_cascade.h"
#include "base.h"
#include <string.h>
#include <algorithm>

namespace hobot {
namespace vision {
namespace alpha {

void AlphaCascade::Init() {
  ref_fw_ = ref_fh_ = 0;
  conf_dec_prec_ = reg_dec_prec_ = 0;
  bbox_regressor_ = NULL;
}

void AlphaCascade::Release() {
  for (uint i = 0; i < classifiers_.size(); i++) {
    if (classifiers_[i])
      delete classifiers_[i];
  }
  classifiers_.clear();
  pre_conf_biases_.clear();
  pre_conf_upperbounds_.clear();
  init_reg_outputs_.clear();
  if (bbox_regressor_) {
    delete bbox_regressor_;
  }
  bbox_regressor_ = NULL;
  Init();
}

std::istream &AlphaCascade::FromStream(std::istream &is, bool tag_check) {
  Release();
  if (tag_check) {
    char tag[32];
    is.read(tag, 32);
    if (strcmp(tag, "Alpha+ v1.1") != 0) {
      ERROR_INFO("model tag incorrect, %s.", tag);
    }
  }
  ReadFromStream(is, ref_fw_);
  ReadFromStream(is, ref_fh_);
  ReadFromStreamVS(is, classifiers_);
  ReadFromStreamV(is, pre_conf_biases_);
  ReadFromStreamV(is, pre_conf_upperbounds_);
  ReadFromStreamV(is, conf_thresholds_);
  ReadFromStream(is, conf_dec_prec_);
  for (uint i = 0; i < classifiers_.size(); i++) {
    ERROR_IF(classifiers_[i]->GetOutputDim() != 1, "");
  }

  ReadFromStreamV(is, init_reg_outputs_);
  // debug output
#ifdef DEBUG_OUTPUT
  std::cout << "ref_fw_:" << ref_fw_ << std::endl;
  std::cout << "ref_fh_:" << ref_fh_ << std::endl;
  for (auto &classifier : classifiers_) {
    std::cout << "classifier:" << std::endl << *classifier;
  }
  for (auto val : pre_conf_biases_) {
    std::cout << "pre_conf_biases_:" << val << std::endl;
  }
  for (auto val : pre_conf_upperbounds_) {
    std::cout << "pre_conf_upperbounds_:" << val << std::endl;
  }
  for (auto val : conf_thresholds_) {
    std::cout << "conf_thresholds_:" << val << std::endl;
  }
  std::cout << "conf_dec_prec_:" << conf_dec_prec_ << std::endl;
  for (auto val : init_reg_outputs_) {
    std::cout << "init_reg_outputs_:" << val << std::endl;
  }
#endif
  // debug output over

  if (is.eof()) {
    init_reg_outputs_.clear();
    is.clear();
  } else {
    bbox_regressor_ = new AlphaClassifier(is);
    ReadFromStream(is, reg_dec_prec_);
    ERROR_IF(init_reg_outputs_.size() != 4, "");
    ERROR_IF(bbox_regressor_->GetOutputDim() != 4, "");
  }
  return is;
}

void AlphaCascade::UpdateFeatOffsets(const int xstep, const int ystep,
                                     const int cstep, const int sstep) {
  if (xstep == xstep_ && ystep == ystep_ && cstep == cstep_
      && sstep == sstep_) {
    return;
  }
  for (uint i = 0; i < classifiers_.size(); i++) {
    classifiers_[i]->UpdatePixelOffsets(xstep, ystep, cstep, sstep);
  }
  if (bbox_regressor_) {
    bbox_regressor_->UpdatePixelOffsets(xstep, ystep, cstep, sstep);
  }
  xstep_ = xstep;
  ystep_ = ystep;
  cstep_ = cstep;
  sstep_ = sstep;
}

bool AlphaCascade::Predict(const uchar *_ref_pointer, // reference pointer to mcms feature
                           int &passed_layer_num,      // how many layers passed
                           int &conf,                  // confidence
                           int *bbox) const {          // bounding box
  // cascade filter
  conf = 0;
  for (uint i = 0; i < classifiers_.size(); i++) {
    conf = std::min(conf + pre_conf_biases_[i], pre_conf_upperbounds_[i]);
    classifiers_[i]->Predict<1>(_ref_pointer, &conf);
    if (conf < conf_thresholds_[i]) {
      passed_layer_num = i;
      return false;
    }
  }
  passed_layer_num = classifiers_.size();

  // bounding box regression
  if (bbox_regressor_) {
    for (int i = 0; i < 4; i++) {
      bbox[i] = init_reg_outputs_[i];
    }
    bbox_regressor_->Predict<4>(_ref_pointer, bbox);
  }
  return true;
}

} // namespace alpha
} // namespace vision
} // namespace hobot

