//
//  Classes for Building a Grey Image Pyramid
//  Copyright (c) 2016 by Horizon Robotics Inc.
//  Author: Chang Huang (chang.huang@hobot.cc)
//

#include "grey_image_pyramid.h"
#include <math.h>

namespace hobot {
namespace vision {
namespace alpha {

static void PadGreyImageBorder(int w, int h, int step, uchar *data,
                               int border, uchar val) {
  if (border <= 0)
    return;
  for (int y = 0; y < border; y++) {
    uchar *p = data + y * step;
    for (int x = 0; x < w; x++) {
      p[x] = val;
    }
  }
  for (int y = border; y < h - border; y++) {
    uchar *p = data + y * step;
    for (int x = 0; x < border; x++) {
      p[x] = val;
    }
    for (int x = w - border; x < w; x++) {
      p[x] = val;
    }
  }
  for (int y = h - border; y < h; y++) {
    uchar *p = data + y * step;
    for (int x = 0; x < w; x++) {
      p[x] = val;
    }
  }
}

inline void CopyImage(int w, int h,
                      int src_step, const uchar *src_data,
                      int dst_step, uchar *dst_data) {
  for (int y = 0; y < h; y++) {
    const uchar *src = src_data + y * src_step;
    const uchar *src_end = src + w;
    uchar *dst = dst_data + y * dst_step;
    while (src < src_end) {
      *dst++ = *src++;
    }
  }
}

inline void HalfShrinkImage(int src_w, int src_h,
                            int src_step, const uchar *src_data,
                            int dst_w, int dst_h,
                            int dst_step, uchar *dst_data) {
  ERROR_IF(dst_w != src_w / 2 || dst_h != src_h / 2,
           "src %dx%d, dst %dx%d", src_w, src_h, dst_w, dst_h);
  for (int y = 0; y < dst_h; y++) {
    const uchar *src = src_data + (y << 1) * src_step;
    uchar *dst = dst_data + y * dst_step;
    uchar *dst_end = dst + dst_w;
    while (dst < dst_end) {
      *dst++ = (src[0] + src[1] + src[src_step] + src[src_step + 1] + 2) >> 2;
      src += 2;
    }
  }
}

////////////////////////////////////////////////////////////////////////////////

GreyImage::GreyImage() {
  width_ = height_ = step_ = 0;
  data_ = NULL;
  data_size_ = 0;
}

GreyImage::GreyImage(const int width, const int height, const int step) {
  width_ = height_ = step_ = 0;
  data_ = NULL;
  data_size_ = 0;
  if (!Reshape(width, height, step)) {
    ERROR_INFO("Failed in Resize, %d %d %d\n", width, height, step);
  }
}

GreyImage::~GreyImage() {
  if (data_) {
    FreeAlignedMemory((void *&) data_);
  }
}

bool GreyImage::Reshape(const int width, const int height, const int step) {
  width_ = width;
  height_ = height;
  if (step <= 0) {
    //step is not given, round up by aligned step
    step_ = AlignedStepRoundUp(width);
  } else {
    //step is given
    if (step < width) {
      ERROR_INFO("step < width, %d %d\n", step, width);
      return false;
    }
    step_ = step;
  }
  size_t mem_needed = step_ * height;
  if (mem_needed > data_size_) {
    FreeAlignedMemory((void *&) data_);
    if (MallocAlignedMemory((void *&) data_, mem_needed) != 0) {
      ERROR_INFO("Failed in mallocing memory of size %lu", mem_needed);
    }
    data_size_ = mem_needed;
  }
  return true;
}

/////////////////////////////////////////////////////

GreyImagePyramid::GreyImagePyramid(const int pad_border,                         //pad border
                                   const int max_level_num,                      //maximum number of scale levels
                                   const int min_level_w,                        //minimum level image width
                                   const int min_level_h) {
  ERROR_IF(pad_border < 0, "pad_border < 0, %d", pad_border);
  pad_border_ = pad_border;
  max_level_num_ = max_level_num;
  min_level_w_ = min_level_w;
  min_level_h_ = min_level_h;
  level_num_ = 0;
}

GreyImagePyramid::~GreyImagePyramid() {
  for (uint i = 0; i < image_l_.size(); i++) {
    delete image_l_[i];
  }
}

GreyImage *GreyImagePyramid::GetResizedLevelImage(const int lv_i,
                                                  const int dst_w,
                                                  const int dst_h) {
  ERROR_IF(lv_i >= max_level_num_, "lv_i >= max_level_num_, %d %d",
           lv_i, max_level_num_);

  //allocate grey image if necessary
  while (int(image_l_.size()) <= lv_i) {
    image_l_.push_back(new GreyImage);
  }
  GreyImage *dst_img = image_l_[lv_i];

  //reshape dst image if needed
  int dst_w_wb = dst_w + 2 * pad_border_;
  int dst_h_wb = dst_h + 2 * pad_border_;

  bool need_pad_val = false;
  if (dst_img->GetWidth() != dst_w_wb || dst_img->GetHeight() != dst_h_wb) {
    if (!dst_img->Reshape(dst_w_wb, dst_h_wb, AlignedStepRoundUp(dst_w_wb))) {
      ERROR_INFO(
          "Failed in reshaping dst_img %dx%d at lv %u, with pad border %d",
          dst_w_wb,
          dst_h_wb,
          lv_i,
          pad_border_);
    }
    need_pad_val = true;    //set padding area if image resized
  }

  //pad border if needed
  int dst_step = dst_img->GetWidthStep();
  if (need_pad_val) {
    PadGreyImageBorder(dst_w_wb,
                       dst_h_wb,
                       dst_step,
                       dst_img->GetData(),
                       pad_border_,
                       0);
  }

  return dst_img;
}

//////////////////////////////////////////////////////
GreyImagePyramidFP::GreyImagePyramidFP(const int pad_border,                        //pad border
                                       const int max_level_num,                     //maximum number of scale levels
                                       const int min_level_w,                       //minimum level image width
                                       const int min_level_h,                       //minimum level image height
                                       const int scale_numer_bit,                   //scale nemerator (in bit)
                                       const int start_scale_denom,                 //denominator of starting scale
                                       const int scale_step_denom,                  //denominator of scale step
                                       const float Nyquist_freq_ratio)              //Nyquist freq ratio you want to preserve
    : GreyImagePyramid(pad_border, max_level_num, min_level_w, min_level_h) {

  ERROR_IF(scale_numer_bit <= 0, "scale_num_bit <= 0, %d", scale_numer_bit);
  ERROR_IF(start_scale_denom <= 0,
           "start_scale_denom <= 0, %d",
           start_scale_denom);
  ERROR_IF(scale_step_denom <= 0,
           "scale_step_denom <= 0, %d",
           scale_step_denom);

  this->scale_numer_bit_ = scale_numer_bit;
  this->start_scale_denom_ = start_scale_denom;
  this->scale_step_denom_ = scale_step_denom;
  this->Nyquist_freq_ratio_ = Nyquist_freq_ratio;
}

GreyImagePyramidFP::~GreyImagePyramidFP() {

}

void GreyImagePyramidFP::Init(const int img_w,
                              const int img_h,                     //source image size
                              const int grey_img_step,
                              const uchar *img_data) {     //step and image data
  level_num_ = 0;
  for (int l = 0; l < max_level_num_; l++, level_num_++) {
    int src_w, src_h, src_step;
    const uchar *src_data;
    int scale_denom;
    if (l == 0) {
      src_w = img_w;
      src_h = img_h;
      src_step = grey_img_step;
      src_data = img_data;
      scale_denom = start_scale_denom_;
    } else {
      src_w = image_l_[l - 1]->GetWidth() - 2 * pad_border_;
      src_h = image_l_[l - 1]->GetHeight() - 2 * pad_border_;
      src_step = image_l_[l - 1]->GetWidthStep();
      src_data = image_l_[l - 1]->GetConstData()
          + pad_border_ * src_step + pad_border_;
      scale_denom = scale_step_denom_;
    }
    //calculate dst width and height
    int dst_w, dst_h;
    image_resizer_.ResizeGreyImageHorFilter5(src_w, src_h,
                                             src_step, NULL,
                                             scale_numer_bit_, scale_denom,
                                             scale_numer_bit_, scale_denom,
                                             Nyquist_freq_ratio_,
                                             0, NULL, dst_w, dst_h);

    if (min_level_w_ > 0 && min_level_w_ > dst_w
        || min_level_h_ > 0 && min_level_h_ > dst_h) {
      //violate minimum level image size constraint
      break;
    }

    GreyImage &dst_img = *GetResizedLevelImage(l, dst_w, dst_h);
    image_scale_l_.push_back(0);
    int dst_step = dst_img.GetWidthStep();
    uchar *dst_data = dst_img.GetData() + pad_border_ * dst_step + pad_border_;

    if (dst_w == src_w && dst_h == src_h) {
      //simply copy image
      CopyImage(src_w, src_h, src_step, src_data, dst_step, dst_data);
    } else {
      //bilinear interpolcation
      image_resizer_.ResizeGreyImageHorFilter5(src_w,
                                               src_h,
                                               src_step,
                                               src_data,
                                               scale_numer_bit_,
                                               scale_denom,
                                               scale_numer_bit_,
                                               scale_denom,
                                               Nyquist_freq_ratio_,
                                               dst_step,
                                               dst_data,
                                               dst_w,
                                               dst_h);
    }

    if (l == 0) {
      image_scale_l_[0] = float(1 << scale_numer_bit_) / scale_denom;
    } else {
      image_scale_l_[l] =
          image_scale_l_[l - 1] * (1 << scale_numer_bit_) / scale_denom;
    }
  }
}

void GreyImagePyramidFP::Init(const int img_w,
  const int img_h,                     //source image size
  const int grey_img_step,
  const uchar *img_data,
  std::vector<TSRect<int> > & image_roi_l,
  std::vector<float> & image_scale_l) {     //step and image data
  level_num_ = 0;
  std::vector<TSRect<int> > image_roi_l_;
  image_scale_l_.clear();
  for (int l = 0; l < image_scale_l.size(); l++) {
    const float scale_step = image_scale_l[l];
    const TSRect<int> &roi = image_roi_l[l];
    int src_w = roi.r - roi.l;
    int src_h = roi.b - roi.t;
    int src_step = grey_img_step;
    const uchar *src_data = img_data + roi.t * grey_img_step + roi.l;
    //reshape dst image if needed
    int dst_w = int(src_w * scale_step + 0.5f);
    int dst_h = int(src_h * scale_step + 0.5f);
    if (min_level_w_ > 0 && min_level_w_ > dst_w
      || min_level_h_ > 0 && min_level_h_ > dst_h) {
      //violate minimum level image size constraint
      continue;
    }
    
    GreyImage &dst_img = *GetResizedLevelImage(level_num_, dst_w, dst_h);
    image_scale_l_.push_back(scale_step);
    image_roi_l_.push_back(roi);
    level_num_++;
    int dst_step = dst_img.GetWidthStep();
    uchar *dst_data = dst_img.GetData() + pad_border_ * dst_step + pad_border_;

    if (dst_w == src_w && dst_h == src_h) {
      //copy image
      CopyImage(src_w, src_h, src_step, src_data, dst_step, dst_data);
    } else {
      //bilinear interpolcation
      image_resizer_.ResizeGreyImage(src_w, src_h, src_step, src_data,
        dst_w, dst_h, dst_step, dst_data);
    }
  }
  image_scale_l = image_scale_l_;
  image_roi_l = image_roi_l_;
}

////////////////////////////////////////////////////////////////////////////////////////////////

GreyImagePyramidOctave::GreyImagePyramidOctave(const int pad_border,           //pad border
                                               const int max_level_num,        //maximum number of scale levels
                                               const int min_level_w,          //minimum level image width
                                               const int min_level_h,          //minimum level image height
                                               const int scale_numer_bit,      //scale nemerator (in bit)
                                               const int scale_step_denom,     //denominator of scale step
                                               const int octave_num,           //the number of octaves
                                               const int sub_level_num)        //the number of sub scale levels in an octave
    : GreyImagePyramid(pad_border, max_level_num, min_level_w, min_level_h) {

  ERROR_IF(scale_numer_bit <= 0, "scale_num_bit <= 0, %d", scale_numer_bit);
  ERROR_IF(scale_step_denom <= 0,
           "scale_step_denom <= 0, %d",
           scale_step_denom);
  ERROR_IF(octave_num <= 0, "octave_num <= 0, %d", octave_num);
  ERROR_IF(sub_level_num <= 0, "sub_level_num <= 0, %d", sub_level_num);

  this->scale_numer_bit_ = scale_numer_bit;
  this->scale_step_denom_ = scale_step_denom;
  this->octave_num_ = octave_num;
  this->sub_level_num_ = sub_level_num;
}

GreyImagePyramidOctave::~GreyImagePyramidOctave() {

}

void GreyImagePyramidOctave::Init(const int img_w,
                                  const int img_h,           //source image size
                                  const int grey_img_step,
                                  const uchar *img_data) {   //step and image data

  level_num_ = 0;
  for (int l = 0; l < max_level_num_; l++, level_num_++) {
    int src_w, src_h, src_step;
    const uchar *src_data;
    int dst_w, dst_h;
    if (0 == l) {
      // the first level of the first octave
      src_w = img_w;
      src_h = img_h;
      src_step = grey_img_step;
      src_data = img_data;
      dst_w = src_w;
      dst_h = src_h;
      if (min_level_w_ > 0 && min_level_w_ > dst_w
          || min_level_h_ > 0 && min_level_h_ > dst_h) {
        //violate minimum level image size constraint
        break;
      }
      GreyImage &dst_img = *GetResizedLevelImage(l, dst_w, dst_h);
      int dst_step = dst_img.GetWidthStep();
      uchar
          *dst_data = dst_img.GetData() + pad_border_ * dst_step + pad_border_;
      CopyImage(src_w, src_h, src_step, src_data, dst_step, dst_data);
      image_scale_l_[0] = 1.0f;
    } else if (0 == l % sub_level_num_) {
      // the first level of coming octaves
      src_w = image_l_[l - sub_level_num_]->GetWidth() - 2 * pad_border_;
      src_h = image_l_[l - sub_level_num_]->GetHeight() - 2 * pad_border_;
      src_step = image_l_[l - sub_level_num_]->GetWidthStep();
      src_data = image_l_[l - sub_level_num_]->GetConstData()
          + pad_border_ * src_step + pad_border_;
      dst_w = src_w >> 1;
      dst_h = src_h >> 1;
      if (min_level_w_ > 0 && min_level_w_ > dst_w
          || min_level_h_ > 0 && min_level_h_ > dst_h) {
        //violate minimum level image size constraint
        break;
      }
      GreyImage &dst_img = *GetResizedLevelImage(l, dst_w, dst_h);
      int dst_step = dst_img.GetWidthStep();
      uchar
          *dst_data = dst_img.GetData() + pad_border_ * dst_step + pad_border_;
      HalfShrinkImage(src_w,
                      src_h,
                      src_step,
                      src_data,
                      dst_w,
                      dst_h,
                      dst_step,
                      dst_data);
      image_scale_l_[l] = 0.5f * image_scale_l_[l - sub_level_num_];
    } else {
      // intermediate level
      src_w = image_l_[l - 1]->GetWidth() - 2 * pad_border_;
      src_h = image_l_[l - 1]->GetHeight() - 2 * pad_border_;
      src_step = image_l_[l - 1]->GetWidthStep();
      src_data = image_l_[l - 1]->GetConstData()
          + pad_border_ * src_step + pad_border_;
      //calculate dst width and height
      int dst_w, dst_h;
      image_resizer_.ResizeGreyImageHorFilter5(src_w,
                                               src_h,
                                               src_step,
                                               NULL,
                                               scale_numer_bit_,
                                               scale_step_denom_,
                                               scale_numer_bit_,
                                               scale_step_denom_,
                                               0,
                                               0,
                                               NULL,
                                               dst_w,
                                               dst_h);

      if (min_level_w_ > 0 && min_level_w_ > dst_w
          || min_level_h_ > 0 && min_level_h_ > dst_h) {
        //violate minimum level image size constraint
        break;
      }
      GreyImage &dst_img = *GetResizedLevelImage(l, dst_w, dst_h);
      int dst_step = dst_img.GetWidthStep();
      uchar
          *dst_data = dst_img.GetData() + pad_border_ * dst_step + pad_border_;

      //bilinear interpolcation
      image_resizer_.ResizeGreyImageHorFilter5(src_w,
                                               src_h,
                                               src_step,
                                               src_data,
                                               scale_numer_bit_,
                                               scale_step_denom_,
                                               scale_numer_bit_,
                                               scale_step_denom_,
                                               0,
                                               dst_step,
                                               dst_data,
                                               dst_w,
                                               dst_h);

      image_scale_l_[l] =
          image_scale_l_[l - 1] * (1 << scale_numer_bit_) / scale_step_denom_;
    }
  }
}

//////////////////////////////////////////////////////
GreyImagePyramidGC::GreyImagePyramidGC(const int pad_border,                        //pad border
                                       const int max_level_num,                     //maximum number of scale levels
                                       const int min_level_w,                       //minimum level image width
                                       const int min_level_h,                       //minimum level image height
                                       const int scale_numer_bit,                   //scale nemerator (in bit)
                                       const int scale_step_denom)                  //denominator of scale step
    : GreyImagePyramid(pad_border, max_level_num, min_level_w, min_level_h) {

  ERROR_IF(scale_numer_bit <= 0, "scale_num_bit <= 0, %d", scale_numer_bit);
  ERROR_IF(scale_step_denom <= 0,
           "scale_step_denom <= 0, %d",
           scale_step_denom);

  this->scale_numer_bit_ = scale_numer_bit;
  this->scale_step_denom_ = scale_step_denom;
}

GreyImagePyramidGC::~GreyImagePyramidGC() {

}

void GreyImagePyramidGC::Init(const int img_w,
                              const int img_h,             //source image size
                              const int grey_img_step,
                              const uchar *img_data) {     //step and image data

  level_num_ = 0;
  for (int l = 0; l < max_level_num_; l++, level_num_++) {
    int src_w, src_h, src_step;
    const uchar *src_data;
    int dst_w, dst_h;
    if (l == 0) {
      // first level
      src_w = img_w;
      src_h = img_h;
      src_step = grey_img_step;
      src_data = img_data;
      dst_w = src_w;
      dst_h = src_h;
      if (min_level_w_ > 0 && min_level_w_ > dst_w
          || min_level_h_ > 0 && min_level_h_ > dst_h) {
        //violate minimum level image size constraint
        break;
      }
      GreyImage &dst_img = *GetResizedLevelImage(l, dst_w, dst_h);
      int dst_step = dst_img.GetWidthStep();
      uchar
          *dst_data = dst_img.GetData() + pad_border_ * dst_step + pad_border_;
      CopyImage(src_w, src_h, src_step, src_data, dst_step, dst_data);
      image_scale_l_[0] = 1.0f;
    } else {
      src_w = image_l_[l - 1]->GetWidth() - 2 * pad_border_;
      src_h = image_l_[l - 1]->GetHeight() - 2 * pad_border_;
      src_step = image_l_[l - 1]->GetWidthStep();
      src_data = image_l_[l - 1]->GetConstData()
          + pad_border_ * src_step + pad_border_;
      //calculate dst width and height
      ResizeBilinearInterpolationGC(src_w, src_h, src_step, NULL,
                                    scale_numer_bit_, scale_step_denom_,
                                    scale_numer_bit_, scale_step_denom_,
                                    dst_w, dst_h, 0, NULL);

      if (min_level_w_ > 0 && min_level_w_ > dst_w
          || min_level_h_ > 0 && min_level_h_ > dst_h) {
        //violate minimum level image size constraint
        break;
      }

      GreyImage &dst_img = *GetResizedLevelImage(l, dst_w, dst_h);
      int dst_step = dst_img.GetWidthStep();
      uchar
          *dst_data = dst_img.GetData() + pad_border_ * dst_step + pad_border_;

      //bilinear interpolcation
      ResizeBilinearInterpolationGC(src_w, src_h, src_step, src_data,
                                    scale_numer_bit_, scale_step_denom_,
                                    scale_numer_bit_, scale_step_denom_,
                                    dst_w, dst_h, dst_step, dst_data);

      image_scale_l_[l] =
          image_scale_l_[l - 1] * (1 << scale_numer_bit_) / scale_step_denom_;
    }
  }
}

} // namespace alpha
} // namespace vision
} // namespace hobot
