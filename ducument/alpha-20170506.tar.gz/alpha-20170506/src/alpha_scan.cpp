//
//  Scanning for Alpha Detection
//  Copyright (c) 2016 by Horizon Robotics Inc.
//  Author: Chang Huang (chang.huang@hobot.cc)
//

#include "alpha_scan.h"
#include "alpha_cascade.h"
#include "mcms.h"

namespace hobot {
namespace vision {
namespace alpha {

inline bool DetectOneWnd(AlphaCascade &cas,
                         const uchar *wnd_feat_ptr,
                         const int wnd_left,
                         const int wnd_top,
                         const int coord_scale_numer,
                         const int coord_scale_bits,
                         int &passed_layer_num,
                         SDetRespFP &resp,
                         int bias_x = 0, int bias_y = 0
) {
  int conf;
  int bbox[4];
  bool passed = cas.Predict(wnd_feat_ptr, passed_layer_num, conf, bbox);
  if (passed) {
    // set resp conf as 1
    resp.conf = 1 << kScoreDecPrec;
    if (cas.HasBBoxReg()) {
      // normalize dec prec
      bbox[0] = RightShiftRoundUp(bbox[0] << kCoordDecPrec, cas.reg_dec_prec_)
          + (wnd_left << kCoordDecPrec);
      bbox[1] = RightShiftRoundUp(bbox[1] << kCoordDecPrec, cas.reg_dec_prec_)
          + (wnd_top << kCoordDecPrec);
      bbox[2] = RightShiftRoundUp(bbox[2] << kCoordDecPrec, cas.reg_dec_prec_)
          + (wnd_left << kCoordDecPrec);
      bbox[3] = RightShiftRoundUp(bbox[3] << kCoordDecPrec, cas.reg_dec_prec_)
          + (wnd_top << kCoordDecPrec);
    } else {
      bbox[0] = wnd_left << kCoordDecPrec;
      bbox[1] = wnd_top << kCoordDecPrec;
      bbox[2] = (2 * cas.ref_fw_ + wnd_left) << kCoordDecPrec;
      bbox[3] = (2 * cas.ref_fh_ + wnd_top) << kCoordDecPrec;
    }
    // calculate bounding box
    resp.rect.l =
        RightShiftRoundUp(bbox[0] * coord_scale_numer, coord_scale_bits) + bias_x;
    resp.rect.t =
        RightShiftRoundUp(bbox[1] * coord_scale_numer, coord_scale_bits) + bias_y;
    resp.rect.r =
        RightShiftRoundUp(bbox[2] * coord_scale_numer, coord_scale_bits) + bias_x;
    resp.rect.b =
        RightShiftRoundUp(bbox[3] * coord_scale_numer, coord_scale_bits) + bias_y;
  }

  return passed;
}

int AlphaScanFP(AlphaCascade &cascade,
                const unsigned char *feat_ptr,
                const int ystep, const int xstep,
                const int bgn_x, const int bgn_y,
                const int end_x, const int end_y,
                const ScanMode scan_mode,
                const int coarse2fine_layer_num,
                const int coord_scale_numer, const int coord_scale_bits,
                std::list<SDetRespFP> &raw_resp_list,
                int bias_x, int bias_y
#ifdef CAL_DET_STAT
    , DetStat &det_stat
#endif
) {

  AlphaCascade &cas = cascade;
  std::list<SDetRespFP> &rrl = raw_resp_list;
  int passed_layer_num;
  SDetRespFP resp;
  int resp_num = 0;

  if (scan_mode == kUniformScan) {
    //uniform scanning
    for (int y = bgn_y; y < end_y; y++) {
      for (int x = bgn_x; x < end_x; x++) {
        if (DetectOneWnd(cas, feat_ptr + y * ystep + x * xstep,
                        x * 2, y * 2,
                        coord_scale_numer, coord_scale_bits,
                        passed_layer_num, resp, bias_x, bias_y
        )) {
          rrl.push_back(resp);
          resp_num++;
#ifdef CAL_DET_STAT
          det_stat.scanned_wnd_num ++;
          det_stat.wnd_num_each_layer[passed_layer_num] ++;
#endif
        }
      }
    }

  } else if (scan_mode == kCoarse2FineScan) {
    //3 x 3 coarse to fine scanning
    for (int y = bgn_y + 1; y < end_y; y += 3) {
      for (int x = bgn_x + 1; x < end_x; x += 3) {
        //coarse step
        if (DetectOneWnd(cas, feat_ptr + y * ystep + x * xstep,
                         x * 2, y * 2,
                         coord_scale_numer, coord_scale_bits,
                         passed_layer_num, resp
        )) {
          rrl.push_back(resp);
          resp_num++;
        }
#ifdef CAL_DET_STAT
        det_stat.scanned_wnd_num ++;
        det_stat.wnd_num_each_layer[passed_layer_num] ++;
#endif
        if (passed_layer_num >= coarse2fine_layer_num) {
          //fine step
          for (int yy = y - 1; yy <= y + 1; yy++) {
            if (yy >= end_y)
              continue;
            for (int xx = x - 1; xx <= x + 1; xx++) {
              if (xx >= end_x)
                continue;
              if (xx == x && yy == y)
                continue;
              if (DetectOneWnd(cas, feat_ptr + yy * ystep + xx * xstep,
                               xx * 2, yy * 2,
                               coord_scale_numer, coord_scale_bits,
                               passed_layer_num, resp
              )) {
                rrl.push_back(resp);
                resp_num++;
              }
#ifdef CAL_DET_STAT
              det_stat.scanned_wnd_num ++;
              det_stat.wnd_num_each_layer[passed_layer_num] ++;
#endif
            }
          }
        }
      }
    }

  } else if (scan_mode == kCellSearch) {
    //3 x 3 cell search
    const int ox[9] = {1, 0, 2, 2, 0, 1, 1, 0, 2};
    const int oy[9] = {1, 0, 2, 0, 2, 0, 2, 1, 1};
    const int conf1 = 1 << kScoreDecPrec;
    const int cell_confs[9] =
        {conf1 * 9 / 1 * 2 - conf1, conf1 * 9 / 2 * 2 - conf1,
         conf1 * 9 / 3 * 2 - conf1,
         conf1 * 9 / 4 * 2 - conf1, conf1 * 9 / 5 * 2 - conf1,
         conf1 * 9 / 6 * 2 - conf1,
         conf1 * 9 / 7 * 2 - conf1, conf1 * 9 / 8 * 2 - conf1,
         conf1 * 9 / 9 * 2 - conf1};
    for (int y = bgn_y; y < end_y; y += 3) {
      for (int x = bgn_x; x < end_x; x += 3) {
        int cell_passed_wnd_num = 0;
        int cell_passed_layer_num = 0;
        for (int cell_i = 0; cell_i < 9; cell_i++) {
          int cx = x + ox[cell_i];
          int cy = y + oy[cell_i];
          if (cx >= end_x || cy >= end_y) {
            continue;
          }
          if (DetectOneWnd(cas, feat_ptr + cy * ystep + cx * xstep,
                           cx * 2, cy * 2,
                           coord_scale_numer, coord_scale_bits,
                           passed_layer_num, resp
          )) {
            // wnd passed
            if (cell_passed_wnd_num == 0) {
              resp.conf = conf1;
            } else {
              resp.conf = cell_confs[cell_i];
            }
            cell_passed_wnd_num++;
            rrl.push_back(resp);
            resp_num++;
          }
#ifdef CAL_DET_STAT
          det_stat.scanned_wnd_num ++;
          det_stat.wnd_num_each_layer[passed_layer_num] ++;
#endif
          if (cell_passed_wnd_num >= 2) {
            // early accept
            break;
          }
          cell_passed_layer_num += passed_layer_num;
          if (cell_passed_layer_num < (cell_i + 1) * coarse2fine_layer_num) {
            // early reject
            break;
          }
        }
      }
    }
  } else {
    ERROR_INFO("Unknown scan mode %d", scan_mode);
  }

  return resp_num;
}

} // namespace alpha
} // namespace vision
} // namespace hobot

