//
// Created by Bear on 16/9/20.
// Copyright (c) 2016 Horizon Robotics. All rights reserved.
//

#ifndef ALPHA_DET_PREDICTION_MCMS_NEON_H
#define ALPHA_DET_PREDICTION_MCMS_NEON_H

#include "mcms.h"

namespace hobot {
namespace vision {
namespace alpha {

class ImageMcmsNeon : public ImageMcms {
 public:
  ImageMcmsNeon(int img_w, int img_h, int chan_num, int scale_num)
      : ImageMcms( img_w, img_h, chan_num, scale_num)
  {}

  virtual void Compute(const uchar *grey_img,
                       const int w,
                       const int h,
                       const int step,
                       const int chan_num,
                       const ChannelType *chan_types,
                       const int scale_num);
};

} // namespace alpha
} // namespace vision
} // namespace hobot

#endif //ALPHA_DET_PREDICTION_MCMS_NEON_H
