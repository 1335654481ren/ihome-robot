//
//  Cascade for Alpha Detection
//  Copyright (c) 2016 by Horizon Robotics Inc.
//  Author: Chang Huang (chang.huang@hobot.cc)
//

#ifndef __ALPHA_CASCADE_H__
#define __ALPHA_CASCADE_H__

#include "alpha_classifier.h"
#include "channel_feature.h"

namespace hobot {
namespace vision {
namespace alpha {

struct AlphaCascade {
  // reference window size in feature space
  int ref_fw_, ref_fh_;

  // cascade filters
  std::vector<AlphaClassifier *> classifiers_;

  std::vector<int> pre_conf_biases_;

  std::vector<int> pre_conf_upperbounds_;

  std::vector<int> conf_thresholds_;

  // confidence decimal fix-point precision
  int conf_dec_prec_;

  // bounding box regression
  std::vector<int> init_reg_outputs_;

  AlphaClassifier *bbox_regressor_;

  // regression decimal fix-point precision
  int reg_dec_prec_;

  // running time buffer
  int xstep_, ystep_, cstep_, sstep_;

  AlphaCascade() { Init(); }
  AlphaCascade(std::istream &is) {
    Init();
    FromStream(is);
  }
  virtual ~AlphaCascade() { Release(); }

  void Init();
  void Release();

  std::istream &FromStream(std::istream &is, bool tag_check = true);

  bool Predict(const uchar *_ref_pointer, // reference pointer to mcms feature
               int &passed_layer_num,      // how many layers passed
               int &conf,                  // confidence
               int *bbox) const;           // bounding box

  void UpdateFeatOffsets(const int xstep, const int ystep,
                         const int cstep, const int sstep);

  inline int GetLayerNum() const { return int(classifiers_.size()); }
  inline bool HasBBoxReg() const { return bbox_regressor_ != NULL; }
};

} // namespace alpha
} // namespace vision
} // namespace hobot

#endif

