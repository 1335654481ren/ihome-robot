//
//  Classifiers for Alpha Detection
//  Copyright (c) 2016 by Horizon Robotics Inc.
//  Author: Chang Huang (chang.huang@hobot.cc)
//

#ifndef __ALPHA_CLASSIFIER_H__
#define __ALPHA_CLASSIFIER_H__

#include "base.h"
#include <istream>

namespace hobot {
namespace vision {
namespace alpha {

struct AlphaClassifier {
  // here we assume all naive decision trees are of
  // the same shape, and the same for look up tables.

  int dt_num_;        //decision tree number
  int dt_depth_;      //decision tree depth
  int lut_dim_;       //look up table dim

  //
  // naive decision trees
  //

  //basic features of decision tree.
  //quaruples (x, y, c, s) for each pixel.
  //each branching node is a pair of them,
  //with a bias defined below.
  //length: 4 * 2 * dt_depth_ * dt_num_
  uchar *mcms_pixels_;

  //bias terms for each of the branching node.
  //length: dt_depth_ * dt_num_
  uchar *biases_;

  //pixel offsets in mcms feature image
  //length: 2 * dt_depth_ * dt_num_
  int *mcms_pixel_offsets_;

  //
  // look up tables
  //

  //fix point elements of look up tables.
  //length: (1 << dt_depth_) * lut_dim_ * dt_num_
  signed char *luts_;
  int16_t *lut16s_;

  //fix point left shift bit for each lut
  //length: dt_num_
  uchar *fp_bits_;

  AlphaClassifier();
  AlphaClassifier(std::istream &is);
  virtual ~AlphaClassifier();

  void Init();
  void Release();

  int GetOutputDim() const;

  //update offsets of mcms pixels given mcms feature
  //image steps, in x, y, c and s axes.
  void UpdatePixelOffsets(const int xstep, const int ystep,
                          const int cstep, const int sstep);

  //calculate prediction results given pointer to left top
  //window, and add to outputs
  template <int lut_dim>
  void Predict(const uchar *ref_pointer, int *outputs) const;

  std::istream &FromStream(std::istream &is);
};

std::ostream &operator<<(std::ostream &out, AlphaClassifier &in);

} // namespace alpha
} // namespace vision
} // namespace hobot

#endif
