//
//  Simple Tensor Template
//  Copyright (c) 2016 by Horizon Robotics Inc.
//  Author: Chang Huang (chang.huang@hobot.cc)
//

#ifndef _ARRAY_H_
#define _ARRAY_H_

#include <vector>
#include <string>
#include "base.h"

#ifndef __APPLE__
#include <malloc.h>
#endif

namespace hobot {
namespace vision {
namespace alpha {

template<typename T>
struct TArrayMD {
  // tensor dimension
  int dim_;

  // shape, stride and steps (stride = step * sizeof(T))
  std::vector<int> shape_, strides_, steps_;

  // data size
  size_t data_size_;

  // pointer to data
  void *data_;

  TArrayMD() {
    Init();
  }

  TArrayMD(int dim, int *shape, int *strides = NULL) {
    Init();
    if (!Resize(dim, shape, strides, true)) {
      REPORT_ERROR_POSITION;
    }
  }

  ~TArrayMD() {
    ReleaseData();
  }

  void Init() {
    dim_ = 0;
    data_size_ = 0;
    data_ = NULL;
  }

  void ReleaseData() {
    if (data_)
      FreeAlignedMemory(data_);
    data_ = NULL;
  }

  bool Resize(int dim, int *shape, int *strides = NULL,
              bool realloc_memory = true, bool padding_at_end = true) {
    if (dim <= 0) ERROR_INFO("Invalid dim %d", dim);

    dim_ = dim;
    shape_.assign(shape, shape + dim_);

    if (strides) {
      //strides given
      strides_.assign(strides, strides + dim_);
      //check strides_ is valid or not
      bool valid = strides_[dim_ - 1] >= sizeof(T);
      for (int d = dim_ - 2; d >= 0; d--)
        valid &= strides_[d] >= strides_[d + 1] * shape_[d + 1];
      if (!valid) ERROR_INFO("Invalid stride");
    } else {
      //strides are computed according to shape
      strides_.resize(dim_);
      strides_[dim_ - 1] = sizeof(T);
      for (int d = dim_ - 2; d >= 0; d--)
        strides_[d] = strides_[d + 1] * shape_[d + 1];
    }

    steps_.resize(dim_);
    for (int d = 0; d < dim_; d++)
      steps_[d] = strides_[d] / sizeof(T);

    //for data_size
    size_t memory_needed = shape[0] * strides_[0];
    if (padding_at_end)
      memory_needed += kMemAlignStep;

    if (realloc_memory) {
      //reallocate memory
      if (data_)
        ReleaseData();
      MallocAlignedMemory(data_, memory_needed);
      if (data_ == NULL) ERROR_INFO("failed in allocating memory of size %lu\n",
                                    memory_needed);
      data_size_ = memory_needed;

    } else {

      if (memory_needed > data_size_)
        return false;
    }

    return true;
  }

  inline T *ptr() const {
    return (T *) data_;
  }

  inline const T *c_ptr() const {
    return (const T *) data_;
  }

};

} // namespace alpha
} // namespace vision
} // namespace hobot

#endif
