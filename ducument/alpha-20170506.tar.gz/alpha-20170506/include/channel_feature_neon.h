//
// Created by Bear on 2016/11/1.
// Copyright (c) 2016 - 2022. Horizon Robotics. All rights reserved.
//
// The material in this file is confidential and contains trade secrets
// of Horizon Robotics Inc. This is proprietary information owned by
// Horizon Robotics Inc. No part of this work may be disclosed,
// reproduced, copied, transmitted, or used in any way for any purpose,
// without the express written permission of Horizon Robotics Inc.
//

#ifndef ALPHA_DET_PREDICTION_CHANNEL_FEATURE_NEON_H
#define ALPHA_DET_PREDICTION_CHANNEL_FEATURE_NEON_H

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * @brief compute line channel feature use neon
 * @param src0
 * @param src1
 * @param src2
 * @param width
 * @param dst
 */
void line_channel_feature_yxc_neon(const unsigned char *src0,
                                   const unsigned char *src1,
                                   const unsigned char *src2,
                                   const int width,
                                   unsigned char *dst);

void line_triangular_filter_12_neon(const unsigned char *src0,  // radius = 1, stride = 2
                                    const unsigned char *src1,
                                    const unsigned char *src2,
                                    const int width,
                                    unsigned char *dst);

void line_triangular_filter_11_neon(const unsigned char *src0,  // radius = 1, stride = 1
                                    const unsigned char *src1,
                                    const unsigned char *src2,
                                    const int width,
                                    unsigned char *dst);

void line_triangular_filter_21_neon(const unsigned char *src0,  // radius = 2, stride = 1
                                    const unsigned char *src1,
                                    const unsigned char *src2,
                                    const int width,
                                    unsigned char *dst);
#ifdef __cplusplus
}
#endif

#endif //ALPHA_DET_PREDICTION_CHANNEL_FEATURE_NEON_H
