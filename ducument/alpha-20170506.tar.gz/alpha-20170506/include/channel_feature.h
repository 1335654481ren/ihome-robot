//
//  Functions for Channel Features
//  Copyright (c) 2016 by Horizon Robotics Inc.
//  Author: Chang Huang (chang.huang@hobot.cc)
//

#ifndef __CHANNEL_FEATURE_H__
#define __CHANNEL_FEATURE_H__

namespace hobot
{
namespace vision
{
namespace alpha
{

//
//  Channel Types
//
typedef enum {
  CF_Original,            //original image
  CF_AbsGradX,            //abs grad in x axis
  CF_AbsGradY,            //abs grad in y axis
  CF_AbsGradLTRB,         //abs grad from left top to right bottom
  CF_AbsGradRTLB,         //abs grad from right top to left bottom
  CF_AbsGradDXY,          //abs grad from left right to top bottom: abs(((x4+x6+1)>>1) - ((x2+x8+1)>>1))
  CF_AbsGradDLTRB,        //abs grad from cross diagonal: abs(((x1+x9+1)>>1) - ((x3+x7+1)>>1))
  CF_AbsGradDiffC,        //abs diff in center: abs(((((x1+x9+1)>>1) + ((x3+x7+1)>>1) + 1)>>1) - x5)
} ChannelType;

#if !defined(HOBOT_SYXC) && !defined(HOBOT_SCYX)
#define HOBOT_SYXC
//#define HOBOT_SCYX
#endif

/**
 * @brief Compute Channel Features, index as below
 *              0   1   2
 *              3   4   5
 *              6   7   8
 * @param img_w
 * @param img_h
 * @param img_step
 * @param img
 * @param chan_type
 * @param radius
 * @param fimg_step
 * @param fimg
 */
void ComputeChannelFeature(const int img_w, const int img_h,
                           const int img_step, const unsigned char *img,
                           const ChannelType chan_type, const int radius,
                           const int fimg_step, unsigned char *fimg);

/**
 * @brief Triangular Filter for Image (i.e.,  2-D [1 2 1] / 4)
 * @param img_w
 * @param img_h
 * @param img_step
 * @param img
 * @param radius
 * @param stride
 * @param fimg_step
 * @param fimg
 */
void TriangularFilter(const int img_w, const int img_h,
                      const int img_step, const unsigned char *img,
                      const int radius, const int stride,
                      const int fimg_step, unsigned char *fimg);

/**
 * @brief TODO
 * @param img_w
 * @param img_h
 * @param img_step
 * @param img
 * @param fimg_ystep
 * @param fimg_xstep
 * @param fimg_cstep
 * @param fimg
 */
void ComputeChannelFeatureNeon(const int img_w,
                               const int img_h,
                               const int img_step,
                               const unsigned char *img,
                               const int fimg_ystep,
                               const int fimg_xstep,
                               const int fimg_cstep,
                               unsigned char *fimg);

/**
 * @brief TODO
 * @param img_w
 * @param img_h
 * @param img_ystep
 * @param img_xstep
 * @param img
 * @param radius
 * @param stride
 * @param fimg_ystep
 * @param fimg_xstep
 * @param fimg
 */
void TriangularFilterNeon(const int img_w,
                          const int img_h,
                          const int img_ystep,
                          const int img_xstep,
                          const int img_cstep,
                          const unsigned char *img,
                          const int radius,
                          const int stride,
                          const int fimg_ystep,
                          const int fimg_xstep,
                          const int fimg_cstep,
                          unsigned char *fimg);

} // namespace alpha
} // namespace vision
} // namespace hobot

#endif  //__CHANNEL_FEATURE_H__
