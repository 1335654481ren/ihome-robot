//
//  Multi-Channel Multi-Scale (MCMS) feature image
//  Copyright (c) 2016 by Horizon Robotics Inc.
//  Author: Chang Huang (chang.huang@hobot.cc)
//

#ifndef __MCMS_H__
#define __MCMS_H__

#include "array.h"
#include "channel_feature.h"

namespace hobot {
namespace vision {
namespace alpha {

class ImageMcms {
 public:
  //axis definitions
#if defined(HOBOT_SYXC)
  static const int mcms_s_i = 0, mcms_y_i = 1, mcms_x_i = 2, mcms_c_i = 3;
  static const int mc_y_i = 0, mc_x_i = 1, mc_c_i = 2;
#elif defined(HOBOT_SCYX)
  static const int mcms_s_i = 0, mcms_c_i = 1, mcms_y_i = 2, mcms_x_i = 3;
  static const int mc_c_i = 0, mc_y_i = 1, mc_x_i = 2;
#else
#error "NOT SUPPORT NDIM"
#endif

  int img_w_, img_h_, scale_num_;

  std::vector<ChannelType> chan_types_;

  TArrayMD<uchar>
      mcms_img_;            //multi-channel multi-scale image container
  TArrayMD<uchar> mc_img_;              //multi-channel image

  explicit ImageMcms() : img_w_(0), img_h_(0), scale_num_(0) {}

  ImageMcms(int img_w, int img_h, int chan_num, int scale_num);

  void GetSteps(int &xstep, int &ystep, int &cstep, int &sstep) const;
  void GetImageSize(int &img_w, int &img_h) const;
  void GetFeatImageSize(int &fimg_w, int &fimg_h) const;

  int GetMaxChannelNum() const { return mcms_img_.shape_[mcms_c_i]; }
  int GetMaxScaleNum() const { return mcms_img_.shape_[mcms_s_i]; }
  int GetMaxImageW() const { return mcms_img_.shape_[mcms_x_i] << 1; }
  int GetMaxImageH() const { return mcms_img_.shape_[mcms_y_i] << 1; }

  //margins, [0] left, [1] top, [2] right, [3] bottom
  //void GetMargin(int c, int s, int *margins) const;

  virtual void Compute(const uchar *grey_img, const int w, const int h, const int step,
               const int chan_num, const ChannelType *chan_types,
               const int scale_num);

  inline const uchar *GetWndPtr(int x, int y) const {
    return mcms_img_.c_ptr() + x * mcms_img_.steps_[mcms_x_i]
        + y * mcms_img_.steps_[mcms_y_i];
  }
};

} // namespace alpha
} // namespace vision
} // namespace hobot

#endif
