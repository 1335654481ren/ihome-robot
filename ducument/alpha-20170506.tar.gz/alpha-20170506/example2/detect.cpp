//
//  Sample Codes of Using Alpha Detection Module
//

#include "opencv/cv.h"
#include "opencv/highgui.h"
#include "opencv/cv.hpp"

#include "alpha_detection.h"
#include "alpha_merge.h"
#include "SimpleIniExt.h"
#include <stdio.h>
#include <fstream>
#include <vector>

#if defined(__linux__) || defined(__APPLE__)
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <unistd.h>
#define sprintf_s sprintf
#endif
#ifdef _WIN32
#include <windows.h>
#include <time.h>
#endif

using namespace cv;
using namespace hobot::vision::alpha;
namespace hb = hobot;

void ShowGreyImage(int img_w, int img_h, int img_grey_step,
                   unsigned char *grey_img_data, char *wnd_name) {
  IplImage *img = cvCreateImageHeader(cvSize(img_w, img_h), 8, 1);
  cvSetData(img, grey_img_data, img_grey_step);
  cvShowImage(wnd_name, img);
  cvReleaseImageHeader(&img);
}

void ShowGreyImage(GreyImage &img, char *wnd_name) {
  ShowGreyImage(img.GetWidth(), img.GetHeight(), img.GetWidthStep(),
                img.GetData(), wnd_name);
}

void SaveGreyImage(int img_w, int img_h, int img_grey_step,
                   unsigned char *grey_img_data, char *filename) {
  IplImage *img = cvCreateImageHeader(cvSize(img_w, img_h), 8, 1);
  cvSetData(img, grey_img_data, img_grey_step);
  cvSaveImage(filename, img);
  cvReleaseImageHeader(&img);
}

void SaveGreyImage(GreyImage &img, char *filename) {
  SaveGreyImage(img.GetWidth(), img.GetHeight(), img.GetWidthStep(),
                img.GetData(), filename);
}

std::string GetDirname(const std::string& str) {
  std::size_t found = str.find_last_of("/\\");
  if (found == std::string::npos) {
    return std::string(".");
  } else {
    return str.substr(0, found);
  }
}

long long GetTimeStamp() {
#ifdef _WIN32
  LARGE_INTEGER freq, curr_time;
  QueryPerformanceFrequency(&freq);
  QueryPerformanceCounter(&curr_time);
  return curr_time.QuadPart * 1000 / freq.QuadPart;

#elif defined(__linux__) || defined(__APPLE__)
  struct timeval curr_time;
  gettimeofday(&curr_time, NULL);
  return curr_time.tv_sec * 1000 + curr_time.tv_usec / 1000;

#else
  REPORT_ERROR_POSITION
  ;
#endif
}

struct ImageRectAnno {
  std::string img_fname;
  std::vector<float> rect_annos;
};

void LoadImageRectAnnoList(const char *img_rect_anno_fname,
                           const char *img_fname_prefix,
                           std::vector<ImageRectAnno> &img_rect_annos) {
  std::string dirname = img_fname_prefix ? img_fname_prefix : GetDirname(std::string(img_rect_anno_fname));
  std::ifstream ifs(img_rect_anno_fname);
  if (!ifs.is_open()) {
    ERROR_INFO("Failed in loading %s", img_rect_anno_fname);
  }

  while (ifs.good()) {
    std::string line;
    std::getline(ifs, line);
    if (line.length() > 1) {
      std::vector < std::string > items;
      std::string delim(" ");
      split(line, delim, items);
      if (items.size() == 0) {
        continue;
      }
      ImageRectAnno ira;
      ira.img_fname = dirname + "/" + items[0];
      for (unsigned int i = 1; i < items.size(); i++) {
        ira.rect_annos.push_back(float(atof(items[i].c_str())));
      }
      img_rect_annos.push_back(ira);
    }
  }
}

int TestDetectImage(int argc, char **argv) {
  if (argc != 3 && argc != 4) {
    printf("usage: ./detect settings_ini_fname image_list_fname [image_fname_prefix]\n");
    return -1;
  }

  const char *ini_fname = argv[1];
  const char *img_rect_anno_fname = argv[2];
  const char *img_fname_prefix = argc == 4 ? argv[3] : NULL;

  //
  // read settings from ini
  //
  CSimpleIniExt ini(true);
  if (ini.LoadFile(ini_fname) < 0) {
    ERROR_INFO("Failed in loading %s", ini_fname);
  }

  //
  // General Settings
  //

  // whether enable batch processing mode
  int batch_mode;
  if (!ini.GetValueExt("general_settings", "batch_mode", batch_mode)) {
    batch_mode = 0;
  }
  if (!batch_mode) {
    ini.SetSilentMode(false);
  }

  // maximum image size
  int max_img_w, max_img_h;
  if (!ini.GetValueExt("general_settings", "max_img_w", max_img_w)) REPORT_ERROR_POSITION;
  if (!ini.GetValueExt("general_settings", "max_img_h", max_img_h)) REPORT_ERROR_POSITION;

  //
  // Scan Settings
  //

  // scanning scales
  int scale_bits;
  int start_scale_denom, scale_step_denom;
  float Nyquist_freq_ratio;
  float scan_end_scale;
  // use hardware friendly version
  if (!ini.GetValueExt("scan_settings", "scale_bits", scale_bits)) {
    REPORT_ERROR_POSITION;
  }
  if (!ini.GetValueExt("scan_settings", "start_scale_denom", start_scale_denom)) {
    REPORT_ERROR_POSITION;
  }
  if (!ini.GetValueExt("scan_settings", "scale_step_denom", scale_step_denom)) {
    REPORT_ERROR_POSITION;
  }

  int scale_level_num;
  if (!ini.GetValueExt("scan_settings", "scale_level_num", scale_level_num)) {
    // calculate true beginning scale and scale step for image pyramid, as well as the number of levels
    if (!ini.GetValueExt("scan_settings", "scan_end_scale", scan_end_scale)) {
      REPORT_ERROR_POSITION;
    }
    float scan_bgn_scale = float(1 << scale_bits) / start_scale_denom;
    float scan_scale_step = float(1 << scale_bits) / scale_step_denom;
    scale_level_num = int(
        logf(scan_end_scale / scan_bgn_scale) / logf(scan_scale_step));
  }

  // minimum pyramid scaled image size
  int min_scale_level_w, min_scale_level_h;
  if (!ini.GetValueExt("scan_settings", "min_scale_level_w", min_scale_level_w)) {
    min_scale_level_w = 16;
  }
  if (!ini.GetValueExt("scan_settings", "min_scale_level_h", min_scale_level_h)) {
    min_scale_level_h = 16;
  }

  // Nyquist_freq_ratio is for mitigating high-frequency noise during image down scale, 1.0 means disabled
  if (!ini.GetValueExt("scan_settings", "Nyquist_freq_ratio",
                       Nyquist_freq_ratio)) {
    Nyquist_freq_ratio = 1.0f;
  }

  // scan mode
  ScanMode scan_mode;
  std::string str;
  if (!ini.GetValueExt("scan_settings", "scan_mode", str)) {
    REPORT_ERROR_POSITION;
  }
  if (0 == str.compare("uniform")) {
    scan_mode = kUniformScan;
  } else if (0 == str.compare("coarse_to_fine")) {
    scan_mode = kCoarse2FineScan;
  } else if (0 == str.compare("cell_search")) {
    scan_mode = kCellSearch;
  } else {
    ERROR_INFO("Unknown scan mode %s", str.c_str());
  }

  // coarse to fine layer number for early rejecting in coarse to fine and cell search modes
  int coarse_to_fine_layer_num;
  if (scan_mode != kUniformScan) {
    if (!ini.GetValueExt("scan_settings", "coarse_to_fine_layer_num",
                         coarse_to_fine_layer_num)) {
      REPORT_ERROR_POSITION;
    }
  }

  // padding border size
  int pad_border;
  if (!ini.GetValueExt("scan_settings", "pad_border", pad_border)) {
    pad_border = 0;
  }

  //
  // Merge Settings
  //
  float merge_overlap_ratio_thres;
  float nms_conf_thres;
  float nms_max_overlap_ratio;
  float nms_max_contain_ratio;
  if (!ini.GetValueExt("merge_settings", "merge_overlap_ratio_thres",
                       merge_overlap_ratio_thres)) {
    REPORT_ERROR_POSITION;
  }
  if (!ini.GetValueExt("merge_settings", "nms_conf_thres", nms_conf_thres)) {
    REPORT_ERROR_POSITION;
  }
  if (!ini.GetValueExt("merge_settings", "nms_max_overlap_ratio",
                       nms_max_overlap_ratio)) {
    REPORT_ERROR_POSITION
  }
  if (!ini.GetValueExt("merge_settings", "nms_max_contain_ratio",
                       nms_max_contain_ratio)) {
    REPORT_ERROR_POSITION;
  }

  //
  // Model Filenames
  //
  std::vector < std::string > model_names;
  std::string ini_dirname = GetDirname(std::string(ini_fname));

  for (int model_i = 0; model_i < 8; model_i++) {
    std::stringstream sname;
    sname << "model" << model_i;
    if (ini.GetSectionSize(sname.str().c_str()) < 0) {
      break;
    }
    std::string mname;
    if (!ini.GetValueExt(sname.str().c_str(), "model_fname", mname)) {
      REPORT_ERROR_POSITION;
    }
    if (mname[0] == '/' || mname[1] == ':') {
      // with absolute path (linux or windows)
      model_names.push_back(mname);
    }
    else {
      model_names.push_back(ini_dirname + "/" + mname);
    }
  }

  //
  // Initialize Alpha Detector
  //
  AlphaDetector det(max_img_w, max_img_h);

  std::vector<std::istream*> iss;
  for (unsigned int i = 0; i < model_names.size(); i++) {
    std::ifstream *ifs = new std::ifstream(model_names[i].c_str(),
                                           std::ifstream::binary);
    if (!ifs->is_open()) {
      ERROR_INFO("Failed in loading %s", model_names[i].c_str());
    }
    iss.push_back(ifs);
  }
  det.InitModels(iss);
  for (unsigned int i = 0; i < iss.size(); i++) {
    delete iss[i];
  }

  //
  // Load Image Rect Anno File List
  //
  std::vector<ImageRectAnno> img_rect_annos;
  LoadImageRectAnnoList(img_rect_anno_fname, img_fname_prefix, img_rect_annos);

  const CvScalar COLOR_RGB[] = { CV_RGB(0, 255, 0), CV_RGB(255, 0, 0), CV_RGB(
      0, 0, 255), CV_RGB(128, 0, 255), CV_RGB(128, 255, 0), CV_RGB(255, 0, 128),
                                 CV_RGB(0, 128, 255), CV_RGB(255, 128, 0) };

  bool show_raw_resp = true;
  bool show_merged_resp = true;
  std::vector<bool> show_model_rst(model_names.size(), true);

  unsigned int i = 0;
  unsigned int img_num = img_rect_annos.size();
  GreyImagePyramidFP img_pyr(pad_border, scale_level_num, min_scale_level_w, min_scale_level_h,
                             scale_bits, start_scale_denom, scale_step_denom, Nyquist_freq_ratio);

  while (i < img_num) {
    printf("%s\n", img_rect_annos[i].img_fname.c_str());
    IplImage *color_img = cvLoadImage(img_rect_annos[i].img_fname.c_str());
    if (color_img == NULL) {
      printf("failed in loading image %s\n", img_rect_annos[i].img_fname.c_str());
      exit(0);
    }
    IplImage *grey_img = cvCreateImage(
        cvSize(color_img->width, color_img->height), 8, 1);
    cvCvtColor(color_img, grey_img, CV_BGR2GRAY);

    std::vector<std::list<SDetRespFP> > raw_resp_list, merged_resp_list;
    long long st = GetTimeStamp();
    // compute image pyramid
    img_pyr.Init(grey_img->width, grey_img->height, grey_img->widthStep,
                 (unsigned char*) grey_img->imageData);
    // scan for raw detection
    det.Detect(img_pyr, scan_mode, coarse_to_fine_layer_num, raw_resp_list);
    // merge and non-max suppression
    merged_resp_list.resize(raw_resp_list.size());
    for (unsigned int ci = 0; ci < merged_resp_list.size(); ci++) {
      DetRespOnlineClusteringFP(raw_resp_list[ci], merge_overlap_ratio_thres,
                                merged_resp_list[ci]);
      NonMaximumSuppresionFP(merged_resp_list[ci], nms_conf_thres,
                             nms_max_overlap_ratio, nms_max_contain_ratio);
    }
    long long time_elaps = GetTimeStamp() - st;

    /*
     //debug
     for (unsigned int k = 0; k < img_pyr.GetLevelNum(); k++) {
     if (k < 6) continue;
     GreyImage &img = *((GreyImage*)img_pyr.GetLevel(k));
     char wnd_name[128];
     sprintf_s(wnd_name, "lv %d", k);
     ShowGreyImage(img.GetWidth(), img.GetHeight(), img.GetWidthStep(),
     img.GetData(), wnd_name);
     }
     */

    if (batch_mode) {
      printf("%s", img_rect_annos[i].img_fname.c_str());
      for (unsigned int ci = 0; ci < merged_resp_list.size(); ci++) {
        for (SDetRespFP &itr : merged_resp_list[ci]) {
          //        for (std::list<SDetRespFP>::iterator itr = merged_resp_list[ci].begin();
          //            itr != merged_resp_list[ci].end(); itr++) {
          float left = float(itr.rect.l) / (1 << kCoordDecPrec);
          float top = float(itr.rect.t) / (1 << kCoordDecPrec);
          float right = float(itr.rect.r) / (1 << kCoordDecPrec);
          float bottom = float(itr.rect.b) / (1 << kCoordDecPrec);
          float conf = float(itr.conf) / (1 << kScoreDecPrec);
          printf(" %.1f %.1f %.1f %.1f %.2f", left, top, right, bottom, conf);
        }
        printf("\n");
      }
    } else {
      printf("#%u/%lu: %s, time spent %llu ms\n", i, img_rect_annos.size(),
             img_rect_annos[i].img_fname.c_str(), time_elaps);
      for (unsigned int ci = 0; ci < merged_resp_list.size(); ci++) {
        printf("\t#%u: %lu raw, %lu merged\n", ci, raw_resp_list[ci].size(),
               merged_resp_list[ci].size());
#if 0
        for (std::list<SDetRespFP>::iterator itr = merged_resp_list[ci].begin();
            itr != merged_resp_list[ci].end(); itr++) {
          float left = float(itr->rect.l) / (1 << kCoordDecPrec);
          float top = float(itr->rect.t) / (1 << kCoordDecPrec);
          float right = float(itr->rect.r) / (1 << kCoordDecPrec);
          float bottom = float(itr->rect.b) / (1 << kCoordDecPrec);
          float conf = float(itr->conf) / (1 << kScoreDecPrec);
          printf(" %.1f %.1f %.1f %.1f %.2f", left, top, right, bottom, conf);
        }
        printf("\n");
#endif
      }
    }

#ifdef CAL_DET_STAT
    det.PrintDetStat();
#endif

    bool quit = false;

    if (batch_mode) {
      i++;

    } else {
      //render detection results
      while (true) {
        IplImage *rst_img = cvCloneImage(color_img);
        for (unsigned int ci = 0; ci < merged_resp_list.size(); ci++) {
          if (!show_model_rst[ci])
            continue;
          if (show_raw_resp) {
            //            for (std::list<SDetRespFP>::iterator itr =
            //                raw_resp_list[ci].begin(); itr != raw_resp_list[ci].end();
            //                itr++) {
            for (SDetRespFP &itr : raw_resp_list[ci]) {
              int left = hb::RightShiftRoundUp(itr.rect.l, kCoordDecPrec);
              int top = hb::RightShiftRoundUp(itr.rect.t, kCoordDecPrec);
              int right = hb::RightShiftRoundUp(itr.rect.r, kCoordDecPrec);
              int bottom = hb::RightShiftRoundUp(itr.rect.b, kCoordDecPrec);
              cvRectangle(rst_img, cvPoint(left, top), cvPoint(right, bottom),
                          COLOR_RGB[ci], 1);
            }
          }
          if (show_merged_resp) {
            CvFont font;
            cvInitFont(&font, CV_FONT_HERSHEY_DUPLEX, 1.0f, 1.0f, 0, 1, CV_AA);
            for (SDetRespFP &itr : merged_resp_list[ci]) {
              //            for (std::list<SDetRespFP>::iterator itr = merged_resp_list[ci]
              //                .begin(); itr != merged_resp_list[ci].end(); itr++) {
              int left = hb::RightShiftRoundUp(itr.rect.l, kCoordDecPrec);
              int top = hb::RightShiftRoundUp(itr.rect.t, kCoordDecPrec);
              int right = hb::RightShiftRoundUp(itr.rect.r, kCoordDecPrec);
              int bottom = hb::RightShiftRoundUp(itr.rect.b, kCoordDecPrec);
              float conf = float(itr.conf) / (1 << kScoreDecPrec);
              int line_width = int(log1p(conf));
              cvRectangle(rst_img, cvPoint(left, top), cvPoint(right, bottom),
                          CV_RGB(0, 0, 0), line_width + 4);
              cvRectangle(rst_img, cvPoint(left, top), cvPoint(right, bottom),
                          COLOR_RGB[ci], line_width);
              std::stringstream text;
              text << conf << ".f";
              //              char text[20];
              //              sprintf_s(text, "%.0f", conf);
              CvSize text_size;
              int baseline;
              cvGetTextSize(text.str().c_str(), &font, &text_size, &baseline);
              cvPutText(rst_img, text.str().c_str(),
                        cvPoint(left, top - text_size.height / 2), &font,
                        COLOR_RGB[ci]);
            }
          }
        }
        cvShowImage("det_rst", rst_img);
        cvReleaseImage(&rst_img);
        int key = cvWaitKey(-1) & 0xFF;
        if (key == 'q' || key == 'Q') {
          quit = true;
          break;
        } else if (key == 'r' || key == 'R') {
          show_raw_resp = !show_raw_resp;
        } else if (key == 'm' || key == 'M') {
          show_merged_resp = !show_merged_resp;
        } else if (key >= '1' && key < '8') {
          int idx = key - '1';
          show_model_rst[idx] = !show_model_rst[idx];
        } else if (key == ' ') {
          break;
        } else if (key == '=') {
          if (i + 1 < img_num)
            i++;
          else
            i = img_num - 1;
          break;
        } else if (key == '-') {
          if (i > 0)
            i--;
          else
            i = 0;
          break;
        } else if (key == ']') {
          if (i + 10 < img_num)
            i += 10;
          else
            i = img_num - 1;
          break;
        } else if (key == '[') {
          if (i > 10)
            i -= 10;
          else
            i = 0;
          break;
        } else if (key == '\'') {
          if (i + 100 < img_num)
            i += 100;
          else
            i = img_num - 1;
          break;
        } else if (key == ';') {
          if (i > 100)
            i -= 100;
          else
            i = 0;
          break;
#ifdef CAL_DET_STAT
          } else if (key == 's' || key == 'S') {
          det.ResetDetStat();
#endif
        } else {
          //break;
        }
      }
    }

    cvReleaseImage(&grey_img);
    cvReleaseImage(&color_img);
    if (quit)
      break;
  }
  return 0;
}

int TestDetectCamera(int argc, char **argv) {
  if (argc != 2) {
    printf("usage: %s settings_ini_fname\n", argv[0]);
    return -1;
  }

  const char *ini_fname = argv[1];

  //
  // read settings from ini
  //
  CSimpleIniExt ini(true);
  if (ini.LoadFile(ini_fname) < 0) {
    ERROR_INFO("Failed in loading %s", ini_fname);
  }

  //
  // General Settings
  //

  // whether enable batch processing mode
  ini.SetSilentMode(false);

  // maximum image size
  int max_img_w, max_img_h;
  if (!ini.GetValueExt("general_settings", "max_img_w", max_img_w)) REPORT_ERROR_POSITION;
  if (!ini.GetValueExt("general_settings", "max_img_h", max_img_h)) REPORT_ERROR_POSITION;

  //
  // Scan Settings
  //

  // scanning scales
  int scale_bits;
  int start_scale_denom, scale_step_denom;
  float Nyquist_freq_ratio;
  float scan_end_scale;
  // use hardware friendly version
  if (!ini.GetValueExt("scan_settings", "scale_bits", scale_bits)) {
    REPORT_ERROR_POSITION;
  }
  if (!ini.GetValueExt("scan_settings", "start_scale_denom", start_scale_denom)) {
    REPORT_ERROR_POSITION;
  }
  if (!ini.GetValueExt("scan_settings", "scale_step_denom", scale_step_denom)) {
    REPORT_ERROR_POSITION;
  }

  int scale_level_num;
  if (!ini.GetValueExt("scan_settings", "scale_level_num", scale_level_num)) {
    // calculate true beginning scale and scale step for image pyramid, as well as the number of levels
    if (!ini.GetValueExt("scan_settings", "scan_end_scale", scan_end_scale)) {
      REPORT_ERROR_POSITION;
    }
    float scan_bgn_scale = float(1 << scale_bits) / start_scale_denom;
    float scan_scale_step = float(1 << scale_bits) / scale_step_denom;
    scale_level_num = int(
        logf(scan_end_scale / scan_bgn_scale) / logf(scan_scale_step));
  }

  // minimum pyramid scaled image size
  int min_scale_level_w, min_scale_level_h;
  if (!ini.GetValueExt("scan_settings", "min_scale_level_w", min_scale_level_w)) {
    min_scale_level_w = 16;
  }
  if (!ini.GetValueExt("scan_settings", "min_scale_level_h", min_scale_level_h)) {
    min_scale_level_h = 16;
  }

  // Nyquist_freq_ratio is for mitigating high-frequency noise during image down scale, 1.0 means disabled
  if (!ini.GetValueExt("scan_settings", "Nyquist_freq_ratio",
                       Nyquist_freq_ratio)) {
    Nyquist_freq_ratio = 1.0f;
  }

  // scan mode
  ScanMode scan_mode;
  std::string str;
  if (!ini.GetValueExt("scan_settings", "scan_mode", str)) {
    REPORT_ERROR_POSITION;
  }
  if (0 == str.compare("uniform")) {
    scan_mode = kUniformScan;
  } else if (0 == str.compare("coarse_to_fine")) {
    scan_mode = kCoarse2FineScan;
  } else if (0 == str.compare("cell_search")) {
    scan_mode = kCellSearch;
  } else {
    ERROR_INFO("Unknown scan mode %s", str.c_str());
  }

  // coarse to fine layer number for early rejecting in coarse to fine and cell search modes
  int coarse_to_fine_layer_num;
  if (scan_mode != kUniformScan) {
    if (!ini.GetValueExt("scan_settings", "coarse_to_fine_layer_num",
                         coarse_to_fine_layer_num)) {
      REPORT_ERROR_POSITION;
    }
  }

  // padding border size
  int pad_border;
  if (!ini.GetValueExt("scan_settings", "pad_border", pad_border)) {
    pad_border = 0;
  }

  //
  // Merge Settings
  //
  float merge_overlap_ratio_thres;
  float nms_conf_thres;
  float nms_max_overlap_ratio;
  float nms_max_contain_ratio;
  if (!ini.GetValueExt("merge_settings", "merge_overlap_ratio_thres",
                       merge_overlap_ratio_thres)) {
    REPORT_ERROR_POSITION;
  }
  if (!ini.GetValueExt("merge_settings", "nms_conf_thres", nms_conf_thres)) {
    REPORT_ERROR_POSITION;
  }
  if (!ini.GetValueExt("merge_settings", "nms_max_overlap_ratio",
                       nms_max_overlap_ratio)) {
    REPORT_ERROR_POSITION
  }
  if (!ini.GetValueExt("merge_settings", "nms_max_contain_ratio",
                       nms_max_contain_ratio)) {
    REPORT_ERROR_POSITION;
  }

  //
  // Model Filenames
  //
  std::vector < std::string > model_names;
  std::string ini_dirname = GetDirname(std::string(ini_fname));

  for (int model_i = 0; model_i < 8; model_i++) {
    std::stringstream sname;
    sname << "model" << model_i;
    if (ini.GetSectionSize(sname.str().c_str()) < 0) {
      break;
    }
    std::string mname;
    if (!ini.GetValueExt(sname.str().c_str(), "model_fname", mname)) {
      REPORT_ERROR_POSITION;
    }
    if (mname[0] == '/' || mname[1] == ':') {
      // with absolute path (linux or windows)
      model_names.push_back(mname);
    }
    else {
      model_names.push_back(ini_dirname + "/" + mname);
    }
  }

  //
  // Initialize Alpha Detector
  //
  AlphaDetector det(max_img_w, max_img_h);

  std::vector<std::istream*> iss;
  for (unsigned int i = 0; i < model_names.size(); i++) {
    std::ifstream *ifs = new std::ifstream(model_names[i].c_str(),
                                           std::ifstream::binary);
    if (!ifs->is_open()) {
      ERROR_INFO("Failed in loading %s", model_names[i].c_str());
    }
    iss.push_back(ifs);
  }
  det.InitModels(iss);
  for (unsigned int i = 0; i < iss.size(); i++) {
    delete iss[i];
  }

  //
  // Load Image Rect Anno File List
  //
  cv::VideoCapture camera(0);

  const CvScalar COLOR_RGB[] = { CV_RGB(0, 255, 0), CV_RGB(255, 0, 0), CV_RGB(
      0, 0, 255), CV_RGB(128, 0, 255), CV_RGB(128, 255, 0), CV_RGB(255, 0, 128),
      CV_RGB(0, 128, 255), CV_RGB(255, 128, 0) };

  bool show_raw_resp = true;
  bool show_merged_resp = true;
  std::vector<bool> show_model_rst(model_names.size(), true);

  unsigned int i = 0;
//  unsigned int img_num = img_rect_annos.size();
  GreyImagePyramidFP img_pyr(pad_border, scale_level_num, min_scale_level_w, min_scale_level_h,
      scale_bits, start_scale_denom, scale_step_denom, Nyquist_freq_ratio);

  while (1) {
    cv::Mat color_img;
    camera >> color_img;
    cv::Mat grey_img(color_img.rows, color_img.cols, CV_8UC1);
    cv::cvtColor(color_img, grey_img, CV_BGR2GRAY);

    std::vector<std::list<SDetRespFP> > raw_resp_list, merged_resp_list;
    long long st = GetTimeStamp();
    // compute image pyramid
    img_pyr.Init(grey_img.cols, grey_img.rows, grey_img.step[grey_img.dims - 2],
                 grey_img.data);
    // scan for raw detection
    det.Detect(img_pyr, scan_mode, coarse_to_fine_layer_num, raw_resp_list);
    // merge and non-max suppression
    merged_resp_list.resize(raw_resp_list.size());
    for (unsigned int ci = 0; ci < merged_resp_list.size(); ci++) {
      DetRespOnlineClusteringFP(raw_resp_list[ci], merge_overlap_ratio_thres,
                                merged_resp_list[ci]);
      NonMaximumSuppresionFP(merged_resp_list[ci], nms_conf_thres,
                             nms_max_overlap_ratio, nms_max_contain_ratio);
    }
    long long time_elaps = GetTimeStamp() - st;

    std::cout << "#" << i++ << " frame, spent " << time_elaps << "ms" << std::endl;
    for (unsigned int ci = 0; ci < merged_resp_list.size(); ci++) {
      std::cout << "\t#" << ci << ": " << raw_resp_list[ci].size() << " raw, "
                << merged_resp_list[ci].size() << " merged" << std::endl;
    }

#ifdef CAL_DET_STAT
    det.PrintDetStat();
#endif

    bool quit = false;

    {
      //render detection results
      while (true) {
        cv::Mat rst_img;
        color_img.copyTo(rst_img);
        for (unsigned int ci = 0; ci < merged_resp_list.size(); ci++) {
          if (!show_model_rst[ci])
            continue;
          if (show_raw_resp) {
            for (SDetRespFP &itr : raw_resp_list[ci]) {
              int left = hb::RightShiftRoundUp(itr.rect.l, kCoordDecPrec);
              int top = hb::RightShiftRoundUp(itr.rect.t, kCoordDecPrec);
              int right = hb::RightShiftRoundUp(itr.rect.r, kCoordDecPrec);
              int bottom = hb::RightShiftRoundUp(itr.rect.b, kCoordDecPrec);
              cv::rectangle(rst_img, cv::Point(left, top), cv::Point(right, bottom),
                          COLOR_RGB[ci], 1);
            }
          }
          if (show_merged_resp) {
            CvFont font;
            cvInitFont(&font, CV_FONT_HERSHEY_DUPLEX, 1.0f, 1.0f, 0, 1, CV_AA);
            for (SDetRespFP &itr : merged_resp_list[ci]) {
              int left = hb::RightShiftRoundUp(itr.rect.l, kCoordDecPrec);
              int top = hb::RightShiftRoundUp(itr.rect.t, kCoordDecPrec);
              int right = hb::RightShiftRoundUp(itr.rect.r, kCoordDecPrec);
              int bottom = hb::RightShiftRoundUp(itr.rect.b, kCoordDecPrec);
              float conf = float(itr.conf) / (1 << kScoreDecPrec);
              int line_width = int(log1p(conf));
              cv::rectangle(rst_img, cv::Point(left, top), cv::Point(right, bottom),
                          CV_RGB(0, 0, 0), line_width + 4);
              cv::rectangle(rst_img, cv::Point(left, top), cv::Point(right, bottom),
                          COLOR_RGB[ci], line_width);
              std::stringstream text;
              text << conf << ".f";
              CvSize text_size;
              int baseline;
              cvGetTextSize(text.str().c_str(), &font, &text_size, &baseline);
              cv::putText(rst_img, text.str(),
                          cv::Point(left, top - text_size.height / 2),
                          CV_FONT_HERSHEY_DUPLEX, 1.f,
                          COLOR_RGB[ci]);
            }
          }
        }
        cv::imshow("det_rst", rst_img);
        int key = cv::waitKey(1) & 0xFF;
        if (key == 'q' || key == 'Q') {
          quit = true;
          break;
        } else if (key == 'r' || key == 'R') {
          show_raw_resp = !show_raw_resp;
        } else if (key == 'm' || key == 'M') {
          show_merged_resp = !show_merged_resp;
        } else if (key >= '1' && key < '8') {
          int idx = key - '1';
          show_model_rst[idx] = !show_model_rst[idx];
        } else if (key == ' ') {
          break;
#ifdef CAL_DET_STAT
        } else if (key == 's' || key == 'S') {
          det.ResetDetStat();
#endif
        } else {
          break;
        }
      }
    }

    if (quit)
      break;
  }
  return 0;
}

int main(int argc, char **argv) {
  return TestDetectImage(argc, argv);
//  return TestDetectCamera(argc, argv);
}
